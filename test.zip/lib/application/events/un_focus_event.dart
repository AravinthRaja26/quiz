

import 'package:event_bus_plus/res/app_event.dart';

///
class UnFocusEvent extends AppEvent {
  ///
  const UnFocusEvent();

  @override
  List<Object?> get props => <Object>[];
}