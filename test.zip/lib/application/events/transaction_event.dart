import 'package:event_bus_plus/res/app_event.dart';

///
class TransactionEvent extends AppEvent {
  ///
  const TransactionEvent();

  @override
  List<Object?> get props => <Object>[];
}
