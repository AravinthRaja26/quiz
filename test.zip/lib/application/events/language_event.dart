

import 'package:event_bus_plus/event_bus_plus.dart';

///
/// DashboardEvent class
///
class LanguageEvent extends AppEvent{

  ///
  const LanguageEvent();

  @override
  List<Object?> get props => <Object>[];
}