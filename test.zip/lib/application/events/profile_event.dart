

import 'package:event_bus_plus/res/app_event.dart';

///
class ProfileEvent extends AppEvent {
  ///
  const ProfileEvent();

  @override
  List<Object?> get props => <Object>[];
}
///
class ProfileNameEvent extends AppEvent {
  ///
  const ProfileNameEvent();

  @override
  List<Object?> get props => <Object>[];
}
