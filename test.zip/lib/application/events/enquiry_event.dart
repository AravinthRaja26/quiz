import 'package:event_bus_plus/event_bus_plus.dart';

///
/// DashboardEvent class
///
class EnquiryEvent extends AppEvent{



  ///
  const EnquiryEvent();

  @override
  List<Object?> get props => <Object>[];
}