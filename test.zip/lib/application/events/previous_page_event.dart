import 'package:event_bus_plus/res/app_event.dart';

///
class PreviousPageEvent extends AppEvent {
  ///
  const PreviousPageEvent();
  @override
  List<Object?> get props => <Object>[];
}