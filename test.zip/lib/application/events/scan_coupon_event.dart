
import 'package:event_bus_plus/res/app_event.dart';

///
class ScanCouponEvent extends AppEvent {
  ///
  const ScanCouponEvent();

  @override
  List<Object?> get props => <Object>[];
}
