import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:flutter/material.dart';

///
/// ColorSchemes are generated from this website
/// https://m3.material.io/theme-builder#/custom
///

///
TextTheme textTheme = const TextTheme(
    bodyLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
    bodyMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
    bodySmall: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
    labelLarge: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
    labelMedium: TextStyle(fontSize: 12.55, fontWeight: FontWeight.w700),
    labelSmall: TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
    titleLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
    titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
    titleSmall: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
    headlineLarge: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
    headlineMedium: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
    headlineSmall: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
    displayLarge: TextStyle(fontSize: 36, fontWeight: FontWeight.w700),
    displayMedium: TextStyle(fontSize: 32, fontWeight: FontWeight.w700),
    displaySmall: TextStyle(fontSize: 28, fontWeight: FontWeight.w700));

///
/// LightColorScheme
///

const ColorScheme lightColorScheme = ColorScheme(
  brightness: Brightness.light,
  primary: Color(0xFFC00100),
  onPrimary: Color(0xFFFFFFFF),
  primaryContainer: Color(0xFFFFDAD4),
  onPrimaryContainer: Color(0xFF410000),
  secondary: Color(0xFF1E57C9),
  onSecondary: Color(0xFFFFFFFF),
  secondaryContainer: Color(0xFFDAE1FF),
  onSecondaryContainer: Color(0xFF001849),
  tertiary: Color(0xFF9A4523),
  onTertiary: Color(0xFFFFFFFF),
  tertiaryContainer: Color(0xFFFFDBCF),
  onTertiaryContainer: Color(0xFF380D00),
  error: Color(0xFFBA1A1A),
  errorContainer: Color(0xFFFFDAD6),
  onError: Color(0xFFFFFFFF),
  onErrorContainer: Color(0xFF410002),
  background: Color(0xFFFFFBFF),
  onBackground: Color(0xFF1B0261),
  surface: Color(0xFFFFFBFF),
  onSurface: Color(0xFF1B0261),
  surfaceVariant: Color(0xFFF5DDDA),
  onSurfaceVariant: Color(0xFF534341),
  outline: Color(0xFF857370),
  onInverseSurface: Color(0xFFF4EEFF),
  inverseSurface: Color(0xFF302175),
  inversePrimary: Color(0xFFFFB4A8),
  shadow: Color(0xFF000000),
  surfaceTint: Color(0xFFC00100),
  outlineVariant: Color(0xFFD8C2BE),
  scrim: Color(0xFF000000),
);

///
const ColorScheme darkColorScheme = ColorScheme(
  brightness: Brightness.dark,
  primary: Color(0xFFFFFFFF),
  onPrimary: Color(0xFF690100),
  primaryContainer: Color(0xFF930100),
  onPrimaryContainer: Color(0xFFFFDAD4),
  secondary: Color(0xFFB3C5FF),
  onSecondary: Color(0xFF002B75),
  secondaryContainer: Color(0xFF003FA3),
  onSecondaryContainer: Color(0xFFDAE1FF),
  tertiary: Color(0xFFFFB59B),
  onTertiary: Color(0xFF5B1A00),
  tertiaryContainer: Color(0xFF7B2E0E),
  onTertiaryContainer: Color(0xFFFFDBCF),
  error: Color(0xFFFFB4AB),
  errorContainer: Color(0xFF93000A),
  onError: Color(0xFF690005),
  onErrorContainer: Color(0xFFFFDAD6),
  background: Color(0xFF1B0261),
  onBackground: Color(0xFFE5DEFF),
  surface: Color(0xFF1B0261),
  onSurface: Color(0xFFE5DEFF),
  surfaceVariant: Color(0xFF534341),
  onSurfaceVariant: Color(0xFFD8C2BE),
  outline: Color(0xFFA08C89),
  onInverseSurface: Color(0xFF1B0261),
  inverseSurface: Color(0xFFE5DEFF),
  inversePrimary: Color(0xFFC00100),
  shadow: Color(0xFF000000),
  surfaceTint: Color(0xFFFFB4A8),
  outlineVariant: Color(0xFF534341),
  scrim: Color(0xFF000000),
);

///
/// Light Theme
/// The colors in [lightThemeData] MUST be used from [lightColorScheme]
///
ThemeData lightThemeData = ThemeData(
    useMaterial3: true,
    colorScheme: lightColorScheme,
    textTheme: textTheme.apply(bodyColor: lightColorScheme.onBackground),
    scaffoldBackgroundColor: lightColorScheme.background,
    cardColor: Colors.white,

    dialogTheme: const DialogTheme(
      backgroundColor: CustomColors.midBlue
    ),
    cardTheme: const CardTheme(color: Colors.white),
    appBarTheme: AppBarTheme(
      iconTheme: const IconThemeData(
        color: CustomColors.purpleBrown
      ),
        backgroundColor: lightColorScheme.onPrimary,
        titleTextStyle: textTheme.titleLarge));

///
/// DarkTheme Theme
/// The colors in [darkThemeData] MUST be used from [darkColorScheme]
///
ThemeData darkThemeData = ThemeData(
    useMaterial3: true,
    colorScheme: darkColorScheme,
    scaffoldBackgroundColor: darkColorScheme.background,
    textTheme: textTheme.apply(bodyColor: darkColorScheme.onBackground),
    cardColor: Colors.white,
    cardTheme: const CardTheme(color: Colors.white),
    appBarTheme: AppBarTheme(
        backgroundColor: darkColorScheme.onPrimary,
        titleTextStyle: textTheme.titleLarge));
