import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/enum/ticket_enum.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_bottom_sheet.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_tab_custom.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/no_data.dart';
import 'package:nikitchem/presentation/ui/utils/valitaion.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/ticket/ticket_list_viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/ticket/ticket_list_viewmodel_provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// TicketList Screen
///
@RoutePage(name: 'ticketListScreen')
class TicketListScreen extends StatelessWidget {
  /// TicketListScreen screen constructor
  const TicketListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return TicketListProvider(
      builder: (BuildContext context, _) {
        return Builder(builder: (BuildContext context) {
          TicketListViewModel vm =
              BaseViewModel.watch<TicketListViewModel>(context);

          return Scaffold(
              resizeToAvoidBottomInset: false,
              backgroundColor: CustomColors.white,
              appBar: AppBar(
                centerTitle: true,
                title: TextVariant(
                  data: localLanguage?.keyTicketDetails ??
                      LocaleKeys.ticketDetails.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                ),
                toolbarHeight: 100,
                bottom: PreferredSize(
                  preferredSize: Size(MediaQuery.of(context).size.width, 74),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: CustomCardWidget(
                                onTap: () {
                                  vm.currentTransaction(
                                      TicketEnum.allTicket, null, context);
                                },
                                title: localLanguage?.keyAllTickets
                                        ?.toUpperCase() ??
                                    LocaleKeys.allTickets.tr().toUpperCase(),
                                image:   AssetImagePath.tickets,
                                selectBgColor:
                                    vm.state.ticketPage == TicketEnum.allTicket
                                        ? CustomColors.midBlue
                                        : CustomColors.white,
                                selectTextColor:
                                    vm.state.ticketPage == TicketEnum.allTicket
                                        ? CustomColors.white
                                        : CustomColors.darkBrown,
                              ),
                            ),
                            Expanded(
                              child: CustomCardWidget(
                                onTap: () {
                                  vm.currentTransaction(
                                      TicketEnum.openTicket, 'Open', context);
                                },
                                title: localLanguage?.keyOpenTickets
                                        ?.toUpperCase() ??
                                    LocaleKeys.openTickets.tr().toUpperCase(),
                                image: AssetImagePath.openTicket,
                                selectBgColor:
                                    vm.state.ticketPage == TicketEnum.openTicket
                                        ? CustomColors.midBlue
                                        : CustomColors.white,
                                selectTextColor:
                                    vm.state.ticketPage == TicketEnum.openTicket
                                        ? CustomColors.white
                                        : CustomColors.darkBrown,
                              ),
                            ),
                            Expanded(
                              child: CustomCardWidget(
                                onTap: () {
                                  vm.currentTransaction(TicketEnum.inProcess,
                                      'Inprocess', context);
                                },
                                title: localLanguage?.keyInProcess
                                        ?.toUpperCase() ??
                                    'Inprocess'.toUpperCase(),
                                image: AssetImagePath.allTicket,
                                selectBgColor:
                                    vm.state.ticketPage == TicketEnum.inProcess
                                        ? CustomColors.midBlue
                                        : CustomColors.white,
                                selectTextColor:
                                    vm.state.ticketPage == TicketEnum.inProcess
                                        ? CustomColors.white
                                        : CustomColors.darkBrown,
                              ),
                            ),
                            Expanded(
                              child: CustomCardWidget(
                                onTap: () {
                                  vm.currentTransaction(
                                      TicketEnum.resolved, 'Resolved', context);
                                },
                                title:
                                    localLanguage?.keyResolved?.toUpperCase() ??
                                        LocaleKeys.resolved.tr().toUpperCase(),
                                image: AssetImagePath.resolved,
                                selectBgColor:
                                    vm.state.ticketPage == TicketEnum.resolved
                                        ? CustomColors.midBlue
                                        : CustomColors.white,
                                selectTextColor:
                                    vm.state.ticketPage == TicketEnum.resolved
                                        ? CustomColors.white
                                        : CustomColors.darkBrown,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 4,
                        )
                      ],
                    ),
                  ),
                ),
              ),
              persistentFooterButtons: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left: 15.0, right: 15.0),
                  child: BackGroundColorButton(
                    isEnable: true,
                    load: false,
                    width: MediaQuery.of(context).size.width,
                    btnName: localLanguage?.keyCreateTicket ??
                        LocaleKeys.createTicket.tr().toUpperCase(),
                    center: true,
                    onTap: () {
                      ticketBottomSheet(
                          key: vm.formKey,
                          validator: (String? value) {
                            return AppValidation.commentVerification(
                                vm.commentController.text.toString());
                          },
                          context: context,
                          controller: vm.commentController,
                          onTap: () {
                            if (vm.formKey.currentState!.validate()) {
                              vm.createTicket(context);
                            }
                          });
                    },
                    variantType: TextVariantType.titleMedium,
                    fontFamily: FontFamily.quattrocentoSans,
                  ),
                ),
              ],
              body: const _BodyScreen());
        });
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TicketListViewModel vm = BaseViewModel.watch<TicketListViewModel>(context);

    return vm.state.load == true
        ? const Center(
            child: CircularProgressIndicator(
              color: CustomColors.midBlue,
            ),
          )
        : const Padding(
            padding: EdgeInsets.only(left: 15.0, right: 15.0),
            child: TransactionWidgetTypes(),
          );
  }
}

///
class TransactionWidgetTypes extends StatelessWidget {
  ///
  const TransactionWidgetTypes({super.key});

  @override
  Widget build(BuildContext context) {
    TicketListViewModel vm = BaseViewModel.watch<TicketListViewModel>(context);
    switch (vm.state.ticketPage) {
      case TicketEnum.allTicket:
        return const AllTicketsWidget();
      case TicketEnum.openTicket:
        return const OpenTicketsWidget();
      case TicketEnum.resolved:
        return const ResolvedTicketsWidget();

      default:
        return const AllTicketsWidget();
    }
  }
}

///
/// AllTicketsWidget
///
class AllTicketsWidget extends StatelessWidget {
  ///

  ///
  final GestureTapCallback? onTap;

  ///
  const AllTicketsWidget({
    Key? key,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TicketListViewModel vm = BaseViewModel.watch<TicketListViewModel>(context);

    return vm.state.load == true
        ? const Center(
            child: Padding(
              padding: EdgeInsets.only(top: 38.0),
              child: CircularProgressIndicator(
                color: CustomColors.midBlue,
              ),
            ),
          )
        : vm.state.consumerTicketList?.data?.isEmpty == null ||
                vm.state.consumerTicketList?.data?.isEmpty == true
            ? const NoDataFound()
            : ListView.builder(
                shrinkWrap: true,
                primary: false,
                itemCount: vm.state.consumerTicketList?.data?.length ?? 0,
                itemBuilder: (BuildContext context, int allTicketIndex) {
                  return CommonListWidget(
                    createdDate: vm.createTicketFormate(vm
                            .state
                            .consumerTicketList!
                            .data?[allTicketIndex]
                            .createdDate ??
                        0),
                    onTap: () {
                      vm.navigateToTicketDetailScreen(
                          context: context,
                          ticketId: vm.state.consumerTicketList
                                  ?.data?[allTicketIndex].ticketId
                                  .toString() ??
                              '');
                    },
                    ticketProgressStatus: vm.state.consumerTicketList
                            ?.data?[allTicketIndex].ticketStatus ??
                        '',
                    ticketId: vm.state.consumerTicketList?.data?[allTicketIndex]
                            .ticketId
                            .toString() ??
                        '',
                    progressColor: vm.state.consumerTicketList
                                ?.data?[allTicketIndex].ticketStatus ==
                            'Open'
                        ? CustomColors.lipstick
                        : vm.state.consumerTicketList?.data?[allTicketIndex]
                                    .ticketStatus ==
                                'Inprocess'
                            ? Colors.orangeAccent
                            : vm.state.consumerTicketList?.data?[allTicketIndex]
                                        .ticketStatus ==
                                    'Resolved'
                                ? CustomColors.green
                                : CustomColors.lipstick,
                  );
                });
  }
}

///
/// OpenTicketsWidget
///
class OpenTicketsWidget extends StatelessWidget {
  ///
  final GestureTapCallback? onTap;

  ///
  const OpenTicketsWidget({
    Key? key,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TicketListViewModel vm = BaseViewModel.watch<TicketListViewModel>(context);

    return vm.state.load == true
        ? const Center(
            child: Padding(
              padding: EdgeInsets.only(top: 38.0),
              child: CircularProgressIndicator(
                color: CustomColors.midBlue,
              ),
            ),
          )
        : vm.state.consumerTicketList?.data?.isEmpty == null ||
                vm.state.consumerTicketList?.data?.isEmpty == true
            ? const NoDataFound()
            : ListView.builder(
                shrinkWrap: true,
                primary: false,
                itemCount: vm.state.consumerTicketList?.data?.length ?? 0,
                itemBuilder: (BuildContext context, int openTicketIndex) {
                  return CommonListWidget(
                    createdDate: vm.createTicketFormate(vm
                            .state
                            .consumerTicketList!
                            .data?[openTicketIndex]
                            .createdDate ??
                        0),
                    onTap: () {
                      vm.navigateToTicketDetailScreen(
                          context: context,
                          ticketId: vm.state.consumerTicketList
                                  ?.data?[openTicketIndex].ticketId
                                  .toString() ??
                              '');
                    },
                    ticketProgressStatus: vm.state.consumerTicketList
                            ?.data?[openTicketIndex].ticketStatus ??
                        '',
                    ticketId: vm.state.consumerTicketList
                            ?.data?[openTicketIndex].ticketId
                            .toString() ??
                        '',
                    progressColor: vm.state.consumerTicketList
                                ?.data?[openTicketIndex].ticketStatus ==
                            'Open'
                        ? CustomColors.lipstick
                        : vm.state.consumerTicketList?.data?[openTicketIndex]
                                    .ticketStatus ==
                                'Inprocess'
                            ? Colors.orangeAccent
                            : vm.state.consumerTicketList
                                        ?.data?[openTicketIndex].ticketStatus ==
                                    'Resolved'
                                ? CustomColors.green
                                : CustomColors.lipstick,
                  );
                });
  }
}

///
/// ResolvedTicketsWidget
///
class ResolvedTicketsWidget extends StatelessWidget {
  ///
  final GestureTapCallback? onTap;

  ///
  const ResolvedTicketsWidget({
    Key? key,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TicketListViewModel vm = BaseViewModel.watch<TicketListViewModel>(context);

    return vm.state.load == true
        ? const Center(
            child: Padding(
              padding: EdgeInsets.only(top: 38.0),
              child: CircularProgressIndicator(
                color: CustomColors.midBlue,
              ),
            ),
          )
        : vm.state.consumerTicketList?.data?.isEmpty == null ||
                vm.state.consumerTicketList?.data?.isEmpty == true
            ? const NoDataFound()
            : ListView.builder(
                shrinkWrap: true,
                primary: false,
                itemCount: vm.state.consumerTicketList?.data?.length ?? 0,
                itemBuilder: (BuildContext context, int resolvedIndex) {
                  return CommonListWidget(
                    onTap: () {
                      vm.navigateToTicketDetailScreen(
                          context: context,
                          ticketId: vm.state.consumerTicketList
                                  ?.data?[resolvedIndex].ticketId
                                  .toString() ??
                              '');
                    },
                    createdDate: vm.createTicketFormate(vm
                            .state
                            .consumerTicketList!
                            .data?[resolvedIndex]
                            .createdDate ??
                        0),
                    ticketProgressStatus: vm.state.consumerTicketList
                            ?.data?[resolvedIndex].ticketStatus ??
                        '',
                    ticketId: vm.state.consumerTicketList?.data?[resolvedIndex]
                            .ticketId
                            .toString() ??
                        '',
                    progressColor: vm.state.consumerTicketList
                                ?.data?[resolvedIndex].ticketStatus ==
                            'Open'
                        ? CustomColors.lipstick
                        : vm.state.consumerTicketList?.data?[resolvedIndex]
                                    .ticketStatus ==
                                'Inprocess'
                            ? Colors.orangeAccent
                            : vm.state.consumerTicketList?.data?[resolvedIndex]
                                        .ticketStatus ==
                                    'Resolved'
                                ? CustomColors.green
                                : CustomColors.lipstick,
                  );
                });
  }
}

///
class CommonListWidget extends StatelessWidget {
  ///
  final GestureTapCallback? onTap;

  ///
  final String? ticketProgressStatus;

  ////
  final String? ticketId;

  ///
  final String? createdDate;

  ///
  final Color? progressColor;

  ///
  const CommonListWidget(
      {Key? key,
      this.onTap,
      this.ticketProgressStatus,
      this.progressColor,
      this.ticketId,
      this.createdDate})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    TicketListViewModel vm = BaseViewModel.watch<TicketListViewModel>(context);

    return Padding(
      padding: const EdgeInsets.only(top: 6.0, bottom: 6, left: 5, right: 5),
      child: InkWell(
        onTap: onTap ??
            () {
              vm.navigateToTicketDetailScreen(
                  context: context, ticketId: ticketId ?? '');
            },
        child: Stack(
          children: <Widget>[
            Container(
              height: 80,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: CustomColors.lightWhite,
              ),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.only(left: 0.0, right: 0),
                child: Container(
                  height: 21,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 4.0, vertical: 1.0),
                  decoration: BoxDecoration(
                     /* gradient: LinearGradient(
                        colors: [progressColor ?? CustomColors.white, Colors.deepOrangeAccent,],
                        begin: FractionalOffset.center,
                        end: FractionalOffset.bottomRight,
                      ),*/

                      borderRadius: BorderRadius.circular(2),
                    color: progressColor ?? CustomColors.red
                  ),
                  child: TextVariant(
                    data: ticketProgressStatus ?? '',
                    color: CustomColors.white,
                    fontFamily: FontFamily.poppins,
                    variantType: TextVariantType.titleSmall,
                    textAlign: TextAlign.center,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0, right: 0, bottom: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(bottom: 2.0, top: 6),
                    child: Image.asset(
                      AssetImagePath.endUser,
                      height: 65,
                      width: 65,
                      fit: BoxFit.contain,
                      color: CustomColors.darkGrey,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 4, top: 10.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        TextVariant(
                          data: ticketId ?? '',
                          color: CustomColors.black,
                          fontFamily: FontFamily.poppins,
                          variantType: TextVariantType.titleLarge,
                          fontWeight: FontWeight.w500,
                        ),
                        const SizedBox(
                          height: 6,
                        ),
                        TextVariant(
                          data: createdDate.toString(),
                          color: CustomColors.greyishBrown,
                          fontFamily: FontFamily.poppins,
                          variantType: TextVariantType.bodySmall,
                          fontWeight: FontWeight.w300,
                        ),
                      ],
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(top: 40.0, left: 50),
                    child: Icon(
                      Icons.arrow_forward_ios,
                      color: CustomColors.black,
                      size: 16,
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: MediaQuery.of(context).size.width / -1.10,
              right: 0,
              top: 35,
              child: const CircleAvatar(
                backgroundColor: Colors.white,
                radius: 6,
              ),
            ),
            Positioned(
              right: MediaQuery.of(context).size.width / -1.10,
              left: 0,
              top: 35,
              child: const CircleAvatar(
                backgroundColor: Colors.white,
                radius: 6,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
