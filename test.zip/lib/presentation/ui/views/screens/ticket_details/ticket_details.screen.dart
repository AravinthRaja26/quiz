import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/no_data.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/ticket/ticket_detail_viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/ticket/ticket_detail_viewmodel_provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// TicketDetailScreen screen
///
@RoutePage(name: 'ticketDetailScreen')
class TicketDetailScreen extends StatelessWidget {
  ///
  final String ticketId;

  /// TicketDetailScreen screen constructor
  const TicketDetailScreen({super.key, required this.ticketId});

  @override
  Widget build(BuildContext context) {
    return TicketDetailProvider(
      ticketId: ticketId,
      builder: (BuildContext context, _) {
        return Scaffold(
            backgroundColor: CustomColors.white,
            appBar: AppBar(
                centerTitle: true,
                title: TextVariant(
                  data: localLanguage?.keyTicketDetails ??
                      LocaleKeys.ticketDetails.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                )),
            body: _BodyScreen(
              ticketId: ticketId,
            ));
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  final String? ticketId;
  const _BodyScreen({Key? key, this.ticketId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TicketDetailViewModel vm =
        BaseViewModel.watch<TicketDetailViewModel>(context);

    debugPrint(MediaQuery.of(context).size.width.toString());
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: vm.state.load == true
          ? const Center(
              child: Padding(
                padding: EdgeInsets.only(top: 38.0),
                child: CircularProgressIndicator(
                  color: CustomColors.midBlue,
                ),
              ),
            )
          : vm.state.viewTicketResponse?.data?.toString().isEmpty == null &&
                  vm.state.viewTicketResponse?.data.toString().isEmpty == true
              ? const NoDataFound()
              : Column(
                  children: <Widget>[
                    Stack(
                      children: <Widget>[
                        Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6),
                            color: CustomColors.lightWhite,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              children: <Widget>[
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 5.0),
                                      child: Image.asset(
                                        AssetImagePath.endUser,
                                        height: 65,
                                        width: 65,
                                        fit: BoxFit.contain,
                                        color: CustomColors.darkGrey,
                                      ),
                                    ),
                                    Column(
                                      children: <Widget>[
                                        TextVariant(
                                          data:
                                              localLanguage?.keyTicketNumber ??
                                                  LocaleKeys.ticketNumber.tr(),
                                          color: CustomColors.black,
                                          fontFamily:
                                              FontFamily.quattrocentoSans,
                                          variantType:
                                              TextVariantType.bodySmall,
                                          fontWeight: FontWeight.w400,
                                        ),
                                        const SizedBox(
                                          height: 5,
                                        ),
                                        TextVariant(
                                          data: vm.state.viewTicketResponse
                                                  ?.data?.ticketId ??
                                              '',
                                          color: CustomColors.midBlue,
                                          fontFamily:
                                              FontFamily.quattrocentoSans,
                                          variantType:
                                              TextVariantType.headlineMedium,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    Column(
                                      children: <Widget>[
                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: <Widget>[
                                              TextVariant(
                                                data: localLanguage
                                                        ?.keyTicketStatus ??
                                                    LocaleKeys.ticketStatus
                                                        .tr(),
                                                color: CustomColors.black,
                                                fontFamily:
                                                    FontFamily.quattrocentoSans,
                                                variantType:
                                                    TextVariantType.bodySmall,
                                                fontWeight: FontWeight.w400,
                                              ),
                                              TextVariant(
                                                data: vm
                                                        .state
                                                        .viewTicketResponse
                                                        ?.data
                                                        ?.ticketStatus ??
                                                    '',
                                                color: CustomColors.green,
                                                fontFamily:
                                                    FontFamily.quattrocentoSans,
                                                variantType:
                                                    TextVariantType.bodyLarge,
                                                fontWeight: FontWeight.w700,
                                              ),
                                              const SizedBox(
                                                height: 15,
                                              ),
                                              TextVariant(
                                                data: localLanguage
                                                        ?.keyCreatedOn ??
                                                    LocaleKeys.createdOn.tr(),
                                                color: CustomColors.black,
                                                fontFamily:
                                                    FontFamily.quattrocentoSans,
                                                variantType:
                                                    TextVariantType.bodySmall,
                                                fontWeight: FontWeight.w400,
                                              ),
                                              TextVariant(
                                                data: vm.createTicketFormate(vm
                                                        .state
                                                        .viewTicketResponse!
                                                        .data
                                                        ?.createdDate ??
                                                    0),
                                                color: CustomColors.black,
                                                fontFamily:
                                                    FontFamily.quattrocentoSans,
                                                variantType:
                                                    TextVariantType.bodyMedium,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: <Widget>[
                                              TextVariant(
                                                data: localLanguage
                                                        ?.keyTicketTitle ??
                                                    LocaleKeys.ticketTitle.tr(),
                                                color: CustomColors.black,
                                                fontFamily:
                                                    FontFamily.quattrocentoSans,
                                                variantType:
                                                    TextVariantType.bodySmall,
                                                fontWeight: FontWeight.w400,
                                              ),
                                              TextVariant(
                                                data: localLanguage
                                                        ?.keyOtherIssue ??
                                                    LocaleKeys.otherIssue.tr(),
                                                color: CustomColors.black,
                                                fontFamily:
                                                    FontFamily.quattrocentoSans,
                                                variantType:
                                                    TextVariantType.bodyMedium,
                                                fontWeight: FontWeight.w700,
                                              ),
                                              const SizedBox(
                                                height: 19,
                                              ),
                                              TextVariant(
                                                data: localLanguage
                                                        ?.keyResolvedOn ??
                                                    LocaleKeys.resolvedOn.tr(),
                                                color: CustomColors.black,
                                                fontFamily:
                                                    FontFamily.quattrocentoSans,
                                                variantType:
                                                    TextVariantType.bodySmall,
                                                fontWeight: FontWeight.w400,
                                              ),
                                              const TextVariant(
                                                textAlign: TextAlign.start,
                                                data: '_ _ _',
                                                color: CustomColors.black,
                                                fontFamily:
                                                    FontFamily.quattrocentoSans,
                                                variantType:
                                                    TextVariantType.bodyMedium,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        TextVariant(
                                          data: localLanguage?.keyDetails ??
                                              LocaleKeys.details.tr(),
                                          color: CustomColors.black,
                                          fontFamily:
                                              FontFamily.quattrocentoSans,
                                          variantType:
                                              TextVariantType.bodySmall,
                                          fontWeight: FontWeight.w400,
                                        ),
                                        const SizedBox(
                                          height: 5,
                                        ),
                                        TextVariant(
                                          data: vm.decodeDescriptionData(vm
                                                      .state
                                                      .viewTicketResponse
                                                      ?.data!
                                                      .ticketDescription ??
                                                  '------') ??
                                              '------',
                                          color: CustomColors.black,
                                          fontFamily:
                                              FontFamily.quattrocentoSans,
                                          variantType:
                                              TextVariantType.bodySmall,
                                          fontWeight: FontWeight.w700,
                                          textAlign: TextAlign.start,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          left: MediaQuery.of(context).size.width / -1.08,
                          right: 0,
                          top: 75,
                          child: const CircleAvatar(
                            backgroundColor: Colors.white,
                            radius: 6,
                          ),
                        ),
                        Positioned(
                          right: MediaQuery.of(context).size.width / -1.08,
                          left: 0,
                          top: 75,
                          child: const CircleAvatar(
                            backgroundColor: Colors.white,
                            radius: 6,
                          ),
                        ),
                        Positioned(
                          right: MediaQuery.of(context).size.width / -1.08,
                          left: 0,
                          top: 240,
                          child: const CircleAvatar(
                            backgroundColor: Colors.white,
                            radius: 6,
                          ),
                        ),
                        Positioned(
                          left: MediaQuery.of(context).size.width / -1.08,
                          right: 0,
                          top: 240,
                          child: const CircleAvatar(
                            backgroundColor: Colors.white,
                            radius: 6,
                          ),
                        ),
                        const Positioned(
                          top: 55,
                          child: Padding(
                            padding: EdgeInsets.all(13.0),
                            child: Text(
                              '----------------------------------------------------------------------',
                              maxLines: 1,
                              style: TextStyle(color: CustomColors.dimGrey),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
    );
  }
}
