import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/gen/assets.gen.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_indication.screen.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_listtitle.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/notification/notification.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/notification/notification_provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// notification screen
///
@RoutePage(name: 'notificationScreen')
class NotificationScreen extends StatelessWidget {
  /// NotificationScreen screen constructor
  const NotificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return NotificationViewModelProvider(
      builder: (BuildContext context, _) {
        return Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
                centerTitle: true,
                title: TextVariant(
                  data: localLanguage?.keyNotifications ??
                      LocaleKeys.notifications.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                )),
            body: const _BodyScreen());
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    NotificationViewModel vm =
        BaseViewModel.watch<NotificationViewModel>(context);

    return vm.state.load == true
        ? const Center(child: CircularProgressIndicator(
      color: CustomColors.midBlue,
    ))
        : vm.state.notificationResponse?.data?.bankTransfer?.isEmpty == null ||
                vm.state.notificationResponse?.data?.bankTransfer?.isEmpty ==
                    true
            ? IndicationScreen(
                image: Assets.images.group320.path,
                title: localLanguage?.keyNoNotifications ??
                    LocaleKeys.noNotifications.tr(),
                subTitle: localLanguage?.keyWeWillNotify ??
                    LocaleKeys.wellNotifyYouWhenSomethingArrived.tr(),
                buttonName: localLanguage?.keyGoBack ?? LocaleKeys.goBack.tr(),
                onTap: () {
                  AutoRouter.of(context).maybePop();
                },
              )
            : ListView.builder(
                shrinkWrap: true,
                itemCount:
                    vm.state.notificationResponse?.data?.bankTransfer?.length ??
                        0,
                itemBuilder: (BuildContext context, int index) {
                  return AppListTitle(
                    text: vm.state.notificationResponse?.data
                            ?.bankTransfer?[index].rechargeMessage ??
                        '',
                  );
                });
  }
}
