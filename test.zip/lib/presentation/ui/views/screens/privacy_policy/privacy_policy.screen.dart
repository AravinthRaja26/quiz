import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/listaki_web_view.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/privacy_policy/privacy_policy.provider.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/privacy_policy/privacy_policy.viewmodel.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// Privacy Policy Screen
///
@RoutePage(name: 'privacyPolicyScreen')
class PrivacyPolicyScreen extends StatelessWidget {
  /// PrivacyPolicyScreen screen constructor
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return PrivacyPolicyProvider(
      builder: (BuildContext context, Widget? child) {
        return Builder(builder: (BuildContext context) {
          return Scaffold(
              backgroundColor: Colors.white,
              appBar: AppBar(
                  centerTitle: true,
                  title: TextVariant(
                    data: localLanguage?.keyPrivacyPolicy ??
                        LocaleKeys.privacyPolicy.tr(),
                    color: CustomColors.purpleBrown,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.headlineMedium,
                    fontWeight: FontWeight.w700,
                  )),
              body: const _BodyScreen());
        });
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    PrivacyPolicyViewModel viewModel =
        BaseViewModel.watch<PrivacyPolicyViewModel>(context);
    return/* const Center(
      child: Text('No data'),
    );*/
    // don`t remove this code
    Padding(
      padding: const EdgeInsets.only(left: 8.0, right: 8.0),
      child:  NikitWebView(
        url: viewModel.webUrl(),
      ),
    );
  }
}
