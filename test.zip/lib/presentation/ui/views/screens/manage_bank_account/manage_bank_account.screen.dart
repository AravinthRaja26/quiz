import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_bottom_sheet.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/no_data.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/account/bank_account.provider.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/account/bank_account.viewmodel.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// ManageBank Account Screen
///
@RoutePage(name: 'manageBankAccountScreen')
class ManageBankAccountScreen extends StatelessWidget {
  /// Manage Bank Account screen constructor
  const ManageBankAccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AccountViewModelProvider(
      builder: (BuildContext context, _) {
        return Builder(builder: (BuildContext context) {
          BankAccountViewModel vm =
              BaseViewModel.watch<BankAccountViewModel>(context);
          return Scaffold(
              backgroundColor: Colors.white,
              appBar: AppBar(
                  centerTitle: true,
                  title: TextVariant(
                    data: localLanguage?.keyManageBankAccounts ??
                        LocaleKeys.manageBankAccounts.tr(),
                    color: CustomColors.purpleBrown,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.headlineMedium,
                    fontWeight: FontWeight.w700,
                  )),
              persistentFooterButtons: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: BackGroundColorButton(
                    isEnable: true,
                    load: false,
                    width: MediaQuery.of(context).size.width,
                    btnName: localLanguage?.keyAddBankAccount ??
                        LocaleKeys.addBankAccount.tr().toUpperCase(),
                    center: true,
                    onTap: () async {
                      showModelBottomSheet(
                          context,
                          vm.accountHolderController,
                          vm.accountNoController,
                          vm.reAccountNoController,
                          vm.ifscController,
                          vm.bankNameController,
                          vm.branchController, ifscOnChanged: (String value) {
                        vm.getBranchName();
                      },
                          cancelOnTap: (){
                            vm.clearText(context: context);
                          },
                          onTap: () {
                        if (vm.formKey.currentState!.validate()) {
                          vm.checkValidate(context: context);
                        }
                      }, key: vm.formKey, load: vm.state.buttonLoad);
                    },
                    variantType: TextVariantType.titleMedium,
                    fontFamily: FontFamily.quattrocentoSans,
                  ),
                ),
              ],
              body: const _BodyScreen());
        });
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    BankAccountViewModel vm =
        BaseViewModel.watch<BankAccountViewModel>(context);
    return Padding(
      padding: const EdgeInsets.only(left: 14.0, right: 14),
      child: vm.state.isLoad == true
          ? const Center(
              child: Padding(
                padding: EdgeInsets.only(top: 200.0),
                child: CircularProgressIndicator(
                  color: CustomColors.midBlue,
                ),
              ),
            )
          : vm.state.accountDetailsResponse?.data?.accountDetails?.isEmpty ==
                      null ||
                  vm.state.accountDetailsResponse?.data?.accountDetails
                          ?.isEmpty ==
                      true
              ? const AccountNoDataFound()
              : ListView.builder(
                  shrinkWrap: true,
                  primary: false,
                  itemCount: vm.state.accountDetailsResponse?.data
                          ?.accountDetails?.length ??
                      0,
                  itemBuilder: (BuildContext context, int index) {
                    return SizedBox(
                      height: 190,
                      child: Stack(
                        children: <Widget>[
                          Image.asset(
                            AssetImagePath.rectangleImage,
                            fit: BoxFit.fill,
                            height: 200,
                            width: double.infinity,
                          ),
                          Image.asset(
                            AssetImagePath.manageAccount,
                            fit: BoxFit.fill,
                            height: 188,
                            width: double.infinity,
                          ),


                          Padding(
                            padding: const EdgeInsets.only(
                                left: 18.0, right: 18, top: 16),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Flexible(
                                      flex: 1,
                                      fit: FlexFit.tight,
                                      child: TextVariant(
                                        data: vm
                                                .state
                                                .accountDetailsResponse
                                                ?.data
                                                ?.accountDetails?[index]
                                                .accHolderName ??
                                            '-----',
                                        color: CustomColors.white,
                                        fontFamily: FontFamily.poppins,
                                        variantType: TextVariantType.titleMedium,
                                        fontWeight: FontWeight.w500,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 45,
                                    ),
                                    Container(
                                      height: 22,
                                      width: 80,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(12),
                                          color: CustomColors.midGreen),
                                      child: TextVariant(
                                        textAlign: TextAlign.center,
                                        data: localLanguage?.keyActive != null
                                            ? '${localLanguage?.keyActive}'
                                            : LocaleKeys.active.tr(),
                                        variantType: TextVariantType.titleMedium,
                                        fontFamily: FontFamily.quattrocentoSans,
                                        color: Colors.white,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 8.0,bottom: 28,right: 26),
                                      child: Align(
                                        alignment: Alignment.bottomRight,
                                        child: InkWell(
                                          onTap: () {
                                            vm.showConfirmDialog(
                                                context,
                                                vm
                                                    .state
                                                    .accountDetailsResponse
                                                    ?.data
                                                    ?.accountDetails?[
                                                index]
                                                    .accId ??
                                                    0,
                                                cancelText:
                                                LocaleKeys.cancel.tr(),
                                                okText: LocaleKeys.confirm
                                                    .tr());
                                          },
                                          child: Image.asset(
                                            AssetImagePath.delete,
                                            fit: BoxFit.fill,
                                            height: 17,
                                            width: 17,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          TextVariant(
                                            data: localLanguage?.keyAccNo ??
                                                LocaleKeys.accountNo.tr(),
                                            color: CustomColors.white,
                                            fontFamily: FontFamily.poppins,
                                            variantType:
                                                TextVariantType.bodySmall,
                                            fontWeight: FontWeight.w300,
                                          ),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          TextVariant(
                                            data: vm
                                                    .state
                                                    .accountDetailsResponse
                                                    ?.data
                                                    ?.accountDetails?[index]
                                                    .accNo ??
                                                '-----',
                                            color: CustomColors.white,
                                            fontFamily: FontFamily.poppins,
                                            variantType:
                                                TextVariantType.titleSmall,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          const SizedBox(
                                            height: 15,
                                          ),
                                          TextVariant(
                                            data: localLanguage?.keyAddBankName ??
                                                LocaleKeys.bankName.tr(),
                                            color: CustomColors.white,
                                            fontFamily: FontFamily.poppins,
                                            variantType:
                                                TextVariantType.bodySmall,
                                            fontWeight: FontWeight.w300,
                                          ),
                                          TextVariant(
                                            data: vm
                                                    .state
                                                    .accountDetailsResponse
                                                    ?.data
                                                    ?.accountDetails?[index]
                                                    .bankName ??
                                                '-----',
                                            color: CustomColors.white,
                                            fontFamily: FontFamily.poppins,
                                            variantType:
                                                TextVariantType.titleSmall,
                                            fontWeight: FontWeight.w500,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          TextVariant(
                                            data: localLanguage?.keyBranchName ??
                                                LocaleKeys.branch.tr(),
                                            color: CustomColors.white,
                                            fontFamily: FontFamily.poppins,
                                            variantType:
                                                TextVariantType.bodySmall,
                                            fontWeight: FontWeight.w300,
                                          ),
                                          TextVariant(
                                            data: vm
                                                    .state
                                                    .accountDetailsResponse
                                                    ?.data
                                                    ?.accountDetails?[index]
                                                    .branchName ??
                                                '-----',
                                            color: CustomColors.white,
                                            fontFamily: FontFamily.poppins,
                                            variantType:
                                                TextVariantType.titleMedium,
                                            fontWeight: FontWeight.w500,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(
                                            height: 15,
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  TextVariant(
                                                    data: localLanguage
                                                            ?.keyIfscCode ??
                                                        LocaleKeys.ifscCode.tr(),
                                                    color: CustomColors.white,
                                                    fontFamily:
                                                        FontFamily.poppins,
                                                    variantType:
                                                        TextVariantType.bodySmall,
                                                    fontWeight: FontWeight.w300,
                                                  ),
                                                  TextVariant(
                                                    data: vm
                                                            .state
                                                            .accountDetailsResponse
                                                            ?.data
                                                            ?.accountDetails?[
                                                                index]
                                                            .ifscCode ??
                                                        '-----',
                                                    color: CustomColors.white,
                                                    fontFamily:
                                                        FontFamily.poppins,
                                                    variantType: TextVariantType
                                                        .titleSmall,
                                                    fontWeight: FontWeight.w500,
                                                    maxLines: 2,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                ],
                                              ),

                                            ],
                                          )
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),

                        ],
                      ),
                    );
                  }),
    );
  }
}
