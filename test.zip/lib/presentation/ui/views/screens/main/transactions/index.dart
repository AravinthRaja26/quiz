// ignore_for_file: always_specify_types
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/enum/transaction_enum.dart';
import 'package:nikitchem/data/models/consumer/consumer_transaction.model.dart';
import 'package:nikitchem/data/models/transcation/earned/earned_model.dart';
import 'package:nikitchem/data/models/transcation/expired/expired_model.dart';
import 'package:nikitchem/data/models/transcation/transfer/transfer_model.dart';
import 'package:nikitchem/data/models/transcation/verified/verified_model.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_bottom_sheet.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_tab_custom.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/no_data.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/transaction/transaction.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/transaction/transacton_viewmodel.provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// TransactionScreen
///
@RoutePage(name: 'transactionScreen')
class TransactionScreen extends StatelessWidget {
  /// TransactionScreen constructor
  const TransactionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return TransactionProvider(builder: (BuildContext context, _) {
      TransactionViwModel vm =
          BaseViewModel.watch<TransactionViwModel>(context);

      return Scaffold(
          key: vm.key,
          backgroundColor: CustomColors.white,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            centerTitle: true,
            title: TextVariant(
              data: localLanguage?.keyTransactions ??
                  LocaleKeys.transactions.tr(),
              color: CustomColors.purpleBrown,
              fontFamily: FontFamily.quattrocentoSans,
              variantType: TextVariantType.headlineMedium,
              fontWeight: FontWeight.w700,
            ),
            actions: <Widget>[
              Padding(
                padding: const EdgeInsets.only(right: 18.0, top: 10),
                child: InkWell(
                  onTap: () {
                    vm.navigationToNotificationScreen(context);
                  },
                  child: Image.asset(
                    AssetImagePath.notificationImage,
                    height: 25,
                    width: 25,
                    fit: BoxFit.fill,
                    color: CustomColors.black,
                  ),
                ),
              ),
            ],
            toolbarHeight: 110,
            bottom: PreferredSize(
              preferredSize: Size(MediaQuery.of(context).size.width, 74),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: CustomCardWidget(
                            onTap: () {
                              vm.currentTransaction(TransactionEnum.earned,context);
                            },
                            title: localLanguage?.keyEarned?.toUpperCase() ??
                                TransactionEnum.earned.name.toUpperCase(),
                            image: AssetImagePath.earned,
                            selectBgColor: vm.state.transactionPage ==
                                    TransactionEnum.earned
                                ? CustomColors.midBlue
                                : CustomColors.white,
                            selectTextColor: vm.state.transactionPage ==
                                    TransactionEnum.earned
                                ? CustomColors.white
                                : CustomColors.darkBrown,
                          ),
                        ),
                        Expanded(
                          child: CustomCardWidget(
                            onTap: () {
                              vm.currentTransaction(TransactionEnum.transfer,context);
                            },
                            title: localLanguage?.keyTransffer?.toUpperCase() ??
                                TransactionEnum.transfer.name.toUpperCase(),
                            image: 'assets/images/im_transfer.png',
                            selectBgColor: vm.state.transactionPage ==
                                    TransactionEnum.transfer
                                ? CustomColors.midBlue
                                : CustomColors.white,
                            selectTextColor: vm.state.transactionPage ==
                                    TransactionEnum.transfer
                                ? CustomColors.white
                                : CustomColors.darkBrown,
                          ),
                        ),
                        Expanded(
                          child: CustomCardWidget(
                            onTap: () {
                              vm.currentTransaction(TransactionEnum.redeemed,context);
                            },
                            selectBgColor: vm.state.transactionPage ==
                                    TransactionEnum.redeemed
                                ? CustomColors.midBlue
                                : CustomColors.white,
                            selectTextColor: vm.state.transactionPage ==
                                    TransactionEnum.redeemed
                                ? CustomColors.white
                                : CustomColors.darkBrown,
                            title: localLanguage?.keyRedeemed?.toUpperCase() ??
                                LocaleKeys.redeemed.tr().toUpperCase(),
                            image: AssetImagePath.redeemed,
                          ),
                        ),
                        Expanded(
                          child: CustomCardWidget(
                            onTap: () {
                              vm.currentTransaction(TransactionEnum.expired,context);
                            },
                            title: localLanguage?.keyExpired?.toUpperCase() ??
                                LocaleKeys.expired.tr().toUpperCase(),
                            selectBgColor: vm.state.transactionPage ==
                                    TransactionEnum.expired
                                ? CustomColors.midBlue
                                : CustomColors.white,
                            selectTextColor: vm.state.transactionPage ==
                                    TransactionEnum.expired
                                ? CustomColors.white
                                : CustomColors.darkBrown,
                            image: AssetImagePath.expired,
                          ),
                        ),
                        Expanded(
                          child: CustomCardWidget(
                            onTap: () {
                              vm.currentTransaction(TransactionEnum.verified,context);
                            },
                            selectBgColor: vm.state.transactionPage ==
                                    TransactionEnum.verified
                                ? CustomColors.midBlue
                                : CustomColors.white,
                            selectTextColor: vm.state.transactionPage ==
                                    TransactionEnum.verified
                                ? CustomColors.white
                                : CustomColors.darkBrown,
                            title: localLanguage?.keyVerified?.toUpperCase() ??
                                LocaleKeys.verified.tr().toUpperCase(),
                            image: AssetImagePath.verified,
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 5.0, top: 12),
                      child: TextVariant(
                        data: vm.title(),
                        color: CustomColors.black,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w700,
                        variantType: TextVariantType.titleLarge,
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    )
                  ],
                ),
              ),
            ),
          ),
          body: const _BodyScreen());
    });
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TransactionViwModel vm = BaseViewModel.watch<TransactionViwModel>(context);

    return RefreshIndicator(
      onRefresh: () async {
        vm.getTransactionDetails(context);
      },
      child: vm.state.load == true
          ? Center(
              child: Padding(
                padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height / 25),
                child: const CircularProgressIndicator(
                  color: CustomColors.midBlue,
                ),
              ),
            )
          : const TransactionWidgetTypes(),
    );
  }
}

///
class TransactionWidgetTypes extends StatelessWidget {
  ///
  const TransactionWidgetTypes({super.key});

  @override
  Widget build(BuildContext context) {
    TransactionViwModel vm = BaseViewModel.watch<TransactionViwModel>(context);
    switch (vm.state.transactionPage) {
      case TransactionEnum.earned:
        return const EarnedWidget();
      case TransactionEnum.transfer:
        return const TransferWidget();
      case TransactionEnum.redeemed:
        return const RedeemedWidget();
      case TransactionEnum.expired:
        return const ExpiredWidget();
      case TransactionEnum.verified:
        return const VeriFiedWidget();
      default:
        return const EarnedWidget();
    }
  }
}

///
/// EarnedWidget
///
class EarnedWidget extends StatelessWidget {
  ///
  const EarnedWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TransactionViwModel vm = BaseViewModel.watch<TransactionViwModel>(context);
    EarnedResponse? earnedData = vm.state.earnedResponse;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14.0),
      child: earnedData?.data?.list == null ||
              earnedData?.data?.list?.isEmpty == true
          ? const NoDataFound()
          : ListView.builder(
              controller: vm.transactionScrollController,
              shrinkWrap: true,
              //  primary: true,
              physics: const ClampingScrollPhysics(),
              itemCount: earnedData?.data?.list?.length ?? 0,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(6.0),
                  child: Column(
                    children: <Widget>[
                      TransactionListWidget(
                        onTap: () {
                          vm.getCouponDetail(context,
                              earnedData?.data?.list?[index].coupenCode ?? '');
                        },
                        couponCode:
                            earnedData?.data?.list?[index].coupenCode ?? '',
                        expireDate:
                            '${earnedData?.data?.list?[index].transactionTime}',
                        amount: earnedData?.data?.list?[index].amount,
                      )
                    ],
                  ),
                );
              }),
    );
  }
}

///
/// TransferWidget
///
class TransferWidget extends StatelessWidget {
  ///
  const TransferWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TransactionViwModel vm = BaseViewModel.watch<TransactionViwModel>(context);
    TransferResponse? transferResponse = vm.state.transferResponse;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14.0),
      child: transferResponse?.data?.list == null ||
              transferResponse?.data?.list?.isEmpty == true
          ? const NoDataFound()
          : ListView.builder(
              controller: vm.transactionScrollController,
              shrinkWrap: true,
              //  primary: true,
              physics: const ClampingScrollPhysics(),
              itemCount: transferResponse?.data?.list?.length ?? 0,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(6.0),
                  child: Column(
                    children: <Widget>[
                      TransactionListWidget(
                        showArrow: false,
                        couponCode:
                            transferResponse?.data?.list?[index].sendTo ??
                                transferResponse
                                    ?.data?.list?[index].receiverMobile ??
                                '',
                        expireDate:
                            '${transferResponse?.data?.list?[index].transactionTime}',
                        amount: transferResponse?.data?.list?[index].amount,
                      )
                    ],
                  ),
                );
              }),
    );
  }
}

///
/// RedeemedWidget
///
class RedeemedWidget extends StatelessWidget {
  ///
  const RedeemedWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TransactionViwModel vm = BaseViewModel.watch<TransactionViwModel>(context);
    List<Redeemed>? transferResponse =
        vm.state.consumerTransactionResponse?.data?.redeemed;
    return Padding(
      padding: const EdgeInsets.only(top: 15.0),
      child: transferResponse == null || transferResponse.isEmpty == true
          ? const NoDataFound()
          : GridView.builder(
              controller: vm.transactionScrollController,
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              shrinkWrap: true,
              // primary: true,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 14,
                mainAxisSpacing: 14,
                mainAxisExtent: 157,
              ),
              itemCount: transferResponse.length ?? 0,
              itemBuilder: (BuildContext context, int index) {
                return InkWell(
                  child: Container(
                    width: MediaQuery.of(context).size.width / 2,
                    decoration: BoxDecoration(
                        color: CustomColors.purpleBrownLight,
                        borderRadius: BorderRadius.circular(6),
                        image: DecorationImage(
                            image: AssetImage(
                              AssetImagePath.redeemedTicket.toString(),
                            ),
                            fit: BoxFit.fill)),
                    child: Padding(
                      padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 48.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                TextVariant(
                                  data: transferResponse[index].uniqueRefNum ??
                                      '',
                                  color: CustomColors.black,
                                  fontFamily: FontFamily.quattrocentoSans,
                                  variantType: TextVariantType.titleSmall,
                                  fontWeight: FontWeight.w700,
                                ),
                                Wrap(
                                  children: [
                                    TextVariant(
                                      data:
                                          '${transferResponse[index].amount?.toInt().toString()} ${localLanguage?.keyPts ?? 'Pts'}',
                                      color: CustomColors.black,
                                      fontFamily: FontFamily.quattrocentoSans,
                                      variantType: TextVariantType.displaySmall,
                                      fontWeight: FontWeight.w700,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 5.0),
                                  child: TextVariant(
                                    data: transferResponse[index]
                                            .transactionType ??
                                        '',
                                    color: /* transferResponse[index].transactionType ==
                                            'Debit'
                                        ? CustomColors.red
                                        : */
                                        CustomColors.green,
                                    fontFamily: FontFamily.quattrocentoSans,
                                    variantType: TextVariantType.bodySmall,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 18.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                TextVariant(
                                  data:
                                      transferResponse[index].transactionType ??
                                          '',
                                  color: CustomColors.black,
                                  fontFamily: FontFamily.quattrocentoSans,
                                  variantType: TextVariantType.bodySmall,
                                  fontWeight: FontWeight.w400,
                                ),
                                TextVariant(
                                  data: '${transferResponse[index].timeStamp}',
                                  color: CustomColors.black,
                                  fontFamily: FontFamily.quattrocentoSans,
                                  variantType: TextVariantType.bodySmall,
                                  fontWeight: FontWeight.w700,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
    );
  }
}

///
/// ExpiredWidget
///
class ExpiredWidget extends StatelessWidget {
  ///
  const ExpiredWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TransactionViwModel vm = BaseViewModel.watch<TransactionViwModel>(context);
    ExpiredResponse? expiredResponse = vm.state.expiredResponse;
    return Padding(
      padding: const EdgeInsets.only(top: 15.0),
      child: expiredResponse?.data?.list == null ||
              expiredResponse?.data?.list?.isEmpty == true
          ? const NoDataFound()
          : ListView.builder(
              controller: vm.transactionScrollController,
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              shrinkWrap: true,
              //  primary: true,
              itemCount: expiredResponse?.data?.list?.length ?? 0,
              itemBuilder: (BuildContext context, int index) {
                return Padding(
                  padding: const EdgeInsets.all(6),
                  child: TransactionListWidget(
                    onTap: () {
                      vm.getCouponDetail(context,
                          expiredResponse?.data?.list?[index].couponCode ?? '');
                    },
                    image: AssetImagePath.qrDim,
                    couponCode:
                        expiredResponse?.data?.list?[index].couponCode ?? '',
                    expireDate:
                        expiredResponse?.data?.list?[index].expiredDate ?? '',
                    amount:
                        expiredResponse?.data?.list?[index].amount?.toDouble(),
                  ),
                );
              }),
    );
  }
}

///
/// VeriFiedWidget
///
class VeriFiedWidget extends StatelessWidget {
  ///
  const VeriFiedWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TransactionViwModel vm = BaseViewModel.watch<TransactionViwModel>(context);
    VerifiedResponse? verifiedResponse = vm.state.verifiedResponse;
    return verifiedResponse?.data?.list == null ||
            verifiedResponse?.data?.list?.isEmpty == true
        ? const NoDataFound()
        : GridView.builder(
            controller: vm.transactionScrollController,
            padding: const EdgeInsets.only(left: 16.0, right: 16.0),
            shrinkWrap: true,
            // primary: false,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 13,
              mainAxisSpacing: 13,
              mainAxisExtent: 180,
            ),
            itemCount: verifiedResponse?.data?.list?.length ?? 0,
            itemBuilder: (BuildContext context, int index) {
              return Container(
                width: MediaQuery.of(context).size.width / 2,
                decoration: BoxDecoration(
                  color: CustomColors.purpleBrownLight,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 20.0, right: 20),
                      child: Image.asset(
                        AssetImagePath.qrDim,
                        height: 175,
                        width: 200,
                        fit: BoxFit.contain,
                        color: CustomColors.greyishBrown,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.only(top: 6),
                      height: 65,
                      width: double.infinity,
                      decoration: const BoxDecoration(
                        color: CustomColors.dimRed,
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(6),
                            bottomRight: Radius.circular(6)),
                      ),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            TextVariant(
                              data: verifiedResponse
                                      ?.data?.list?[index].couponCode ??
                                  '',
                              color: CustomColors.purpleBrown,
                              fontFamily: FontFamily.quattrocentoSans,
                              variantType: TextVariantType.titleMedium,
                              fontWeight: FontWeight.w700,
                            ),
                            Expanded(
                              child: TextVariant(
                                data: verifiedResponse
                                        ?.data?.list?[index].scannedDate ??
                                    '',
                                color: CustomColors.black,
                                fontFamily: FontFamily.quattrocentoSans,
                                variantType: TextVariantType.labelMedium,
                                fontWeight: FontWeight.w400,
                                maxLines: 2,
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              );
            });
  }
}

///
class TransactionListWidget extends StatelessWidget {
  ///
  final String? image;

  ///
  final bool? showArrow;

  ///
  final String? couponCode;

  ///
  final String? expireDate;

  ///
  final double? amount;

  ///
  GestureTapCallback? onTap;

  ///
  TransactionListWidget(
      {Key? key,
      this.image,
      this.couponCode,
      this.expireDate,
      this.showArrow,
      this.amount,
      this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: BorderRadius.circular(6.0),
      elevation: 2.0,
      color: Colors.white,
      child: InkWell(
        borderRadius: BorderRadius.circular(6.0),
        onTap: onTap ?? () {},
        splashColor: Colors.grey.withOpacity(0.2),
        splashFactory: InkSplash.splashFactory,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.0),
          ),
          child: Padding(
            padding: const EdgeInsets.only(
                top: 14.0, bottom: 14.0, left: 8.0, right: 8.0),
            child: Row(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left: 4.0),
                  child: Image.asset(
                    image ?? AssetImagePath.qrDetails,
                    fit: BoxFit.fill,
                    color: CustomColors.black,
                    height: 35,
                    width: 35,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      SizedBox(
                        width: 160,
                        child: TextVariant(
                          data: couponCode ?? '11011ZNQJ',
                          color: CustomColors.black,
                          fontFamily: FontFamily.poppins,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                          variantType: TextVariantType.titleMedium,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      TextVariant(
                        data: expireDate ?? 'Expire on 28 july 2023',
                        color: CustomColors.greyishBrown,
                        fontFamily: FontFamily.poppins,
                        variantType: TextVariantType.bodySmall,
                        fontWeight: FontWeight.w300,
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                TextVariant(
                  data: '$amount ${localLanguage?.keyPts ?? 'Pts'}',
                  color: CustomColors.black,
                  fontFamily: FontFamily.poppins,
                  variantType: TextVariantType.bodyMedium,
                  fontWeight: FontWeight.w600,
                ),
                const SizedBox(
                  width: 8,
                ),
                showArrow == false
                    ? SizedBox()
                    : const Expanded(
                        child: Padding(
                          padding: EdgeInsets.only(right: 2),
                          child: Icon(
                            Icons.arrow_forward_ios,
                            color: CustomColors.midBlue,
                            size: 16,
                          ),
                        ),
                      ),
                const SizedBox(
                  width: 8,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
