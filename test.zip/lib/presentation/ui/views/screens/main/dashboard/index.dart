// ignore_for_file: always_specify_types
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/dashboard/dashboard.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/dashboard/dashboard_viewmodel.provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import 'package:string_extensions/string_extensions.dart';

///
/// DashBoard screen
///
@RoutePage(name: 'dashboardScreen')
class DashBoard extends StatelessWidget {
  /// DashBoard screen constructor
  const DashBoard({super.key});

  @override
  Widget build(BuildContext context) {
    return DashboardProvider(
      builder: (BuildContext context, _) {
        DashBoardViewModel vm =
            BaseViewModel.watch<DashBoardViewModel>(context);
        return Scaffold(
            key: vm.key,
            resizeToAvoidBottomInset: false,
            appBar: AppBar(
              leading: Padding(
                padding: const EdgeInsets.only(left: 18.0, top: 10),
                child: Image.asset(AssetImagePath.asLogo),
              ),
              title: Padding(
                padding: const EdgeInsets.only(left: 4.0, top: 10),
                child: TextVariant(
                  data: localLanguage?.keyHello != null
                      ? '${localLanguage?.keyHello} ${vm.state.userName?.toTitleCase!.toString() ?? ''.replaceFirst(vm.state.userName?[0] ?? '', vm.state.userName?[0].toUpperCase() ?? '')}'
                      : LocaleKeys.hello.tr(namedArgs: {
                          'userName': vm.state.userName.toTitleCase!.toString()
                        }),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                ),
              ),
              actions: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(right: 18.0, top: 10),
                  child: InkWell(
                    onTap: () {
                      vm.navigationToProfileScreen(context);
                    },
                    child: Image.asset(
                      AssetImagePath.personImage,
                      height: 24,
                      width: 24,
                      fit: BoxFit.fill,
                      color: CustomColors.purpleBrown,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 18.0, top: 10),
                  child: InkWell(
                    onTap: () {
                      vm.navigationToNotificationScreen(context);
                    },
                    child: Image.asset(
                      AssetImagePath.notificationImage,
                      height: 24,
                      width: 24,
                      fit: BoxFit.fill,
                      color: CustomColors.purpleBrown,
                    ),
                  ),
                ),
              ],
            ),
            backgroundColor: Colors.white,
            body: const _BodyScreen());
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen();

  @override
  Widget build(BuildContext context) {
    DashBoardViewModel viewModel =
        BaseViewModel.watch<DashBoardViewModel>(context);
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.only(right: 16.0, left: 16.0, top: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const CarouselSliderWidget(),
            const WalletWidget(),
            const SizedBox(
              height: 25,
            ),
            const BankTransferWidget(),
            const SizedBox(
              height: 25,
            ),
            const ScannerWidget(),
            const SizedBox(
              height: 25,
            ),
          ],
        ),
      ),
    );
  }
}

///
class CarouselSliderWidget extends StatelessWidget {
  ///
  const CarouselSliderWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    DashBoardViewModel vm = BaseViewModel.watch<DashBoardViewModel>(context);
    return vm.state.bannerResponse?.data?.isNotEmpty == true
        ? Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              CarouselSlider.builder(
                  options: CarouselOptions(
                      height: 160,
                      aspectRatio: 2.0,
                      viewportFraction: 1.00,
                      initialPage: 0,
                      enableInfiniteScroll: true,
                      reverse: false,
                      autoPlay: vm.imageAutoPlay(),
                      autoPlayInterval: const Duration(seconds: 3),
                      autoPlayAnimationDuration:
                          const Duration(milliseconds: 800),
                      autoPlayCurve: Curves.fastOutSlowIn,
                      enlargeCenterPage: true,
                      enlargeFactor: 0.3,
                      scrollDirection: Axis.horizontal,
                      onPageChanged: (index, reason) {
                        vm.setCurrentIndex(index);
                      }),
                  itemCount: vm.state.bannerResponse?.data?.length ?? 0,
                  itemBuilder: (BuildContext context, int itemIndex,
                          int pageViewIndex) =>
                      Padding(
                        padding: const EdgeInsets.all(0.0),
                        child: Container(
                          height: 160,
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(0.0),
                            child: ClipRRect(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(8.0)),
                              child: InkWell(
                                onTap: () {
                                  vm.openDefaultBrowser(vm.state.bannerResponse
                                          ?.data?[itemIndex].bannerLink ??
                                      '');
                                },
                                child: CachedNetworkImage(
                                  imageUrl: vm.state.bannerResponse
                                          ?.data?[itemIndex].bannerImage ??
                                      '',
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                          ),
                        ),
                      )),
              const SizedBox(
                height: 12,
              ),
              vm.state.bannerResponse?.data?.length != 1
                  ? Center(
                      child: DotsIndicator(
                        dotsCount: vm.state.bannerResponse?.data?.length ?? 0,
                        position: vm.state.currentPage ?? 0,
                        decorator: DotsDecorator(
                          colors: List.generate(
                              vm.state.bannerResponse?.data?.length ?? 0,
                              (index) =>
                                  Color(CustomColors.cornflowerBlue.value)
                                      .withOpacity(0.2)).reversed.toList(),
                          activeColors: List.generate(
                              vm.state.bannerResponse?.data?.length ?? 0,
                              (index) => Color(CustomColors.midBlue.value)),
                        ),
                      ),
                    )
                  : const SizedBox(),
            ],
          )
        : const SizedBox(
            height: 160,
            child: Center(
              child: CircularProgressIndicator(
                color: CustomColors.midBlue,
              ),
            ),
          );
  }
}

///
class WalletWidget extends StatelessWidget {
  ///
  const WalletWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    DashBoardViewModel viewModel =
        BaseViewModel.watch<DashBoardViewModel>(context);
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 145.0,
          child: Stack(
            alignment: Alignment.bottomRight,
            children: <Widget>[
              Container(
                height: 113,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    color: CustomColors.greyishBlack,
                    borderRadius: BorderRadius.circular(6)),
                child: Padding(
                  padding:
                      const EdgeInsets.only(left: 14.0, right: 14.0, top: 9),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      /*viewModel.state.accountBalance != 0
                          ? */TextVariant(
                              data: localLanguage?.keyYourWalletBalance ??
                                  LocaleKeys.yourWalletBalanceIs.tr(),
                              color: CustomColors.white,
                              fontFamily: FontFamily.quattrocentoSans,
                              fontWeight: FontWeight.w400,
                            )
                          /*: const SizedBox()*/,
                      SizedBox(
                        height: viewModel.state.accountBalance != 0 ? 20 : 23,
                      ),
                      viewModel.state.accountBalance != 0
                          ? TextVariant(
                              data:
                                  '${viewModel.state.accountBalance} ${localLanguage?.keyPts ?? 'Pts'}',
                              color: CustomColors.white,
                              fontFamily: FontFamily.quattrocentoSans,
                              fontWeight: FontWeight.w700,
                              variantType: TextVariantType.displaySmall,
                            )
                          : Shimmer.fromColors(
                              enabled: true,
                              period: const Duration(milliseconds: 3000),
                              baseColor: CustomColors.white,
                              highlightColor: CustomColors.greyish,
                              child:  TextVariant(
                                data: localLanguage?.keyEarnRedeemNow ??'Earn & Redeem Now!',
                                color: CustomColors.white,
                                fontFamily: FontFamily.quattrocentoSans,
                                fontWeight: FontWeight.w700,
                                fontSize: 25,
                                variantType: TextVariantType.bodyMedium,
                              ),
                            ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 20.0),
                child: Image.asset(
                  AssetImagePath.dashboardPersonImage,
                  fit: BoxFit.cover,
                  height: 138,
                  width: 98,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(
          height: 18,
        ),
        TextVariant(
          data: localLanguage?.keyRedeemYourWalletPoints ??
              LocaleKeys.redeemYourWalletPoints.tr(),
          color: CustomColors.midBlue,
          fontFamily: FontFamily.quattrocentoSans,
          fontWeight: FontWeight.w700,
          variantType: TextVariantType.headlineSmall,
        ),
      ],
    );
  }
}

///
class BankTransferWidget extends StatelessWidget {
  ///
  const BankTransferWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    DashBoardViewModel viewModel =
        BaseViewModel.watch<DashBoardViewModel>(context);
    return Material(
      borderRadius: BorderRadius.circular(6.0),
      elevation: 2.0,
      color: Colors.white,
      child: InkWell(
        borderRadius: BorderRadius.circular(6.0),
        onTap: () {
          viewModel.navigationToBankTransferScreen(context);
        },
        splashColor: Colors.grey.withOpacity(0.2),
        splashFactory: InkSplash.splashFactory,
        child: Container(
          height: 68,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.0),
          ),
          child: Center(
            child: ListTile(
              leading: Image.asset(
                AssetImagePath.bank,
                fit: BoxFit.fill,
                height: 39,
                width: 39,
              ),
              title: TextVariant(
                data: localLanguage?.keyBankTransfer ??
                    LocaleKeys.bankTransfer.tr(),
                color: CustomColors.black,
                fontFamily: FontFamily.quattrocentoSans,
                fontWeight: FontWeight.w400,
                variantType: TextVariantType.bodyLarge,
              ),
              trailing: const Icon(
                Icons.arrow_forward_ios_rounded,
                size: 18,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

///
class ScannerWidget extends StatelessWidget {
  ///
  const ScannerWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    DashBoardViewModel vm = BaseViewModel.watch<DashBoardViewModel>(context);

    return Center(
      child: InkWell(
        onTap: () {
          /*vm.state.locationPermission == true
              ? vm.locationPermission()
              :*/
          vm.navigationToScannerScreen(context);
        },
        child: Stack(
          alignment: Alignment.center,
          children: <Widget>[
            InkWell(
              onTap: () {
                vm.navigationToScannerScreen(context);
              },
              child: Image.asset(
                AssetImagePath.scan,
                fit: BoxFit.fill,
                height: 81,
                width: 195,
                color: CustomColors.midBlue,
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                TextVariant(
                  data: localLanguage?.keyTapHere ?? LocaleKeys.tabHere.tr(),
                  color: CustomColors.midGreen,
                  fontFamily: FontFamily.quattrocentoSans,
                  fontWeight: FontWeight.w700,
                  variantType: TextVariantType.headlineSmall,
                ),
                TextVariant(
                  data: localLanguage?.keyToScan ?? LocaleKeys.toScan.tr(),
                  color: CustomColors.midGreen,
                  fontFamily: FontFamily.quattrocentoSans,
                  fontWeight: FontWeight.w700,
                  variantType: TextVariantType.headlineSmall,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
