import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/setting.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/setting_viewmodel.provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// Setting screen
///
@RoutePage(name: 'settingScreen')
class SettingScreen extends StatelessWidget {
  /// Setting screen constructor
  const SettingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SettingProvider(
      builder: (BuildContext context, _) {
        return Builder(builder: (BuildContext context) {
          BaseViewModel.watch<SettingViewModel>(context);

          return Scaffold(
              resizeToAvoidBottomInset: false,
              backgroundColor: Colors.white,
              appBar: AppBar(
                  automaticallyImplyLeading: false,
                  centerTitle: true,
                  title: TextVariant(
                    data:
                        localLanguage?.keySettings ?? LocaleKeys.settings.tr(),
                    color: CustomColors.purpleBrown,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.headlineMedium,
                    fontWeight: FontWeight.w700,
                  )),
              body: const _BodyScreen());
        });
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SettingViewModel vm = BaseViewModel.watch<SettingViewModel>(context);
    return Padding(
        padding: const EdgeInsets.only(left: 16.0, right: 16),
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ListView.builder(
                  shrinkWrap: true,
                  primary: false,
                  itemCount: vm.state.listData.length,
                  itemBuilder: (BuildContext context, int index) {
                    return Padding(
                      padding: const EdgeInsets.only(top: 8.0, bottom: 8),
                      child: Material(
                        borderRadius: BorderRadius.circular(6.0),
                        color: CustomColors.lightWhite,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(6.0),
                          onTap: () {
                            vm.settingScreenNavigation(
                                context, vm.state.listData[index].settingData!);
                          },
                          splashColor: Colors.grey.withOpacity(0.2),
                          splashFactory: InkSplash.splashFactory,
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12.0),
                            ),
                            child: ListTile(
                              leading: vm.state.listData[index].image,
                              title: TextVariant(
                                data: vm.state.listData[index].title.toString(),
                                color: CustomColors.purpleBrown,
                                fontFamily: FontFamily.quattrocentoSans,
                                variantType: TextVariantType.titleLarge,
                                fontWeight: FontWeight.w700,
                              ),
                              trailing: const Icon(
                                Icons.arrow_forward_ios,
                                color: Colors.black,
                                size: 16,
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: BackGroundColorButton(
                  width: double.infinity,
                  btnName: localLanguage?.keyLogout ??
                      LocaleKeys.logout.tr().toUpperCase(),
                  center: true,
                  load: false,
                  isEnable: true,



                  onTap: () {
                    vm.showConfirmDialog(context);
                  },
                  variantType: TextVariantType.titleMedium,
                  fontFamily: FontFamily.quattrocentoSans,
                ),
              ),
              const SizedBox(
                height: 12,
              )
            ],
          ),
        ));
  }
}
