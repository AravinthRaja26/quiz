import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/gen/assets.gen.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_outline_button.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/whatsapp/whatsapp.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/whatsapp/whatsapp_viewmodel.provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// Whatsapp screen
///
@RoutePage(name: 'whatsappScreen')
class WhatsappScreen extends StatelessWidget {
  /// Whatsapp screen constructor
  const WhatsappScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return WhatsAppProvider(
      builder: (BuildContext context, _) {
        return Builder(builder: (BuildContext context) {
          BaseViewModel.watch<WhatsAppViewModel>(context);

          return Scaffold(
              resizeToAvoidBottomInset: true,
              backgroundColor: Colors.white,
              appBar: AppBar(
                  automaticallyImplyLeading: false,
                  toolbarHeight: 80,
                  centerTitle: true,
                  title: TextVariant(
                    data: localLanguage?.keyWhatsapp ??
                        LocaleKeys.whatsapp.tr(),
                    color: CustomColors.purpleBrown,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.headlineMedium,
                    fontWeight: FontWeight.w700,
                  )),
              body: const _BodyScreen());
        });
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    WhatsAppViewModel viewModel =
        BaseViewModel.watch<WhatsAppViewModel>(context);
    return SingleChildScrollView(
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 40.0),
            child: Center(
              child: Image.asset(
                Assets.images.group376.path,
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(
            height: 35,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: TextVariant(
                data: localLanguage?.keyExternalApp ??
                    'You are taken to an external app to proceed with the chat. Do you want to continue?',
                textAlign: TextAlign.center,
                variantType: TextVariantType.bodyLarge,
                color: CustomColors.purpleBrown,
                fontFamily: FontFamily.quattrocentoSans),
          ),
          const SizedBox(
            height: 40,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                CustomOutlineButton(
                  text: localLanguage?.keyCancel ??
                      LocaleKeys.cancel.tr().toUpperCase(),
                  onTap: () {
                    viewModel.previousPage(context: context);
                  },
                ),
                Flexible(
                  child: OpenButton(
                    width: 130,
                    isEnable: true,
                    load: false,
                    center: true,
                    btnName: localLanguage?.keyOpen ??
                        LocaleKeys.open.tr().toUpperCase(),
                    onTap: () async {
                      viewModel.openWhatsapp(context);
                    },
                    variantType: TextVariantType.titleMedium,
                    fontFamily: FontFamily.quattrocentoSans,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
