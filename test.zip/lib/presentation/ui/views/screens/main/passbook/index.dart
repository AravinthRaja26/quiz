// ignore_for_file: always_specify_types
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_bottom_sheet.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/no_data.dart';
import 'package:nikitchem/presentation/ui/views/screens/main/transactions/index.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/passbook/passbook_detail.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/passbook/passbook_provider.dart';
import 'package:flutter/material.dart';

///
/// Passbook screen
///
@RoutePage(name: 'passbookScreen')
class PassbookScreen extends StatelessWidget {
  /// Passbook screen constructor
  const PassbookScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return PassbookViewModelProvider(
      builder: (BuildContext context, Widget? child) {
        return Builder(builder: (BuildContext context) {
          PassbookViewModel viewModel =
          BaseViewModel.watch<PassbookViewModel>(context);
          return Scaffold(
              backgroundColor: Colors.white,
              appBar: AppBar(
               centerTitle: true,
                  title:  TextVariant(
                    data: localLanguage?.keyPassbook ?? 'Passbook',
                    color: CustomColors.purpleBrown,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.headlineMedium,
                    fontWeight: FontWeight.w700,
                  ),
                actions: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(right: 20.0, top: 10),
                    child: InkWell(
                      onTap: () {
                        viewModel.navigationToNotificationScreen(context);
                      },
                      child: Image.asset(
                        AssetImagePath.notificationImage,
                        height: 24,
                        width: 24,
                        fit: BoxFit.fill,
                        color: CustomColors.purpleBrown,
                      ),
                    ),
                  ),
                ],
              ),
              body: const _BodyScreen());
        });
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    PassbookViewModel viewModel = BaseViewModel.watch<PassbookViewModel>(context);
    return   viewModel.state.passbookResponse?.data?.list == null ||
        viewModel.state.passbookResponse?.data?.list?.isEmpty == true
        ? const NoDataFound()
        :  Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14.0),
      child: ListView.builder(
          shrinkWrap: true,
          primary: true,
          physics: const ClampingScrollPhysics(),
         itemCount: viewModel.state.passbookResponse?.data?.list?.length??0,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.all(6.0),
              child: Column(
                children: <Widget>[
                  TransactionListWidget(
                    onTap: () {
                      passbookBottomSheet(
                        context: context,
                        couponCode:
                        viewModel.state.passbookResponse?.data?.list?[index].couponCode ??
                            '${viewModel.state.passbookResponse?.data?.list?[index].referenceNum}',
                        transcationType:viewModel.state.passbookResponse?.data?.list?[index].transactionType??'',
                        transferValue:viewModel.state.passbookResponse?.data?.list?[index].amount?.toDouble(),
                        transferDate:
                        '${viewModel.state.passbookResponse?.data?.list?[index].transactionTime}',
                      );
                    },
                    amount:viewModel.state.passbookResponse?.data?.list?[index].amount?.toDouble(),

                    couponCode:
                    viewModel.state.passbookResponse?.data?.list?[index].couponCode ??
                        '${viewModel.state.passbookResponse?.data?.list?[index].referenceNum}',
                    expireDate:
                    '${viewModel.state.passbookResponse?.data?.list?[index].transactionTime}',

                  )
                ],
              ),
            );
          }),
    );
  }
}
