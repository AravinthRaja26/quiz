import 'dart:io';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/enum/document_type.dart';
import 'package:nikitchem/data/models/user_profile/city_response.dart';
import 'package:nikitchem/data/models/user_profile/state_response.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_textform_field.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/profile/profile.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/profile/profile_viewmodel.provider.dart';

import '../../../../utils/storage.keys.dart';

///
/// profile screen
///
@RoutePage(name: 'profileScreen')
class ProfileScreen extends StatelessWidget {
  /// Profile screen constructor
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ProfileProvider(
      builder: (BuildContext context, Widget? child) {
        return Builder(builder: (BuildContext context) {
          ProfileViewModel viewModel =
              BaseViewModel.watch<ProfileViewModel>(context);
          return Scaffold(
              key: viewModel.scaffoldKey,
              backgroundColor: Colors.white,
              appBar: AppBar(
                  centerTitle: true,
                  title: TextVariant(
                    data: localLanguage?.keyProfile ?? LocaleKeys.profile.tr(),
                    color: CustomColors.purpleBrown,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.headlineMedium,
                    fontWeight: FontWeight.w700,
                  )),
              body: const _BodyScreen());
        });
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    ProfileViewModel viewModel = BaseViewModel.watch<ProfileViewModel>(context);
    print(
        '---A>${viewModel.state.consumerByIdResponse.consumerDetail?.kycStatusName}');
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.only(left: 16.0, right: 16, top: 10),
        child: Form(
          key: viewModel.form,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Center(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: CircleAvatar(
                    radius: 70.0,
                    backgroundColor: CustomColors.white,
                    child: Image.asset(
                      AssetImagePath.profile2,
                      height: 92,
                      width: 88,
                      fit: BoxFit.fill,
                      color: CustomColors.purpleBrown,
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              const TextVariant(
                data: 'Personal Details',
                color: CustomColors.midBlue,
                fontFamily: FontFamily.quattrocentoSans,
                fontWeight: FontWeight.w700,
                variantType: TextVariantType.headlineSmall,
              ),
              UnderLineTextField(
                focusNode: viewModel.userNameFocusNode,
                controller: viewModel.userNameController,
                textCapitalization: TextCapitalization.sentences,
                hintText:
                    localLanguage?.keyUserName ?? LocaleKeys.userName.tr(),
                hintColor: CustomColors.black,
                color: CustomColors.midBlue,
                onChanged: (value) {
                  viewModel.setUserNameLength(value: value.trim());
                },
                fontWeight: FontWeight.w700,
                fillColor: CustomColors.lightWhite,
                keyboardType: TextInputType.emailAddress,
              ),
              UnderLineTextField(
                controller: viewModel.emailController,
                hintText: localLanguage?.keyEmailId ?? LocaleKeys.emailId.tr(),
                hintColor: CustomColors.greyish,
                color: CustomColors.midBlue,
                fillColor: CustomColors.lightWhite,
                keyboardType: TextInputType.emailAddress,
              ),
              UnderLineTextField(
                textColor: CustomColors.greyish,
                controller: viewModel.phoneController,
                hintText: '${viewModel.getCountryCode() ?? '+91'} - 0000000000',
                alignLabelWithHint: true,
                enabled: false,
                prefix: Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: TextVariant(
                    data: viewModel.getCountryCode() ?? '+91',
                    variantType: TextVariantType.titleMedium,
                    fontFamily: FontFamily.quattrocentoSans,
                    color: CustomColors.greyish,
                  ),
                ),
                hintColor: CustomColors.black,
                color: CustomColors.midBlue,
                fontWeight: FontWeight.w700,
                fillColor: CustomColors.lightWhite,
                keyboardType: TextInputType.emailAddress,
              ),
              Visibility(
                visible: viewModel.localStorage.retrieveString(StorageKey.countryCode) == '+91',
                child: UnderLineTextField(
                  controller: viewModel.panController,
                  hintText: 'Pan Number',
                  hintColor: CustomColors.greyish,
                  color: CustomColors.midBlue,
                  fillColor: CustomColors.lightWhite,
                  keyboardType: TextInputType.emailAddress,
                  onChanged: (value) {},
                  textCapitalization: TextCapitalization.characters,
                  maxLength: 10,
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              const TextVariant(
                data: 'Address',
                color: CustomColors.midBlue,
                fontFamily: FontFamily.quattrocentoSans,
                fontWeight: FontWeight.w700,
                variantType: TextVariantType.headlineSmall,
              ),
              Autocomplete<StatesData>(
                optionsBuilder: (TextEditingValue textEditingValue) {
                  return viewModel.state.searchedList.toList();
                },
                initialValue: viewModel.userNameController.value,
                onSelected: (StatesData option) {
                  viewModel.selectState(option, context);
                  SystemChannels.textInput.invokeMethod('TextInput.hide');
                },
                optionsMaxHeight: 250,
                displayStringForOption: (StatesData option) {
                  return option.stateName ?? '';
                },
                fieldViewBuilder: (BuildContext context,
                    TextEditingController textEditingController,
                    FocusNode focusNode,
                    VoidCallback onSubmit) {
                  return UnderLineTextField(
                    controller: viewModel.stateController.text == ''
                        ? textEditingController
                        : viewModel.stateController,
                    hintText: 'Select state',
                    hintColor: CustomColors.greyish,
                    focusNode: focusNode,
                    color: CustomColors.midBlue,
                    fillColor: CustomColors.lightWhite,
                    keyboardType: TextInputType.emailAddress,
                    onChanged: (value) {
                      viewModel.searchTheState(searchState: value);
                    },
                  );
                },
              ),
              Autocomplete<CityData>(
                optionsBuilder: (TextEditingValue textEditingValue) {
                  return viewModel.state.citySearchedList.toList();
                },
                initialValue: viewModel.cityController.value,
                onSelected: (CityData option) {
                  viewModel.selectCity(option);
                  SystemChannels.textInput.invokeMethod('TextInput.hide');
                },
                optionsMaxHeight: 250,
                displayStringForOption: (CityData option) {
                  return option.cityName ?? '';
                },
                fieldViewBuilder: (BuildContext context,
                    TextEditingController textEditingController,
                    FocusNode focusNode,
                    VoidCallback onSubmit) {
                  return UnderLineTextField(
                    controller: viewModel.cityController.text == ''
                        ? textEditingController
                        : viewModel.cityController,
                    hintText: 'Select city',
                    hintColor: CustomColors.greyish,
                    focusNode: focusNode,
                    color: CustomColors.midBlue,
                    fillColor: CustomColors.lightWhite,
                    keyboardType: TextInputType.emailAddress,
                    onChanged: (value) {
                      viewModel.searchCity(searchString: value);
                    },
                  );
                },
              ),
              UnderLineTextField(
                controller: viewModel.address1Controller,
                hintText: 'Address 1',
                hintColor: CustomColors.greyish,
                color: CustomColors.midBlue,
                fillColor: CustomColors.lightWhite,
                keyboardType: TextInputType.emailAddress,
              ),
              UnderLineTextField(
                controller: viewModel.address2Controller,
                hintText: 'Address 2',
                hintColor: CustomColors.greyish,
                color: CustomColors.midBlue,
                fillColor: CustomColors.lightWhite,
                keyboardType: TextInputType.emailAddress,
              ),
              UnderLineTextField(
                controller: viewModel.areaController,
                hintText: 'Area',
                hintColor: CustomColors.greyish,
                color: CustomColors.midBlue,
                fillColor: CustomColors.lightWhite,
                keyboardType: TextInputType.emailAddress,
              ),
              UnderLineTextField(
                controller: viewModel.pinController,
                hintText: 'PinCode',
                hintColor: CustomColors.greyish,
                color: CustomColors.midBlue,
                fillColor: CustomColors.lightWhite,
                keyboardType: TextInputType.number,
                maxLength: 7,
              ),
              const SizedBox(
                height: 20,
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8.0, vertical: 14.0),
                decoration: BoxDecoration(
                    border: Border.all(color: CustomColors.midBlue),
                    borderRadius: BorderRadius.circular(16)),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const TextVariant(
                          data: 'KYC Status : ',
                          color: CustomColors.midBlue,
                          fontFamily: FontFamily.quattrocentoSans,
                          fontWeight: FontWeight.w700,
                          variantType: TextVariantType.headlineLarge,
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              vertical: 3, horizontal: 7),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              color: viewModel.state.consumerByIdResponse
                                          .consumerDetail?.kycStatusName ==
                                      'Incomplete'
                                  ? Colors.grey
                                  : viewModel.state.consumerByIdResponse
                                              .consumerDetail?.kycStatusName ==
                                          'Rejected'
                                      ? CustomColors.red
                                      : viewModel
                                                  .state
                                                  .consumerByIdResponse
                                                  .consumerDetail
                                                  ?.kycStatusName ==
                                              'Approved'
                                          ? CustomColors.green
                                          : Colors.orangeAccent),
                          child: TextVariant(
                            data: viewModel.state.consumerByIdResponse
                                    .consumerDetail?.kycStatusName ??
                                '',
                            color: CustomColors.black,
                            fontFamily: FontFamily.quattrocentoSans,
                            fontWeight: FontWeight.w700,
                            variantType: TextVariantType.titleMedium,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    const TextVariant(
                      data: '*Please upload file in JPG, PNG and PDF format.',
                      color: CustomColors.black,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w500,
                      variantType: TextVariantType.bodyMedium,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      height: 100,
                      child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: viewModel.state.customDocument
                              .length /*viewModel.state.consumerByIdResponse
                          .consumerDetail?.documents?.length*/
                          ,
                          itemBuilder: (BuildContext context, int index) {
                            return Padding(
                              padding: const EdgeInsets.all(2.0),
                              child: Center(
                                child: Stack(
                                  alignment: Alignment.topRight,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: InkWell(
                                        onTap: () {
                                          Navigator.of(context)
                                              .push(MaterialPageRoute<void>(
                                            builder: (BuildContext context) =>
                                                Scaffold(
                                              body: Center(
                                                child: Hero(
                                                  tag: 'hero-rectangle',
                                                  child: viewModel
                                                              .state
                                                              .customDocument[
                                                                  index]
                                                              .customDocumentType ==
                                                          DocumentType.network
                                                      ? Image.network(
                                                          'https://app.pays.net.in/${viewModel.state.customDocument[index].filePath}',
                                                          fit: BoxFit.cover,
                                                        )
                                                      : Image.file(
                                                          File(viewModel
                                                                  .state
                                                                  .customDocument[
                                                                      index]
                                                                  .filePath ??
                                                              ''),
                                                          fit: BoxFit.cover,
                                                        ),
                                                  // Image.file(
                                                  //   File(viewModel
                                                  //       .imageList[index].path),
                                                  //   fit: BoxFit.cover,
                                                  // ),
                                                ),
                                              ),
                                            ),
                                          ));
                                        },
                                        child: viewModel
                                                    .state
                                                    .customDocument[index]
                                                    .customDocumentType ==
                                                DocumentType.network
                                            ? Image.network(
                                                'https://app.pays.net.in/${viewModel.state.customDocument[index].filePath}',
                                                fit: BoxFit.cover,
                                                height: 120,
                                                width: 67,
                                              )
                                            : Image.file(
                                                File(viewModel
                                                        .state
                                                        .customDocument[index]
                                                        .filePath ??
                                                    ''),
                                                fit: BoxFit.cover,
                                                height: 120,
                                                width: 67,
                                              ),
                                      ),
                                    ),
                                    InkWell(
                                        onTap: () {
                                          if (viewModel
                                                  .state
                                                  .customDocument[index]
                                                  .documentId !=
                                              null) {
                                            viewModel.deleteImage(
                                                viewModel
                                                        .state
                                                        .customDocument[index]
                                                        .documentId ??
                                                    0,
                                                context);
                                          } else {
                                            viewModel.removeImageLocally(
                                                deleteDocument: viewModel.state
                                                    .customDocument[index]);
                                          }
                                        },
                                        child: const Icon(
                                          Icons.cancel_outlined,
                                          color: CustomColors.black,
                                        ))
                                  ],
                                ),
                              ),
                            );
                          }),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        BackGroundColorButton(
                          width: MediaQuery.of(context).size.width / 2.6,
                          btnName:
                              localLanguage?.keyUpdateFile?.toUpperCase() ??
                                  'From Gallery'.toUpperCase(),
                          center: true,
                          isEnable: viewModel.state.userNameLength > 2,
                          load: false,
                          onTap: () {
                            viewModel.gallery();
                          },
                          variantType: TextVariantType.titleMedium,
                          fontFamily: FontFamily.quattrocentoSans,
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        BackGroundColorButton(
                          width: MediaQuery.of(context).size.width / 2.6,
                          btnName:
                              localLanguage?.keyOpenCamera?.toUpperCase() ??
                                  'Open Camera'.toUpperCase(),
                          center: true,
                          isEnable: viewModel.state.userNameLength > 2,
                          load: false,
                          onTap: () {
                            viewModel.camera();
                          },
                          variantType: TextVariantType.titleMedium,
                          fontFamily: FontFamily.quattrocentoSans,
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    BackGroundColorButton(
                      width: MediaQuery.of(context).size.width,
                      btnName: localLanguage?.keyUpdate ??
                          LocaleKeys.update.tr().toUpperCase(),
                      center: true,
                      isEnable: viewModel.state.userNameLength > 2,
                      load: viewModel.state.load,
                      onTap: () {
                        viewModel.updateProfile(context);
                      },
                      variantType: TextVariantType.titleMedium,
                      fontFamily: FontFamily.quattrocentoSans,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: BackGroundColorButton(
                  width: double.infinity,
                  backgroundColor: CustomColors.red,
                  btnName: localLanguage?.keyDelete ??
                      LocaleKeys.delete.tr().toUpperCase(),
                  center: true,
                  load: false,
                  isEnable: true,
                  onTap: () {
                    viewModel.showDeleteConfirmDialog(context);
                  },
                  variantType: TextVariantType.titleMedium,
                  fontFamily: FontFamily.quattrocentoSans,
                ),
              ),
              const SizedBox(
                height: 30,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
