import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/gen/assets.gen.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_indication.screen.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// NetworkScreen
///
@RoutePage(name: 'networkScreen')
class NetworkScreen extends StatelessWidget {
  ///
  const NetworkScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        List<ConnectivityResult> connectivityResult =
            await (Connectivity().checkConnectivity());
        if (connectivityResult .contains( ConnectivityResult.none)) {
          return false;
        } else {
          return true;
        }
      },
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: IndicationScreen(
              image: Assets.images.group339.path,
              title: localLanguage?.keyYouAreOffline ??
                  LocaleKeys.youAreOffline.tr(),
              subTitle: localLanguage?.keyYourNoConnectedInInternet ??
                  LocaleKeys
                      .yourAreNotConnectedToTheInternetPleaseConnectAndTryAgain
                      .tr(),
              buttonName: localLanguage?.keyReload ??
                  LocaleKeys.reload.tr().toUpperCase(),
              onTap: () async {
                List<ConnectivityResult> connectivityResult =
                    await (Connectivity().checkConnectivity());
                if (connectivityResult.contains( ConnectivityResult.none)) {
                  confirmationDialog(context,
                      showCancelButton: false,
                      title: 'Network',
                      subTitle: 'Please check your network',
                      doneButtonText: LocaleKeys.ok.tr(), onTap: () {
                    AutoRouter.of(context).maybePop();
                  });
                } else {
                  AutoRouter.of(context).maybePop();
                }
              },
            ),
          ),
        ),
      ),
    );
  }
}
