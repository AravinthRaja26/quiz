import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_textform_field.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/bank_transfer/bank_transfer.provider.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/bank_transfer/bank_transfer.viewmodel.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

///
/// Bank Transfer screen
///
@RoutePage(name: 'bankTransferScreen')
class BankTransferScreen extends StatelessWidget {
  /// BankTransfer screen constructor
  const BankTransferScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BankTransferProvider(
      builder: (BuildContext context, _) {
        return Builder(builder: (BuildContext context) {
          BankTransferViewModel viewModel =
              BaseViewModel.watch<BankTransferViewModel>(context);
          return Scaffold(
              key: viewModel.scaffoldKey,
              backgroundColor: Colors.white,
              appBar: AppBar(
                  centerTitle: true,
                  title: TextVariant(
                    data: localLanguage?.keyPointTransfer ?? 'Transfer Points',
                    color: CustomColors.purpleBrown,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.headlineMedium,
                    fontWeight: FontWeight.w700,
                  )),
              body: const _BodyScreen());
        });
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double scaleFactor = MediaQuery.of(context).textScaleFactor;

    BankTransferViewModel vm =
        BaseViewModel.watch<BankTransferViewModel>(context);
    return Padding(
      padding: const EdgeInsets.all(18.0),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            TextVariant(
              data: localLanguage?.keyMobileNumberDealer ??
                  'Enter the mobile number of Dealer',
              color: Colors.black,
              fontFamily: FontFamily.quattrocentoSans,
              fontWeight: FontWeight.w400,
              variantType: TextVariantType.titleLarge,
            ),
            const SizedBox(
              height: 10,
            ),
            UnderLineTextField(
              hintText: localLanguage?.keyEnterHere ?? 'Enter here *',
              hintColor: CustomColors.greyish,
              fontWeight: FontWeight.w400,
              fontFamily: FontFamily.quattrocentoSans,
              color: CustomColors.midBlue,
              controller: vm.mobileController,
              maxLength: 10,
              prefixIcon: Padding(
                padding: const EdgeInsets.only(top:13.0,left: 8.0),
                child: Text(vm.getCountyCode(),style: TextStyle(
                  color: CustomColors.greyish,
                  fontSize: 16/scaleFactor,
                  fontWeight: FontWeight.w400,
                  fontFamily: FontFamily.quattrocentoSans,)),
              ),
              focusNode: vm.mobileFocusNode,
              enabled: vm.state.isKycUpdated,
              keyboardType: const TextInputType.numberWithOptions(
                  decimal: true, signed: false),
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.digitsOnly,
              ],
              onChanged: (String value) {
                vm.enableLoad(value);
              },
              validator: (dynamic value) {
                return null;
              },
              fillColor: CustomColors.lightWhite,
            ),
            const SizedBox(
              height: 15,
            ),
            TextVariant(
              data: localLanguage?.keyPointsTranfer ??
                  'Enter the points to transfer',
              color: Colors.black,
              fontFamily: FontFamily.quattrocentoSans,
              fontWeight: FontWeight.w400,
              variantType: TextVariantType.titleLarge,
            ),
            const SizedBox(
              height: 10,
            ),
            UnderLineTextField(
              hintText: '0.00 *',
              hintColor: CustomColors.greyish,
              enabled: vm.state.isKycUpdated,
              fontWeight: FontWeight.w400,
              fontFamily: FontFamily.quattrocentoSans,
              color: CustomColors.midBlue,
              controller: vm.pointController,
              maxLength: 6,
              focusNode: vm.pointFocusNode,
              keyboardType: const TextInputType.numberWithOptions(
                  decimal: true, signed: false),
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.digitsOnly,
                CurrencyTextInputFormatter.currency(symbol: '', decimalDigits: 0),
              ],
              onChanged: (String value) {
                vm.amountValidate(value, context);
              },
              validator: (dynamic value) {
                return null;
              },
              fillColor: CustomColors.lightWhite,
            ),
            const SizedBox(
              height: 30,
            ),
            BackGroundColorButton(
              isEnable: vm.state.isShimmer,
              load: false,
              width: MediaQuery.of(context).size.width,
              btnName: localLanguage?.keyTransffer ?? 'TRANSFER',
              center: true,
              onTap: () async {
                vm.checkLocation(context);
              },
              variantType: TextVariantType.titleMedium,
              fontFamily: FontFamily.quattrocentoSans,
            ),
            const SizedBox(
              height: 30,
            ),
            Container(
              decoration: BoxDecoration(
                color: CustomColors.midBlue.withOpacity(0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  TextVariant(
                    data: localLanguage?.keyNote ?? 'NOTE *',
                    color: CustomColors.white,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.bodyMedium,
                    fontWeight: FontWeight.w700,
                  ),
                  const SizedBox(
                    height: 6,
                  ),
                  TextVariant(
                    data: localLanguage?.keyKycBenefits ??
                        'As per RBI mandate you need to do full KYC (Know your customer) to receive all benefits:',
                    color: CustomColors.white,
                    fontFamily: FontFamily.quattrocentoSans,
                    fontWeight: FontWeight.w600,
                    variantType: TextVariantType.bodyMedium,
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
