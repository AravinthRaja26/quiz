import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/config/application.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/infrastructure/utils/app.text.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/listaki_web_view.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/about/about_view_model.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/about/about_view_model_provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

///
/// About screen
///
@RoutePage(name: 'aboutScreen')
class AboutScreen extends StatefulWidget {
  /// AboutScreen screen constructor
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen>
    with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return AboutUsProvider(
      builder: (BuildContext context, Widget? child) {
        return Scaffold(
            backgroundColor: CustomColors.white,
            appBar: AppBar(
                centerTitle: true,
                title: TextVariant(
                  data: localLanguage?.keyAboutUs ?? LocaleKeys.aboutUs.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                )),
            body: const _BodyScreen());
      },
      vsync: this,
    );
  }
}

class _BodyScreen extends StatefulWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  State<_BodyScreen> createState() => _BodyScreenState();
}

class _BodyScreenState extends State<_BodyScreen>
    with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    AboutUsViewModel viewModel = BaseViewModel.watch<AboutUsViewModel>(context);

    return DefaultTabController(
      length: 2,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            color: CustomColors.lightWhite,
            constraints: const BoxConstraints.expand(height: 65),
            child: TabBar(
                controller: viewModel.tabController,
                indicatorColor: CustomColors.midBlue,
                indicatorWeight: 1,
                indicatorSize: TabBarIndicatorSize.label,
                labelColor: CustomColors.midBlue,
                automaticIndicatorColorAdjustment: true,
                tabs: <Widget>[
                  Tab(
                    child: TextVariant(
                      data: localLanguage?.keyAboutLitaski ??
                          LocaleKeys.aboutLitaski.tr(),
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w700,
                      color: viewModel.state.currentIndex == 0
                          ? CustomColors.midBlue
                          : CustomColors.greyishBrown,
                      variantType: TextVariantType.titleLarge,
                    ),
                  ),
                  Tab(
                    child: TextVariant(
                      data: localLanguage?.keyAboutTheApp ??
                          LocaleKeys.aboutTheApp.tr(),
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w700,
                      color: viewModel.state.currentIndex == 1
                          ? CustomColors.midBlue
                          : CustomColors.greyishBrown,
                      variantType: TextVariantType.titleLarge,
                    ),
                  ),
                ]),
          ),
          Expanded(
            child: viewModel.state.currentIndex == 1
                ? const AboutAppTheAppWidget()
                : const AboutLitaskiWidget(),
            // AboutAppTheAppWidget(),
          )
        ],
      ),
    );
  }
}

///
class AboutLitaskiWidget extends StatelessWidget {
  ///
  const AboutLitaskiWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    AboutUsViewModel viewModel = BaseViewModel.watch<AboutUsViewModel>(context);

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: /* Center(
          child: Text('No data'),
        )*/
          // don`t remove this code
          Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Image.asset(
            AssetImagePath.asLogo,
            fit: BoxFit.fill,
          ),
          const SizedBox(
            height: 8,
          ),
          Flexible(
            child: NikitWebView(
              url: viewModel.aboutUsWebUrl(),
            ),
          ),
          const SizedBox(
            height: 8,
          ),
          BackGroundColorButton(
            width: MediaQuery.of(context).size.width,
            btnName: localLanguage?.keyVisitOurWebsite ??
                LocaleKeys.visitOurWebSite.tr().toUpperCase(),
            center: true,
            isEnable: true,
            onTap: () {
              launchUrl(Uri.parse('http://nikitchem.in/'),
                  mode: LaunchMode.externalApplication);
            },
            variantType: TextVariantType.titleMedium,
            fontFamily: FontFamily.quattrocentoSans,
          ),
        ],
      ),
    );
  }
}

///
class AboutAppTheAppWidget extends StatelessWidget {
  ///
  const AboutAppTheAppWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    AboutUsViewModel viewModel = BaseViewModel.watch<AboutUsViewModel>(context);
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child:
          /*Center(
        child: Text('No data'),
      )*/
          // don`t remove this code
          Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          RichText(
            textAlign: TextAlign.center,
            text: TextSpan(
              // Note: Styles for TextSpans must be explicitly defined.
              // Child text spans will inherit styles from parent
              style: const TextStyle(
                fontSize: 14.0,
                color: Colors.black,
              ),
              children: <TextSpan>[
                const TextSpan(
                    text: 'App version : ',
                    style: TextStyle(
                        fontFamily: FontFamily.quattrocentoSans,
                        fontSize: 18,
                        color: CustomColors.midBlue,
                        fontWeight: FontWeight.w700)),
                TextSpan(
                    text: viewModel.version,
                    style: const TextStyle(
                      fontSize: 14,
                      color: CustomColors.purpleBrown,
                      fontFamily: FontFamily.quattrocentoSans,
                    )),
              ],
            ),
          ),
          appConfig?.isShowBuildDate == true
              ? RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    // Note: Styles for TextSpans must be explicitly defined.
                    // Child text spans will inherit styles from parent
                    style: const TextStyle(
                      fontSize: 14.0,
                      color: Colors.black,
                    ),
                    children: <TextSpan>[
                      const TextSpan(
                          text: 'Build on : ',
                          style: TextStyle(
                              fontFamily: FontFamily.quattrocentoSans,
                              fontSize: 18,
                              color: CustomColors.midBlue,
                              fontWeight: FontWeight.w700)),
                      TextSpan(
                          text: AppText.buildOn,
                          style: const TextStyle(
                            fontSize: 14,
                            color: CustomColors.purpleBrown,
                            fontFamily: FontFamily.quattrocentoSans,
                          )),
                    ],
                  ),
                )
              : const SizedBox(),
          Expanded(
              child: NikitWebView(
            url: viewModel.aboutAppWebUrl(),
          )),
        ],
      ),
    );
  }
}
