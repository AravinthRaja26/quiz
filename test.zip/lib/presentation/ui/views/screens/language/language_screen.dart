import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/language/language_viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/language/language_viewmodel_provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
@RoutePage(name: 'languageScreen')
class LanguageScreen extends StatelessWidget {
  ///
  const LanguageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LanguageViewModelProvider(
      builder: (BuildContext context, Widget? child) {
        return Builder(builder: (BuildContext context) {
          LanguageViewModel viewModel =
              BaseViewModel.watch<LanguageViewModel>(context);
          return Scaffold(
            key: viewModel.key,
            backgroundColor: Colors.white,
            appBar: AppBar(
                centerTitle: true,
                title: TextVariant(
                  data: localLanguage?.keyLanguageSettings ??
                      LocaleKeys.languageSettings.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                )),
            persistentFooterButtons: <Widget>[
              BackGroundColorButton(
                isEnable: viewModel.state.buttonEnable,
                width: MediaQuery.of(context).size.width,
                onTap: () {
                  viewModel.setLanguage(context);
                },
                btnName: localLanguage?.keyChooseLanguage ?? 'Choose Language',
                center: true,
                variantType: TextVariantType.titleMedium,
                fontFamily: FontFamily.quattrocentoSans,
                load: viewModel.state.buttonLoad,
              )
            ],
            body: const _LanguageScreenBody(),
          );
        });
      },
    );
  }
}

class _LanguageScreenBody extends StatelessWidget {
  const _LanguageScreenBody();

  @override
  Widget build(BuildContext context) {
    LanguageViewModel viewModel =
        BaseViewModel.watch<LanguageViewModel>(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(left: 16.0),
          child: TextVariant(
            data: localLanguage?.keyChangeLanguage ??
                LocaleKeys.changeLanguage.tr(),
            color: CustomColors.midBlue,
            fontFamily: FontFamily.quattrocentoSans,
            variantType: TextVariantType.titleMedium,
          ),
        ),
        viewModel.state.screenLoad == true
            ? Center(
                child: Padding(
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height / 3),
                  child: const CircularProgressIndicator(
                    color: CustomColors.midBlue,
                  ),
                ),
              )
            : Expanded(
                child: viewModel.state.languages.languageList?.isNotEmpty ==
                        true
                    ? GridView.builder(
                        shrinkWrap: true,
                        padding: const EdgeInsets.all(16.0),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                                mainAxisExtent: 91,
                                crossAxisCount: 2,
                                crossAxisSpacing: 8.0,
                                mainAxisSpacing: 8.0),
                        itemCount:
                            viewModel.state.languages.languageList?.length ?? 0,
                        itemBuilder: (BuildContext context, int index) {
                          return _LanguageItem(
                            languageCode: viewModel.state.languages
                                .languageList?[index].languageCode,
                            title: viewModel.state.languages
                                .languageList?[index].languageName,
                            subTitle: viewModel
                                .state.languages.languageList?[index].subTitle,
                          );
                        })
                    : Center(
                        child: TextVariant(
                            data: localLanguage?.keyNoDataAvailable ?? '',
                            variantType: TextVariantType.bodyLarge,
                            color: CustomColors.purpleBrown,
                            fontFamily: FontFamily.quattrocentoSans),
                      )),
      ],
    );
  }
}

class _LanguageItem extends StatelessWidget {
  final String? title;
  final String? subTitle;
  final String? languageCode;

  const _LanguageItem({this.title, this.subTitle, this.languageCode});

  @override
  Widget build(BuildContext context) {
    LanguageViewModel viewModel =
        BaseViewModel.watch<LanguageViewModel>(context);

    return InkWell(
      onTap: () {
        viewModel.selectLanguage(language: languageCode);
      },
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 8,
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
            borderRadius: const BorderRadius.all(Radius.circular(6.0))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left: 12.0, top: 12),
                  child: TextVariant(data: title ?? ''),
                ),
                const Spacer(),
                Radio<String>(
                  value: languageCode ?? 'en',
                  groupValue: viewModel.state.selectedLanguage,
                  activeColor: CustomColors.midBlue,
                  onChanged: (String? value) {
                    viewModel.selectLanguage(language: value);
                  },
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 12.0),
              child: TextVariant(
                data: subTitle ?? 'English',
                fontFamily: FontFamily.quattrocentoSans,
                fontWeight: FontWeight.w400,
                fontSize: 10.0,
              ),
            )
          ],
        ),
      ),
    );
  }
}
