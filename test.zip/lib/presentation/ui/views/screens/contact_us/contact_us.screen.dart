import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_textform_field.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/contact_us/contact_us_viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/contact_us/contact_us_viewmodel_provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// ContactScreen
///
@RoutePage(name: 'contactScreen')
class ContactScreen extends StatelessWidget {
  /// ContactScreen screen constructor
  const ContactScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ContactUsProvider(
      builder: (BuildContext context, Widget? child) {
        return Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
                centerTitle: true,
                title: TextVariant(
                  data:
                      localLanguage?.keyContactUs ?? LocaleKeys.contactUs.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                )),
            body: const _BodyScreen());
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    ContactUsViewModel viewModel =
        BaseViewModel.watch<ContactUsViewModel>(context);

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            TextVariant(
              data: localLanguage?.keyHowCanWeHelp ??
                  LocaleKeys.howCanWeHelp.tr(),
              color: CustomColors.midBlue,
              fontFamily: FontFamily.quattrocentoSans,
              fontWeight: FontWeight.w700,
              variantType: TextVariantType.headlineSmall,
            ),
            const SizedBox(
              height: 10,
            ),
            TextVariant(
              data: localLanguage?.keyFillOutDetails ??
                  LocaleKeys.fillOutTheDetailsAndWeShallGetBackToYou.tr(),
              color: CustomColors.black,
              fontFamily: FontFamily.quattrocentoSans,
              variantType: TextVariantType.titleMedium,
              fontWeight: FontWeight.w700,
            ),
            const SizedBox(
              height: 15,
            ),
            UnderLineTextField(
              hintText:
                  '${localLanguage?.keyEmailId ?? LocaleKeys.emailId.tr()} *',
              hintColor: CustomColors.greyish,
              color: CustomColors.midBlue,
              controller: viewModel.emailController,
              onChanged: (String value) {
                viewModel.enableLoad(value);
              },
              validator: (String? value) {
                return null;
              },
              fillColor: CustomColors.lightWhite,
              keyboardType: TextInputType.emailAddress,
            ),
            UnderLineTextField(
              hintText:
                  localLanguage?.keyPhoneNumber ?? LocaleKeys.phoneNumber.tr(),
              hintColor: CustomColors.greyish,
              controller: viewModel.phoneController,
              maxLength: 10,
              color: CustomColors.midBlue,
              onChanged: (String value) {
                viewModel.enableLoad(value);
              },
              validator: (String? value) {
                return null;
              },
              fillColor: CustomColors.lightWhite,
              keyboardType: TextInputType.emailAddress,
            ),
            MessageUnderLineTextField(
              maxLines: 6,
              controller: viewModel.messageController,
              textAlign: TextAlign.start,
              hintText:
                  '${localLanguage?.keyMessage ?? LocaleKeys.message.tr()} *',
              hintColor: CustomColors.greyish,
              maxLength: 1000,
              color: CustomColors.midBlue,
              onChanged: (String value) {
                viewModel.enableLoad(value);
              },
              alignLabelWithHint: true,
              validator: (dynamic value) {
                return null;
              },
              fillColor: CustomColors.lightWhite,
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(
              height: 30,
            ),
            BackGroundColorButton(
              width: MediaQuery.of(context).size.width,
              btnName:
                  localLanguage?.keySend ?? LocaleKeys.send.tr().toUpperCase(),
              center: true,
              isEnable: viewModel.state.isShimmer,
              load: viewModel.state.isEnabled,
              backgroundColor: viewModel.state.isShimmer == false
                  ? CustomColors.greyish
                  : CustomColors.midBlue,
              onTap: () {
                viewModel.checkValidate(context: context);
              },
              variantType: TextVariantType.titleMedium,
              fontFamily: FontFamily.quattrocentoSans,
            ),
          ],
        ),
      ),
    );
  }
}
