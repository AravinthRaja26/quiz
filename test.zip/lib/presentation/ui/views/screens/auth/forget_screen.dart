import 'package:auto_route/annotations.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_bottom_sheet.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/login/login_viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/login/login_viewmodel_provider.dart';

///

@RoutePage(name: 'forgetPasswordScreen')
class ForgetPasswordScreen extends StatelessWidget {
  ///
  const ForgetPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LoginProvider(builder: (BuildContext context, Widget? child) {
      return Builder(builder: (BuildContext context) {
        LoginViewModel viewModel = BaseViewModel.watch(context);
        return Scaffold(
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
              centerTitle: true,
              title: const TextVariant(
                data: '',
                color: CustomColors.purpleBrown,
                fontFamily: FontFamily.quattrocentoSans,
                variantType: TextVariantType.headlineMedium,
                fontWeight: FontWeight.w700,
              )),
          backgroundColor: Colors.white,
          body: const _ForgetPasswordScreenBody(),
        );
      });
    });
  }
}

class _ForgetPasswordScreenBody extends StatelessWidget {
  const _ForgetPasswordScreenBody();

  @override
  Widget build(BuildContext context) {
    LoginViewModel viewModel = BaseViewModel.watch<LoginViewModel>(context);

    return SizedBox(
      height: MediaQuery.of(context).size.height,
      child: Form(
        key: viewModel.form,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(
                  right: 16.0, left: 16.0, top: 27.0, bottom: 12),
              child: TextVariant(
                data: '${localLanguage?.keyResetMpin ?? 'Reset MPin'} ?',
                color: CustomColors.purpleBrown,
                fontFamily: FontFamily.playfairDisplay,
                variantType: TextVariantType.displayMedium,
                fontWeight: FontWeight.w600,
              ),
            ),
            Padding(
              padding:
                  const EdgeInsets.only(top: 24.0, right: 16.0, left: 16.0),
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: const BorderRadius.all(Radius.circular(6)),
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 3,
                        blurRadius: 7,
                        offset: const Offset(0, 2),
                      ),
                    ]),
                child: TextFormField(
                  cursorColor: CustomColors.midBlue,
                  maxLength: 10,
                  enabled: !viewModel.state.isLoad,
                  textInputAction: TextInputAction.done,
                  keyboardType: const TextInputType.numberWithOptions(
                      decimal: true, signed: false),
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.digitsOnly
                  ],
                  controller: viewModel.phoneController,
                  onChanged: (String value) {
                    viewModel.setPhoneNumberLength(value: value);
                  },
                  style: const TextStyle(
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w400),
                  decoration: InputDecoration(
                      alignLabelWithHint: true,
                      fillColor: Colors.white,
                      prefixIcon: const Padding(
                        padding: EdgeInsets.only(left: 8.0, right: 8.0),
                        child: TextVariant(
                            data: '+977',
                            fontSize: 16,
                            color: CustomColors.midGreen,
                            fontFamily: FontFamily.quattrocentoSans,
                            variantType: TextVariantType.titleMedium),
                      ),
                      counterText: '',
                      prefixIconConstraints:
                          const BoxConstraints(minHeight: 0, minWidth: 0),
                      hintText: localLanguage?.keyEnterMobileNumber ??
                          'Enter your mobile number',
                      hintStyle: const TextStyle(
                        fontSize: 16,
                        color: CustomColors.greyish,
                        fontWeight: FontWeight.w400,
                        fontFamily: FontFamily.quattrocentoSans,
                      ),
                      contentPadding: const EdgeInsets.only(
                          top: 12, left: 8, right: 8.0, bottom: 12.0),
                      border: const OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.all(Radius.circular(6)))),
                ),
              ),
            ),
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16.0, vertical: 26.0),
                child: AppButton(
                  load: viewModel.state.isLoad,
                  width: MediaQuery.of(context).size.width,
                  btnName:  localLanguage?.keySubmit ?? 'SUBMIT',
                  center: true,
                  isEnable: viewModel.state.phoneNumberLength == 10,
                  onTap: () {
                    viewModel.resetMPin(context);
                  },
                  variantType: TextVariantType.titleMedium,
                  fontFamily: FontFamily.quattrocentoSans,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/*///

@RoutePage(name: 'loginScreen')
class LoginScreen extends StatelessWidget {
  ///
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LoginProvider(builder: (BuildContext context, Widget? child) {
      return Builder(builder: (BuildContext context) {
        return const Scaffold(
          resizeToAvoidBottomInset: false,
          backgroundColor: Colors.white,
          body: _LoginScreenBody(),
        );
      });
    });
  }
}

class _LoginScreenBody extends StatelessWidget {
  const _LoginScreenBody();

  @override
  Widget build(BuildContext context) {
    LoginViewModel viewModel = BaseViewModel.watch<LoginViewModel>(context);

    return SizedBox(
      height: MediaQuery.of(context).size.height,
      child: Form(
        key: viewModel.form,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                decoration: const BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(30),
                        bottomLeft: Radius.circular(30))),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(top: 68),
                      child: Align(
                        alignment: Alignment.topRight,
                        child: Padding(
                            padding: const EdgeInsets.only(
                              right: 18.0,
                              left: 18.0,
                            ),
                            child: AppTextButton(
                              onTap: () {
                                viewModel.navigateToChooseLanguage(context: context);
                              },
                              isShowArrowIcon: true,
                              btnName: localLanguage?.keyChangeLanguage ??
                                  LocaleKeys.changeLanguage.tr(),
                            )),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 18.0, right: 18.0, top: 2.0),
                      child: Image.asset(AssetImagePath.asLogo),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 18.0, left: 18.0, top: 30.0),
                      child: TextVariant(
                        data: localLanguage?.keyWelcome != null &&
                                localLanguage?.keyLitaski != null
                            ? '${localLanguage?.keyWelcome}\n${localLanguage?.keyLitaski}'
                            : LocaleKeys.welcomeToLitaski.tr(),
                        color: CustomColors.white,
                        fontFamily: FontFamily.playfairDisplay,
                        variantType: TextVariantType.displayMedium,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 18.0, left: 18.0, top: 30.0),
                      child: TextVariant(
                        data: localLanguage?.keyGetYouStarted ??
                            LocaleKeys.getYouStarted.tr(),
                        color: CustomColors.white,
                        fontFamily: FontFamily.quattrocentoSans,
                        variantType: TextVariantType.bodyMedium,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 18.0, left: 18.0, top: 22.0),
                      child: TextVariant(
                        data: localLanguage?.keyEnterMobileNumber ??
                            LocaleKeys.enterYourMobileNo.tr(),
                        color: CustomColors.white,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontSize: 14,
                        variantType: TextVariantType.bodyMedium,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 18.0, left: 18.0),
                      child: TextFormField(
                        maxLength: 10,
                        enabled: !viewModel.state.isLoad,
                        textInputAction: TextInputAction.done,
                        keyboardType: const TextInputType.numberWithOptions(
                            decimal: true, signed: false),
                        inputFormatters: <TextInputFormatter>[
                          FilteringTextInputFormatter.digitsOnly
                        ],
                        controller: viewModel.phoneController,
                        onChanged: (String value) {
                          viewModel.setPhoneNumberLength(value: value);
                        },
                        cursorColor: CustomColors.white,
                        style: const TextStyle(
                            fontFamily: FontFamily.quattrocentoSans,
                            color: Colors.white,
                            fontWeight: FontWeight.w400),
                        decoration: InputDecoration(
                          alignLabelWithHint: true,
                          fillColor: Colors.white,
                          prefixIcon: const Padding(
                            padding:
                                EdgeInsets.only(left: 8.0, right: 8.0, top: 6),
                            child: TextVariant(
                                data: '+ 91 ',
                                fontSize: 18,
                                color: CustomColors.white,
                                fontFamily: FontFamily.quattrocentoSans,
                                variantType: TextVariantType.titleMedium),
                          ),
                          counterText: '',
                          prefixIconConstraints:
                              const BoxConstraints(minHeight: 0, minWidth: 0),
                          hintText: localLanguage?.keyEnterMobileNumber ??
                              'Enter your mobile number',
                          hintStyle: const TextStyle(
                            fontSize: 18,
                            color: CustomColors.white,
                            fontWeight: FontWeight.w400,
                            fontFamily: FontFamily.quattrocentoSans,
                          ),
                          border: const UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white)),
                          disabledBorder: const UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white)),
                          enabledBorder: const UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white)),
                          focusedBorder: const UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white)),
                          contentPadding: const EdgeInsets.only(
                              top: 12, left: 8, right: 8.0, bottom: 12.0),
                        ),
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 18.0, right: 18.0, top: 40.0),
                        child: AppButton(
                          isGoIconShow: true,
                          isBackgroundColorWhite: true,
                          load: viewModel.state.isLoad,
                          width: MediaQuery.of(context).size.width,
                          btnName: localLanguage?.keyGetOtp ??
                              LocaleKeys.getOTP.tr().toUpperCase(),
                          center: true,
                          isEnable: viewModel.state.phoneNumberLength == 10,
                          onTap: () {
                            viewModel.checkValidate(context: context);
                          },
                          variantType: TextVariantType.titleMedium,
                          fontFamily: FontFamily.quattrocentoSans,
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 60.0,
                    )
                  ],
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Image.asset(
                  AssetImagePath.phoneLoginImage,
                  width: MediaQuery.of(context).size.width,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}*/
