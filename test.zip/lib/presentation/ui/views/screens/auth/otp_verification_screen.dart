import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_outline_button.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/login/otp_verification_provider.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/login/otp_virification_viewmodel.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pinput/pinput.dart';

///
@RoutePage(name: 'otpVerificationScreen')
class OtpVerificationScreen extends StatelessWidget {
  ///
  final String? phoneNumber;

  ///
  const OtpVerificationScreen({super.key, this.phoneNumber});

  @override
  Widget build(BuildContext context) {
    return OtpVerificationProvider(
      builder: (BuildContext context, Widget? child) {
        return Builder(builder: (BuildContext context) {
          return Builder(builder: (BuildContext context) {
            OtpVerificationVieModel viewModel =
                BaseViewModel.watch<OtpVerificationVieModel>(context);
            return Scaffold(
              resizeToAvoidBottomInset: false,
              backgroundColor: Colors.white,
              appBar: AppBar(
                leadingWidth: 80,
                toolbarHeight: 80,
                leading: Row(
                  children: <Widget>[
                    const SizedBox(
                      width: 16.0,
                    ),
                    Image.asset(AssetImagePath.asLogo),
                  ],
                ),
                actions: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(right: 16.0),
                    child: AppOutlineButton(
                      onTap: () {
                        viewModel.navigationToChangeLanguage(context: context);
                      },
                      text: localLanguage?.keyChangeLanguage ??
                          LocaleKeys.changeLanguage.tr(),
                      trailingPath: AssetImagePath.downArrow,
                    ),
                  ),
                ],
              ),
              body: const _OtpVerificationScreen(),
            );
          });
        });
      },
      phoneNumber: phoneNumber,
    );
  }
}

class _OtpVerificationScreen extends StatelessWidget {
  const _OtpVerificationScreen();

  @override
  Widget build(BuildContext context) {
    OtpVerificationVieModel viewModel =
        BaseViewModel.watch<OtpVerificationVieModel>(context);
    return SizedBox(
      height: MediaQuery.of(context).size.height,
      child: Form(
        key: viewModel.form,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding:
                  const EdgeInsets.only(right: 16.0, left: 16.0, top: 27.0),
              child: TextVariant(
                data: localLanguage?.keyOtp != null &&
                        localLanguage?.keyVerification != null
                    ? '${localLanguage?.keyOtp}\n${localLanguage?.keyVerification}'
                    : LocaleKeys.OTPVerification.tr(),
                color: CustomColors.purpleBrown,
                fontFamily: FontFamily.playfairDisplay,
                variantType: TextVariantType.displayMedium,
                fontWeight: FontWeight.w600,
              ),
            ),
            Padding(
              padding:
                  const EdgeInsets.only(right: 16.0, left: 16.0, top: 14.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  TextVariant(
                    data:
                        localLanguage?.keyOtpSent ?? LocaleKeys.hasSendOTP.tr(),
                    color: CustomColors.purpleBrown,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.bodyMedium,
                  ),
                  TextVariant(
                    data:
                        ' +${91} ${viewModel.localStorage.retrieveString(StorageKey.userPhoneNumber).toString()}',
                    color: CustomColors.purpleBrown,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.bodyMedium,
                  ),
                ],
              ),
            ),
            Padding(
                padding:
                    const EdgeInsets.only(top: 14.0, right: 16.0, left: 16.0),
                child: Pinput(
                  controller: viewModel.otpController,
                  keyboardType: const TextInputType.numberWithOptions(
                      decimal: true, signed: false),
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.digitsOnly
                  ],
                  enabled: !viewModel.state.load,
                  onChanged: (String value) {
                    viewModel.setOtpLength(value: value);
                  },
                  defaultPinTheme: PinTheme(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.2),
                              spreadRadius: 3,
                              blurRadius: 7,
                              offset: const Offset(0, 2),
                            ),
                          ],
                          borderRadius: BorderRadius.circular(6.0)),
                      height: 60.0,
                      width: MediaQuery.of(context).size.width,
                      textStyle: const TextStyle(
                          color: CustomColors.midGreen,
                          fontFamily: FontFamily.quattrocentoSans,
                          fontWeight: FontWeight.w700,
                          fontSize: 20.0)),
                )),
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16.0, vertical: 26.0),
              child: AppButton(
                width: MediaQuery.of(context).size.width,
                btnName: localLanguage?.keyValidate ??
                    LocaleKeys.validate.tr().toUpperCase(),
                center: true,
                isEnable: viewModel.state.otpLength == 4,
                load: viewModel.state.load,
                onTap: () {
                  if (viewModel.form.currentState!.validate()) {
                    viewModel.otpVerificationCall(context: context);
                  }
                },
                variantType: TextVariantType.titleMedium,
                fontFamily: FontFamily.quattrocentoSans,
              ),
            ),
            Padding(
              padding:
                  const EdgeInsets.only(bottom: 18.0, left: 16.0, right: 16.0),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Wrap(
                      children: <Widget>[
                        TextVariant(
                          data: localLanguage?.keyGetIt ??
                              LocaleKeys.didNotGetIt.tr(),
                          variantType: TextVariantType.bodyMedium,
                          fontFamily: FontFamily.quattrocentoSans,
                          color: CustomColors.purpleBrown,
                        ),
                      ],
                    ),
                    Row(
                      children: <Widget>[
                        GestureDetector(
                          onTap: viewModel.state.reSendButtonEnable
                              ? () {
                                  viewModel.reSendGetOtp(context: context);
                                }
                              : null,
                          child: TextVariant(
                            data: localLanguage?.keyResendCode ??
                                LocaleKeys.resendCode.tr(),
                            color: viewModel.state.reSendButtonEnable
                                ? CustomColors.midGreen
                                : CustomColors.greyish,
                            variantType: TextVariantType.bodyMedium,
                            fontFamily: FontFamily.quattrocentoSans,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        viewModel.state.reSendButtonEnable == false
                            ? TweenAnimationBuilder<Duration>(
                                duration: const Duration(minutes: 3),
                                tween: Tween<Duration>(
                                    begin: const Duration(minutes: 3),
                                    end: Duration.zero),
                                onEnd: () {
                                  viewModel.enableResendCode();
                                },
                                builder: (BuildContext context, Duration value,
                                    Widget? child) {
                                  final int minutes = value.inMinutes;

                                  final int seconds = value.inSeconds % 60;
                                  Object secondsTime =
                                      seconds > 9 ? seconds : '0$seconds';
                                  return Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 5),
                                      child: Text('${0}$minutes:$secondsTime',
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                              color: CustomColors.midGreen,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18)));
                                })
                            : const SizedBox()
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Center(
                child: Image.asset(
                  AssetImagePath.otpVerificationImage,
                  fit: BoxFit.fill,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

/*///
@RoutePage<String>(name: 'otpVerificationScreen')
class OtpVerificationScreen extends StatelessWidget {
  ///
  final String? phoneNumber;

  ///
  const OtpVerificationScreen({super.key, this.phoneNumber});

  @override
  Widget build(BuildContext context) {
    return OtpVerificationProvider(
      builder: (BuildContext context, Widget? child) {
        return Builder(builder: (BuildContext context) {
          return Builder(builder: (BuildContext context) {
            return const Scaffold(
              resizeToAvoidBottomInset: false,
              backgroundColor: Colors.white,
              body: _OtpVerificationScreen(),
            );
          });
        });
      },
      phoneNumber: phoneNumber,
    );
  }
}

class _OtpVerificationScreen extends StatelessWidget {
  const _OtpVerificationScreen();

  @override
  Widget build(BuildContext context) {

    final PinTheme defaultPinTheme = PinTheme(
        height: 56.0,
        width: MediaQuery.of(context).size.width,
        textStyle: const TextStyle(
            color: CustomColors.white,
            fontFamily: FontFamily.quattrocentoSans,
            fontWeight: FontWeight.w700,
            fontSize: 20.0));

    final Column cursor = Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: <Widget>[
        Container(
          width: 56,
          height: 1,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ],
    );
    final Column preFilledWidget = Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: <Widget>[
        Container(
          width: 56,
          height: 1,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ],
    );
    OtpVerificationVieModel viewModel =
        BaseViewModel.watch<OtpVerificationVieModel>(context);
    return SizedBox(
      height: MediaQuery.of(context).size.height,
      child: Form(
        key: viewModel.form,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                decoration: const BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(30),
                        bottomLeft: Radius.circular(30))),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(top: 68),
                      child: Align(
                        alignment: Alignment.topRight,
                        child: Padding(
                            padding: const EdgeInsets.only(
                              right: 18.0,
                              left: 18.0,
                            ),
                            child: AppTextButton(
                              onTap: () {
                                viewModel.navigationToChangeLanguage(context: context);
                              },
                              isShowArrowIcon: true,
                              btnName: localLanguage?.keyChangeLanguage ??
                                  LocaleKeys.changeLanguage.tr(),
                            )),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 18.0, right: 18.0, top: 2.0),
                      child: Image.asset(AssetImagePath.asLogo),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 16.0, left: 16.0, top: 27.0),
                      child: TextVariant(
                        data: localLanguage?.keyOtp != null &&
                                localLanguage?.keyVerification != null
                            ? '${localLanguage?.keyOtp}\n${localLanguage?.keyVerification}'
                            : LocaleKeys.OTPVerification.tr(),
                        color: CustomColors.white,
                        fontFamily: FontFamily.playfairDisplay,
                        variantType: TextVariantType.displayMedium,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 16.0, left: 16.0, top: 14.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          TextVariant(
                            data: '${localLanguage?.keyOtpSent} +91'??
                                LocaleKeys.hasSendOTP.tr(),
                            color: CustomColors.white,
                            fontFamily: FontFamily.quattrocentoSans,
                            variantType: TextVariantType.bodyMedium,
                          ),
                          TextVariant(
                            data:
                                ' ${viewModel.localStorage.retrieveString(StorageKey.userPhoneNumber).toString()}',
                            color: CustomColors.white,
                            fontFamily: FontFamily.quattrocentoSans,
                            variantType: TextVariantType.bodyMedium,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                        padding: const EdgeInsets.only(
                            top: 14.0, right: 16.0, left: 16.0),
                        child: Pinput(
                          length: 4,
                          controller: viewModel.otpController,
                          pinAnimationType: PinAnimationType.slide,

                          defaultPinTheme: defaultPinTheme,
                          keyboardType: const TextInputType.numberWithOptions(
                              decimal: true, signed: false),
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter.digitsOnly
                          ],
                          enabled: !viewModel.state.load,
                          onChanged: (String value) {
                            viewModel.setOtpLength(value: value);
                          },
                          cursor: cursor,
                          preFilledWidget: preFilledWidget,
                        )),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16.0, vertical: 26.0),
                      child: AppButton(
                        isBackgroundColorWhite: true,
                        isGoIconShow: true,
                        width: MediaQuery.of(context).size.width,
                        btnName: localLanguage?.keyValidate ??
                            LocaleKeys.validate.tr().toUpperCase(),
                        center: true,
                        isEnable: viewModel.state.otpLength == 4,
                        load: viewModel.state.load,
                        onTap: () {
                          if (viewModel.form.currentState!.validate()) {
                            viewModel.otpVerificationCall(context: context);
                          }
                        },
                        variantType: TextVariantType.titleMedium,
                        fontFamily: FontFamily.quattrocentoSans,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          bottom: 18.0, left: 16.0, right: 16.0),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Wrap(
                              children: <Widget>[
                                TextVariant(
                                  data: localLanguage?.keyGetIt ??
                                      LocaleKeys.didNotGetIt.tr(),
                                  variantType: TextVariantType.bodyMedium,
                                  fontFamily: FontFamily.quattrocentoSans,
                                  color: CustomColors.white,
                                ),
                              ],
                            ),
                            Row(
                              children: <Widget>[
                                GestureDetector(
                                  onTap: viewModel.state.reSendButtonEnable
                                      ? () {
                                          viewModel.reSendGetOtp(
                                              context: context);
                                        }
                                      : null,
                                  child: TextVariant(
                                    data: localLanguage?.keyResendCode ??
                                        LocaleKeys.resendCode.tr(),
                                    color: viewModel.state.reSendButtonEnable
                                        ? CustomColors.white
                                        : CustomColors.ligthRed,
                                    variantType: TextVariantType.bodyMedium,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: FontFamily.quattrocentoSans,
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                viewModel.state.reSendButtonEnable == false
                                    ? TweenAnimationBuilder<Duration>(
                                        duration: const Duration(minutes: 3),
                                        tween: Tween<Duration>(
                                            begin: const Duration(minutes: 3),
                                            end: Duration.zero),
                                        onEnd: () {
                                          viewModel.enableResendCode();
                                        },
                                        builder: (BuildContext context,
                                            Duration value, Widget? child) {
                                          final int minutes = value.inMinutes;

                                          final int seconds =
                                              value.inSeconds % 60;
                                          Object secondsTime =
                                              seconds > 9 ? seconds : '0$seconds';
                                          return Padding(
                                              padding: const EdgeInsets.symmetric(
                                                  vertical: 5),
                                              child: Text(
                                                  '${0}$minutes:$secondsTime',
                                                  textAlign: TextAlign.center,
                                                  style: const TextStyle(
                                                      color: CustomColors.white,
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 18)));
                                        })
                                    : const SizedBox()
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Center(
                child: Image.asset(
                  AssetImagePath.otpVerificationImage,
                  fit: BoxFit.fill,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}*/
