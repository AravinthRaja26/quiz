import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/splash_screen/splash_provider.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/splash_screen/splash_view_model.dart';

///
@RoutePage(name: 'splashScreen')
class SplashScreen extends StatelessWidget {
  ///
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SplashProvider(
      builder: (BuildContext context, Widget? child) {
        return Builder(builder: (BuildContext context) {
          SplashViewModel viewModel =
              BaseViewModel.watch<SplashViewModel>(context);
          return Scaffold(
              key: viewModel.key,
              backgroundColor: CustomColors.midBlue,
              body: Center(
                child: Image.asset(
                  'assets/images/splash_background.png',
                  height: 240,
                  width: 240,
                ),
              ));
        });
      },
    );
  }
}
