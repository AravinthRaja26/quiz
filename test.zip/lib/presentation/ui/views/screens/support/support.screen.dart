import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/support/support_model.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_listtitle.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/no_data.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/support/support.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/support/support_viewmodel.provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// Support screen
///
@RoutePage(name: 'supportScreen')
class SupportScreen extends StatelessWidget {
  /// SupportScreen screen constructor
  const SupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SupportProvider(
      builder: (BuildContext context, _) {
        return Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
                centerTitle: true,
                title: TextVariant(
                  data: localLanguage?.keySupport ?? LocaleKeys.support.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                )),
            body: const _BodyScreen());
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SupportViewModel vm = BaseViewModel.watch<SupportViewModel>(context);

    return vm.state.isLoad == true
        ? const Center(
            child: CircularProgressIndicator(
              color: CustomColors.midBlue,
            ),
          )
        : vm.state.consumerDetails?.data?.isEmpty == true
            ? const NoDataFound()
            : Padding(
                padding: const EdgeInsets.all(10.0),
                child: Scrollbar(
                  radius: const Radius.circular(12),
                  thickness: 4,
                  child: ListView.builder(
                      shrinkWrap: true,
                      primary: false,
                      itemCount: vm.state.consumerDetails?.data?.length ?? 0,
                      itemBuilder: (BuildContext context, int index) {
                        ConsumerData? data =
                            vm.state.consumerDetails?.data?[index];
                        return data?.child == true
                            ? Padding(
                                padding: const EdgeInsets.only(
                                    left: 8, right: 6, bottom: 13, top: 10),
                                child: Material(
                                  borderRadius: BorderRadius.circular(6.0),
                                  elevation: 3.0,
                                  color: Colors.white,
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(6.0),
                                    onTap: () {
                                      data?.child == true &&
                                          data?.viewMore == false? vm.viewMore(context, data):vm.viewLess(context, data);
                                    },
                                    splashColor: Colors.grey.withOpacity(0.2),
                                    splashFactory: InkSplash.splashFactory,
                                    child: AnimatedContainer(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(12.0),
                                        ),
                                        duration: const Duration(seconds: 3),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: <Widget>[
                                            Expanded(
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            8.0),
                                                    child: TextVariant(
                                                      data:
                                                          data?.consumerOption ??
                                                              '',
                                                      color: CustomColors
                                                          .purpleBrown,
                                                      textAlign:
                                                          TextAlign.start,
                                                      fontFamily: FontFamily
                                                          .quattrocentoSans,
                                                      variantType:
                                                          TextVariantType
                                                              .titleMedium,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                    ),
                                                  ),
                                                  data?.viewMore == true
                                                      ? Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(8.0),
                                                          child: TextVariant(
                                                            data: vm
                                                                    .state
                                                                    .viewMoreConsumerDetails
                                                                    ?.data?[0]
                                                                    .consumerOption
                                                                    ?.replaceAll(
                                                                        '~ ~ ~ ~ ~',
                                                                        '\n') ??
                                                                '',
                                                            color: CustomColors
                                                                .midBlue,
                                                            textAlign:
                                                                TextAlign.start,
                                                            fontFamily: FontFamily
                                                                .quattrocentoSans,
                                                            variantType:
                                                                TextVariantType
                                                                    .titleMedium,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                          ),
                                                        )
                                                      : const SizedBox(),
                                                ],
                                              ),
                                            ),
                                            data?.child == true &&
                                                    data?.viewMore == false
                                                ? const Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 8.0,
                                                            vertical: 4.0),
                                                    child: Icon(Icons.add,
                                                        size: 20.0),
                                                  )
                                                : const Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 8.0,
                                                            vertical: 4.0),
                                                    child: Icon(Icons.minimize),
                                                  )
                                          ],
                                        )),
                                  ),
                                ),
                              )
                            : CustomWidget(
                                onTap: () {
                                  data?.consumerOption == 'Other issues'
                                      ? vm.navigationToSupportScreen(context)
                                      : '';
                                },
                                text: data?.consumerOption ?? '',
                              );
                      }),
                ),
              );
  }
}
