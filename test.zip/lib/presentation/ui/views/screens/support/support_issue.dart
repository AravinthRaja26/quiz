import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_outline_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_textform_field.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/valitaion.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/support/support.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/support/support_viewmodel.provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// Support Issue Screen
///
@RoutePage(name: 'supportIssueScreen')
class SupportIssueScreen extends StatelessWidget {
  ///  Support Issue screen constructor
  const SupportIssueScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SupportProvider(
      builder: (BuildContext context, _) {
        return Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
                centerTitle: true,
                title: TextVariant(
                  data: localLanguage?.keySupport ?? LocaleKeys.support.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                )),
            body: const _BodyScreen());
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SupportViewModel vm = BaseViewModel.watch<SupportViewModel>(context);
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: SingleChildScrollView(
        child: Form(
          key: vm.formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              TextVariant(
                data: localLanguage?.keyEnterYourIssueHere ??
                    LocaleKeys.enterYourIssueHere.tr(),
                color: CustomColors.midBlue,
                fontFamily: FontFamily.quattrocentoSans,
                fontWeight: FontWeight.w700,
                variantType: TextVariantType.headlineSmall,
              ),
              const SizedBox(
                height: 15,
              ),
              MessageUnderLineTextField(
                maxLines: 6,
                maxLength: 1000,
                textAlign: TextAlign.start,
                hintText: localLanguage?.keyEnterYourComment ??
                    LocaleKeys.enterYourCommentHere.tr(),
                hintColor: CustomColors.greyish,
                color: CustomColors.midBlue,
                alignLabelWithHint: true,
                controller: vm.commentController,
                validator: (String? value) {
                  return AppValidation.commentVerification(
                      vm.commentController.text.toString());
                },
                onChanged: (String value) {
                  vm.enableLoad(value);
                },
                fillColor: CustomColors.lightWhite,
                keyboardType: TextInputType.emailAddress,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Expanded(
                      child: CustomOutlineButton(
                        width: 160,
                        text: localLanguage?.keyCancel ??
                            LocaleKeys.cancel.tr().toUpperCase(),
                        onTap: () {
                          AutoRouter.of(context).maybePop();
                        },
                      ),
                    ),
                    Expanded(
                      child: AppButton(
                        width: 160,
                        isEnable: vm.state.isShimmer,
                        load: vm.state.isEnabled,
                        btnName: localLanguage?.keySend ??
                            LocaleKeys.send.tr().toUpperCase(),
                        center: true,
                        onTap: () async {
                          if (vm.formKey.currentState!.validate()) {
                            vm.createTicket(context);
                          }
                        },
                        variantType: TextVariantType.titleMedium,
                        fontFamily: FontFamily.quattrocentoSans,
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
