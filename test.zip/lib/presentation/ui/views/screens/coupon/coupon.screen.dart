import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_textform_field.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/coupon/coupon.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/coupon/coupon_viewmodel.provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// CouponScreen screen
///
@RoutePage(name: 'couponScreen')
class CouponScreen extends StatelessWidget {
  /// CouponScreen constructor
  const CouponScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CouponProvider(
      builder: (BuildContext context, _) {
        return Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
                toolbarHeight: 80,
                centerTitle: true,
                title: TextVariant(
                  data: localLanguage?.keyRedeem ?? LocaleKeys.Redeem.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                )),
            body: const _BodyScreen());
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    CouponViewModel vm = BaseViewModel.watch<CouponViewModel>(context);
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            TextVariant(
              data: LocaleKeys.pleaseEnterCouponCodeManually.tr(),
              color: CustomColors.black,
              fontFamily: FontFamily.quattrocentoSans,
              variantType: TextVariantType.titleLarge,
              fontWeight: FontWeight.w700,
            ),
            const SizedBox(
              height: 15,
            ),
            UnderLineTextField(
              textCapitalization: TextCapitalization.characters,
              hintColor: CustomColors.greyish,
              color: CustomColors.midBlue,
              controller: vm.couponController,
              onChanged: (String value) {
                vm.enableLoad(value);
              },
              validator: (dynamic value) {
                return null;
              },
              fillColor: CustomColors.lightWhite,
              keyboardType: TextInputType.emailAddress,
              hintText: LocaleKeys.enterYourCouponCode.tr(),
            ),
            const SizedBox(
              height: 30,
            ),
            AppButton(
              isEnable: vm.state.isShimmer,
              load: vm.state.isLoad,
              width: MediaQuery.of(context).size.width,
              btnName: LocaleKeys.Redeem.tr().toUpperCase(),
              center: true,
              onTap: () {
                vm.scanCouponDetail(context: context);
              },
              variantType: TextVariantType.titleMedium,
              fontFamily: FontFamily.quattrocentoSans,
            ),
          ],
        ),
      ),
    );
  }
}
