import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/models/consumer/consumer_transaction.model.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/coupon/coupon_detail.provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
/// coupon Detail screen
///
@RoutePage(name: 'couponDetailScreen')
class CouponDetailScreen extends StatelessWidget {
  ///
  final Earned? consumerEarnedDetails;

  ///
  final Expired? consumerExpiredDetails;

  /// coupon screen constructor
  const CouponDetailScreen({
    super.key,
    this.consumerEarnedDetails,
    this.consumerExpiredDetails,
  });

  @override
  Widget build(BuildContext context) {
    return CouponDetailProvider(
      consumerEarnedDetails: consumerEarnedDetails,
      consumerExpiredDetails: consumerExpiredDetails,
      builder: (BuildContext context, _) {
        return Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
                centerTitle: true,
                title: TextVariant(
                  data: localLanguage?.keyCouponDetails ??
                      LocaleKeys.couponDetails.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineMedium,
                  fontWeight: FontWeight.w700,
                )),
            body: _BodyScreen(
              consumerEarnedDetails: consumerEarnedDetails,
              consumerExpiredDetails: consumerExpiredDetails,
            ));
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  ///
  final Earned? consumerEarnedDetails;

  ///
  final Expired? consumerExpiredDetails;
  const _BodyScreen(
      {Key? key, this.consumerEarnedDetails, this.consumerExpiredDetails})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16.0, right: 16.0),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            const SizedBox(
              height: 45.0,
            ),
            QrcodeDetailsWidget(
              consumerEarnedDetails: consumerEarnedDetails,
              consumerExpiredDetails: consumerExpiredDetails,
            ),
            const SizedBox(
              height: 15,
            ),
            PointsWidget(
              consumerEarnedDetails: consumerEarnedDetails,
              consumerExpiredDetails: consumerExpiredDetails,
            ),
            const SizedBox(
              height: 10,
            ),
            EarnedPointsWidget(
              consumerEarnedDetails: consumerEarnedDetails,
              consumerExpiredDetails: consumerExpiredDetails,
            ),
            const SizedBox(
              height: 10,
            ),
            DateDetailsWidget(
              consumerEarnedDetails: consumerEarnedDetails,
              consumerExpiredDetails: consumerExpiredDetails,
            ),
            const SizedBox(
              height: 24,
            ),
          ],
        ),
      ),
    );
  }
}

///
class QrcodeDetailsWidget extends StatelessWidget {
  ///
  final Earned? consumerEarnedDetails;

  ///
  final Expired? consumerExpiredDetails;

  ///
  const QrcodeDetailsWidget(
      {Key? key, this.consumerEarnedDetails, this.consumerExpiredDetails})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        consumerExpiredDetails?.typeDesc == 'Expired'
            ? Stack(
                alignment: Alignment.center,
                children: <Widget>[
                  Image.asset(
                    AssetImagePath.qrDim,
                    height: 150,
                    width: 150,
                    fit: BoxFit.fill,
                    color: CustomColors.black,
                  ),
                  Image.asset(
                    AssetImagePath.expired1,
                    height: 40,
                    width: 70,
                    fit: BoxFit.fill,
                    color: CustomColors.midBlue,
                  )
                ],
              )
            : Image.asset(
                AssetImagePath.qrDetails,
                height: 150,
                width: 150,
                fit: BoxFit.fill,
                color: CustomColors.black,
              ),
        const SizedBox(
          height: 20,
        ),
        TextVariant(
          data: localLanguage?.keyQrCode ?? LocaleKeys.qrCode.tr(),
          color: CustomColors.black,
          fontFamily: FontFamily.quattrocentoSans,
          variantType: TextVariantType.bodySmall,
          fontWeight: FontWeight.w400,
        ),
        consumerEarnedDetails?.coupenCode != null
            ? TextVariant(
                data: consumerEarnedDetails?.coupenCode.toString() ?? '',
                color: CustomColors.black,
                fontFamily: FontFamily.playfairDisplay,
                variantType: TextVariantType.displaySmall,
                fontWeight: FontWeight.w600,
              )
            : consumerExpiredDetails?.coupenCode != null
                ? TextVariant(
                    data: consumerExpiredDetails?.coupenCode.toString() ?? '',
                    color: CustomColors.black,
                    fontFamily: FontFamily.playfairDisplay,
                    variantType: TextVariantType.displaySmall,
                    fontWeight: FontWeight.w600,
                  )
                : const SizedBox(),
      ],
    );
  }
}

///
class PointsWidget extends StatelessWidget {
  ///

  final Earned? consumerEarnedDetails;

  ///
  final Expired? consumerExpiredDetails;

  ///

  const PointsWidget(
      {Key? key, this.consumerEarnedDetails, this.consumerExpiredDetails})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        Expanded(
          child: Container(
            padding: const EdgeInsets.only(top: 6),
            height: 65,
            width: MediaQuery.of(context).size.width / 2.3,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: CustomColors.dimRed,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                TextVariant(
                  data:
                      localLanguage?.keyBasePoints ?? LocaleKeys.basePoint.tr(),
                  color: CustomColors.black,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.labelLarge,
                  fontWeight: FontWeight.w500,
                ),
                const TextVariant(
                  data: '1',
                  color: CustomColors.black,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.titleLarge,
                  fontWeight: FontWeight.w700,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(
          width: 10,
        ),
        Expanded(
          child: Container(
            padding: const EdgeInsets.only(top: 6),
            height: 65,
            width: MediaQuery.of(context).size.width / 2.3,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: CustomColors.dimRed,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                TextVariant(
                  data: localLanguage?.keyAdditionalPoint ??
                      LocaleKeys.additionalPoint.tr(),
                  color: CustomColors.black,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.labelLarge,
                  fontWeight: FontWeight.w500,
                ),
                const TextVariant(
                  data: '0',
                  color: CustomColors.black,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.titleLarge,
                  fontWeight: FontWeight.w700,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

///
class EarnedPointsWidget extends StatelessWidget {
  ///

  final Earned? consumerEarnedDetails;

  ///
  final Expired? consumerExpiredDetails;

  ///
  const EarnedPointsWidget(
      {Key? key, this.consumerEarnedDetails, this.consumerExpiredDetails})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 6),
      height: 65,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: CustomColors.midBlue,
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 20.0, right: 20.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            TextVariant(
              data: localLanguage?.keyPointsEarned ??
                  LocaleKeys.pointsEarned.tr(),
              color: CustomColors.white,
              fontFamily: FontFamily.quattrocentoSans,
              variantType: TextVariantType.titleLarge,
              fontWeight: FontWeight.w700,
            ),
            consumerEarnedDetails?.amount != null
                ? TextVariant(
                    data:
                        '${consumerEarnedDetails?.amount?.toInt().toString() ?? ' '} ${localLanguage?.keyPts ?? 'Pts'}',
                    color: CustomColors.white,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.headlineSmall,
                    fontWeight: FontWeight.w700,
                  )
                : consumerExpiredDetails?.expireAmount != null
                    ? TextVariant(
                        data:
                            '${consumerExpiredDetails?.expireAmount.toInt().toString() ?? ' '} ${localLanguage?.keyPts ?? 'Pts'}',
                        color: CustomColors.white,
                        fontFamily: FontFamily.quattrocentoSans,
                        variantType: TextVariantType.headlineSmall,
                        fontWeight: FontWeight.w700,
                      )
                    : const SizedBox(),
          ],
        ),
      ),
    );
  }
}

///
class DateDetailsWidget extends StatelessWidget {
  ///
  final Earned? consumerEarnedDetails;

  ///
  final Expired? consumerExpiredDetails;

  ///
  const DateDetailsWidget(
      {Key? key, this.consumerEarnedDetails, this.consumerExpiredDetails})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: CustomColors.dimRed,
      ),
      child: Padding(
        padding:
            const EdgeInsets.only(left: 16.0, right: 16.0, top: 12, bottom: 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  TextVariant(
                    data: localLanguage?.keyScannedDate ??
                        LocaleKeys.scannedDate.tr(),
                    color: CustomColors.black,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.labelLarge,
                    fontWeight: FontWeight.w400,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  TextVariant(
                    data: consumerEarnedDetails?.transactionTime
                            .toString()
                            .substring(0, 12) ??
                        '',
                    color: CustomColors.black,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.titleMedium,
                    fontWeight: FontWeight.w700,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const Spacer(),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  TextVariant(
                    data: localLanguage?.keyExpiredDate ??
                        LocaleKeys.expiredDate.tr(),
                    color: CustomColors.black,
                    fontFamily: FontFamily.quattrocentoSans,
                    variantType: TextVariantType.labelLarge,
                    fontWeight: FontWeight.w400,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  consumerEarnedDetails?.expiredDate.toString() != null
                      ? TextVariant(
                          data: consumerEarnedDetails?.expiredDate.toString() ??
                              '',
                          color: CustomColors.black,
                          fontFamily: FontFamily.quattrocentoSans,
                          variantType: TextVariantType.titleMedium,
                          fontWeight: FontWeight.w700,
                        )
                      : consumerExpiredDetails?.expiryDate.toString() != null
                          ? TextVariant(
                              data: consumerExpiredDetails?.expiryDate
                                      .toString() ??
                                  '',
                              color: CustomColors.black,
                              fontFamily: FontFamily.quattrocentoSans,
                              variantType: TextVariantType.titleMedium,
                              fontWeight: FontWeight.w700,
                            )
                          : const SizedBox(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
