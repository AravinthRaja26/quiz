import 'package:ai_barcode_scanner/ai_barcode_scanner.dart';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_textform_field.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/capital_later.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/scan/scan.viewmodel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/scan/scan.viewmodel.provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

///
/// Scan screen
///
@RoutePage(name: 'scanScreen')
class ScanScreen extends StatefulWidget {
  /// ScanScreen  constructor
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return ScanProvider(
      tickerProvider: this,
      builder: (BuildContext context, _) {
        ScanViewModel vm = BaseViewModel.watch<ScanViewModel>(context);
        return Builder(builder: (BuildContext context) {
          return Scaffold(
              key: vm.scaffoldKey,
              resizeToAvoidBottomInset: false,
              appBar: AppBar(
                automaticallyImplyLeading: true,
                centerTitle: true,
                toolbarHeight: 80,
                title: TextVariant(
                  data: localLanguage?.keyScanHere ?? LocaleKeys.scanHere.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.headlineSmall,
                  fontWeight: FontWeight.w700,
                ),
                bottom: PreferredSize(
                  preferredSize: Size(MediaQuery.of(context).size.width, 50),
                  child: Container(
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(16)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(
                              right: 2.0, left: 16.0, bottom: 1.0),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                flex: 5,
                                child: UnderLineTextField(
                                  focusNode: vm.focusNode,
                                  maxLength: 20,
                                  borderColor: CustomColors.midBlue,
                                  textCapitalization:
                                      TextCapitalization.characters,
                                  borderRadius: 10.0,
                                  hintColor: CustomColors.greyish,
                                  inputFormatters: <TextInputFormatter>[
                                    FilteringTextInputFormatter.deny(
                                        RegExp('[ ]')),
                                    FilteringTextInputFormatter.allow(
                                        RegExp('[a-zA-Z0-9]')),
                                    UpperCaseTextFormatter(),
                                  ],
                                  color: CustomColors.midBlue,
                                  controller: vm.couponController,
                                  suffixIcon: vm.state.isEnable
                                      ? InkWell(
                                          onTap: () {
                                            vm.clearText();
                                          },
                                          child: Icon(
                                            Icons.clear,
                                            color: vm.state.isEnable
                                                ? CustomColors.midBlue
                                                : CustomColors.greyish,
                                          ))
                                      : const SizedBox(),
                                  onChanged: (String value) {
                                    vm.couponCodeButtonEnable();
                                  },
                                  maxLines: 1,
                                  validator: (dynamic value) {
                                    return null;
                                  },
                                  fillColor: CustomColors.lightWhite,
                                  keyboardType: TextInputType.emailAddress,
                                  hintText:
                                      localLanguage?.keyEnterCodeManually ??
                                          LocaleKeys.enterCodeManually.tr(),
                                ),
                              ),
                              const SizedBox(
                                width: 10.0,
                              ),
                              Expanded(
                                flex: 1,
                                child: InkWell(
                                  onTap: vm.state.proceedButton
                                      ? () {
                                          vm.codeCoupon(context);
                                          SystemChannels.textInput
                                              .invokeMethod('TextInput.hide');
                                          vm.focusNode.unfocus();
                                        }
                                      : null,
                                  child: CircleAvatar(
                                    backgroundColor: vm.state.proceedButton
                                        ? CustomColors.midBlue
                                        : CustomColors.greyish,
                                    maxRadius: 24,
                                    child: const Icon(
                                      Icons.arrow_forward_outlined,
                                      size: 25,
                                      color: CustomColors.white,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 8,
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 16.0, bottom: 5),
                          child: Row(
                            children: <Widget>[
                              const TextVariant(
                                data: '* ',
                                color: CustomColors.lipstick,
                                fontFamily: FontFamily.quattrocentoSans,
                                variantType: TextVariantType.bodyMedium,
                              ),
                              TextVariant(
                                data: localLanguage
                                        ?.keyPleaseEnterMinimumEightCharacters ??
                                    'Please enter minimum 8 characters',
                                color: CustomColors.purpleBrown,
                                fontFamily: FontFamily.quattrocentoSans,
                                variantType: TextVariantType.bodyMedium,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              backgroundColor: CustomColors.white,
              body: const _BodyScreen());
        });
      },
    );
  }
}

class _BodyScreen extends StatelessWidget {
  const _BodyScreen();

  @override
  Widget build(BuildContext context) {
    ScanViewModel vm = BaseViewModel.watch<ScanViewModel>(context);

    return vm.state.isCameraPermissionGranted
        ? const ScannerWidget()
        : Column(
            children: <Widget>[
              SizedBox(
                height: 400,
                width: 400,
                child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    Image.asset(
                      AssetImagePath.wrapQR,
                      fit: BoxFit.fill,
                      color: CustomColors.midBlue,
                    ),
                    Image.asset(
                      AssetImagePath.qrDim,
                      height: 175,
                      width: 200,
                      fit: BoxFit.contain,
                      color: CustomColors.greyishBrown,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(13.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    const TextVariant(
                      data: '* ',
                      color: CustomColors.lipstick,
                      fontFamily: FontFamily.quattrocentoSans,
                      variantType: TextVariantType.headlineMedium,
                    ),
                    Flexible(
                      child: TextVariant(
                        data: localLanguage?.keyLocationPermissionQrAction ??
                            'Enable location permissions to perform QR actions',
                        color: CustomColors.purpleBrown,
                        fontFamily: FontFamily.quattrocentoSans,
                        variantType: TextVariantType.titleLarge,
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
  }
}

///
class ScannerWidget extends StatelessWidget {
  ///
  const ScannerWidget({super.key});

  @override
  Widget build(BuildContext context) {
    ScanViewModel vm = BaseViewModel.watch<ScanViewModel>(context);
    final Size size = MediaQuery.of(context).size;

    return Stack(
      children: <Widget>[
        // QrScannerWithEffect(
        //   qrKey: vm.qrKey,
        //   onQrScannerViewCreated: vm.onQRViewCreated,
        //   qrOverlayBorderColor: CustomColors.midBlue,
        //   isScanComplete: vm.state.isScanEffect,
        //   cutOutSize: (MediaQuery.of(context).size.width < 300 ||
        //           MediaQuery.of(context).size.height < 400)
        //       ? 250.0
        //       : 260.0,
        //   qrOverlayBorderRadius: 6.0,
        //   qrOverlayBorderWidth: 10.0,
        //   effectColor: CustomColors.midBlue,
        //   effectGradient: const LinearGradient(
        //     begin: Alignment.topCenter,
        //     end: Alignment.bottomCenter,
        //     stops: <double>[0.0, 1],
        //     colors: <Color>[
        //       CustomColors.midBlue,
        //       CustomColors.midBlue,
        //     ],
        //   ),
        // ),
        AiBarcodeScanner(
          onDispose: () {
            debugPrint("Barcode scanner disposed!");
          },
          hideSheetDragHandler: true,
          hideGalleryIcon: true,
          hideGalleryButton: true,
          hideSheetTitle: true,
          cutOutSize: 230.0,
          borderColor: CustomColors.blue,
          successColor: CustomColors.green,
          errorColor: CustomColors.red,
          showSuccess: true,
          showError: true,
          customOverlayBuilder: (BuildContext context, bool? value,
              MobileScannerController controller) {
            return Container(
              decoration: ShapeDecoration(shape: OverlayShape(
                borderRadius: 16,
                cutOutSize: 230,
                borderWidth: 8,
                borderColor: CustomColors.blue
              )),
            );
          },
          // overlayColor: CustomColors.backgeroundBlue,
          appBarBuilder: (_, __) {
            return PreferredSize(preferredSize: Size(0, 20), child: SizedBox());
          },
          controller: vm.qrController,
          placeholderBuilder: (BuildContext context, Widget? widget) {
            return Center(child: CircularProgressIndicator());
          },
          errorBuilder: (BuildContext context, MobileScannerException exception,
              Widget? widget) {
            return SnackBar(content: Text(exception.toString()));
          },
          onDetect: (BarcodeCapture capture) async {
            final String? scannedValue = capture.barcodes.first.rawValue;
            final Uint8List? image = capture.image;
            final Object? raw = capture.raw;
            final List<Barcode> barcodes = capture.barcodes;
            vm.qrData = barcodes.first;
            if (scannedValue != null) {
              vm.scanCouponDetail(context: context, qrValue: scannedValue);
              vm.controller?.stop();
              vm.qrController.stop();
              // vm.qrController.start();
            }

            print('---->${scannedValue}');
          },
        ),
        PositionedTransition(
          rect: RelativeRectTween(
            begin: RelativeRect.fromSize(
              Rect.fromLTWH(size.width /4.5, size.height / 1.8 * 0.5, 500, 500),
              Size(0, 50),
            ),
            end: RelativeRect.fromSize(
              Rect.fromLTWH(size.width /4.5,size.height / 2 * 1.03, 100, 100),
              Size(0, 50),
            ),
          ).animate(CurvedAnimation(
            parent: vm.controller!,
            curve: Curves.linear,
          )),
          child: Padding(
              padding: EdgeInsets.all(8),
              child: Wrap(
                children: <Widget>[
                  Container(
                    color: CustomColors.red,
                    height: 3,
                    width: 200,
                  ),
                ],
              )),
        ),
        Align(
          alignment: Alignment.topCenter,
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: TextVariant(
                    data: localLanguage?.keyOr ?? 'OR',
                    variantType: TextVariantType.titleLarge,
                    color: CustomColors.white),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: TextVariant(
                    data: localLanguage?.keyScanQrCode ?? 'Scan QR Code',
                    variantType: TextVariantType.displaySmall,
                    textAlign: TextAlign.center,
                    color: Colors.white),
              ),
            ],
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 40.0, vertical: 30.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                InkWell(
                  onTap: () async {
                    vm.getData();
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        color: vm.state.onFlashLight
                            ? CustomColors.midBlue
                            : CustomColors.white,
                        borderRadius:
                            const BorderRadius.all(Radius.circular(30))),
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(
                      vm.state.onFlashLight
                          ? Icons.flashlight_on_outlined
                          : Icons.flashlight_off_outlined,
                      size: 25,
                      color: CustomColors.dimBlack,
                    ),
                  ),
                ),
                const Spacer(),
                InkWell(
                  onTap: () async {
                    vm.getCameraAccess();
                  },
                  child: Container(
                    decoration: const BoxDecoration(
                        color: CustomColors.white,
                        borderRadius: BorderRadius.all(Radius.circular(30))),
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(
                      vm.state.onCameraAccess ? Icons.sync : Icons.sync,
                      size: 25,
                      color: CustomColors.dimBlack,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
