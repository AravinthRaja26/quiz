
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
class TutorialSecondScreen extends StatelessWidget {
  ///
  final GestureTapCallback? onTap;

  ///
  const TutorialSecondScreen({super.key, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        TutorialItem(
          title: localLanguage?.keyRedeem ?? LocaleKeys.Redeem.tr(),
          description: localLanguage?.keyTutorialDescription2 != null
              ? '${localLanguage?.keyTutorialDescription2}'
              : LocaleKeys.tutorial_des_2.tr(),
        ),
        Padding(
            padding: const EdgeInsets.only(top: 14.0),
            child: OpenButton(
              isEnable: true,
              load: false,
              fontFamily: FontFamily.poppins,
              variantType: TextVariantType.bodyMedium,
              btnName: localLanguage?.keyLetsGo ?? LocaleKeys.LetsGo.tr(),
              onTap: onTap ?? () {},
            )),
        const Padding(
            padding: EdgeInsets.only(top: 35.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                CircleAvatar(
                    maxRadius: 5, backgroundColor: CustomColors.greyishBrown2),
                Padding(
                  padding: EdgeInsets.only(left: 8.0),
                  child: CircleAvatar(
                      maxRadius: 5, backgroundColor: CustomColors.midBlue,
                  ),
                ),
              ],
            )),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(left: 26.0,right: 26.0,bottom: 26.0),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Image.asset(
                'assets/images/group_3157.png',
              ),
            ),
          ),
        )
      ],
    );
  }
}

///
class TutorialItem extends StatelessWidget {
  ///
  final String? title;

  ///
  final String? description;

  ///
  const TutorialItem({super.key, this.title, this.description});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(top: 29.0, right: 16.0, left: 16.0),
          child: TextVariant(
              data: title ?? '',
              color: CustomColors.purpleBrown,
              fontFamily: FontFamily.playfairDisplay,
              variantType: TextVariantType.displayMedium),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 18.0, right: 16.0, left: 16.0),
          child: TextVariant(
              data: description ?? '',
              color: CustomColors.purpleBrown,
              fontFamily: FontFamily.quattrocentoSans,
              textAlign: TextAlign.center,
              variantType: TextVariantType.bodyMedium),
        ),
      ],
    );
  }
}
