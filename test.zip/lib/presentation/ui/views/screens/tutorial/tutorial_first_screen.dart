import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/ui/views/screens/tutorial/tutorial_second_screen.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
class TutorialFirstScreen extends StatelessWidget {
  ///
  const TutorialFirstScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.only(left: 22.0,right: 22.0,bottom: 22.0),
            child: Image.asset(
              'assets/images/group_3122.png',
            ),
          ),
        ),
        Column(
          children: <Widget>[
            TutorialItem(
              title:
                  localLanguage?.keyGetRewarded ?? LocaleKeys.GetRewarded.tr(),
              description: localLanguage?.keyTutorialDescription1 != null &&
                      localLanguage?.keyTheBestModularSwitchFromLitaski != null
                  ? '${localLanguage?.keyTutorialDescription1}\n'
                  : LocaleKeys.tutorial_des_1.tr(),
            ),
            const Padding(
                padding: EdgeInsets.only(top: 68.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                      padding: EdgeInsets.only(right: 8.0),
                      child: CircleAvatar(
                          maxRadius: 5,
                          backgroundColor:
                           CustomColors.midBlue,
                         ),
                    ),
                    CircleAvatar(
                        maxRadius: 5,
                        backgroundColor: CustomColors.greyishBrown2),
                  ],
                )),
            /* Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 0.0),
                child: Image.asset(
                  'assets/images/intersection_1.png',
                  fit: BoxFit.cover,
                ),
              ),
            ),*/
          ],
        ),
      ],
    );
  }
}
