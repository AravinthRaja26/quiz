import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/screens/tutorial/tutorial_first_screen.dart';
import 'package:nikitchem/presentation/ui/views/screens/tutorial/tutorial_second_screen.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/tutorial/tutorial.viewmdel.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/tutorial/tutorial_viewmdel.provider.dart';
import 'package:flutter/material.dart';

///
@RoutePage(name: 'tutorialScreen')
class TutorialScreen extends StatelessWidget {
  ///
  const TutorialScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return TutorialViewModelProvider(
      builder: (BuildContext context, Widget? child) {
        return Builder(builder: (BuildContext context) {
          TutorialViewModel viewModel =
              BaseViewModel.watch<TutorialViewModel>(context);
          return Scaffold(
            key: viewModel.key,
            backgroundColor: CustomColors.white,
            appBar:
                AppBar(backgroundColor: CustomColors.white, actions: <Widget>[
              InkWell(
                onTap: () {
                  viewModel.navigateToLogin(context: context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: TextVariant(
                      data: localLanguage?.keySkip ?? 'Skip',
                      variantType: TextVariantType.bodyLarge,
                      color: CustomColors.midBlue,
                      fontFamily: FontFamily.quattrocentoSans),
                ),
              )
            ]),
            body: const _TutorialScreenBody(),
            floatingActionButton: Padding(
              padding: const EdgeInsets.all(20.0),
              child: FloatingActionButton(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(28)),
                  onPressed: () {
                    viewModel.navigateToLogin(context: context);
                  },
                  backgroundColor: CustomColors.midBlue,
                  child: const Icon(
                    Icons.keyboard_double_arrow_right_outlined,
                    color: Colors.white,
                    size: 35,
                  )),
            ),
          );
        });
      },
    );
  }
}

class _TutorialScreenBody extends StatelessWidget {
  const _TutorialScreenBody();

  @override
  Widget build(BuildContext context) {
    TutorialViewModel viewModel =
        BaseViewModel.watch<TutorialViewModel>(context);

    return PageView(
      reverse: false,
      controller: viewModel.pageController,
      onPageChanged: (int value) {
        viewModel.setCurrentIndex(value);
      },
      children: <Widget>[
        const TutorialFirstScreen(),
        TutorialSecondScreen(
          onTap: () {
            viewModel.navigateToLogin(context: context);
          },
        )
      ],
    );
  }
}

///
class TutorialItem extends StatelessWidget {
  ///
  final String? title;

  ///
  final String? description;

  ///
  final String? image;

  ///
  const TutorialItem({super.key, this.title, this.description, this.image});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(top: 54.0, right: 16.0, left: 16.0),
          child: TextVariant(
              data: title ?? '',
              color: CustomColors.black,
              textAlign: TextAlign.center,
              fontFamily: FontFamily.playfairDisplay,
              variantType: TextVariantType.headlineLarge),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 18.0, right: 16.0, left: 16.0),
          child: TextVariant(
              data: description ?? '',
              color: CustomColors.purpleBrown,
              fontFamily: FontFamily.quattrocentoSans,
              textAlign: TextAlign.center,
              variantType: TextVariantType.bodyMedium),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 43.0, left: 16, right: 16),
          child: Image.asset(
            image ?? 'assets/images/group_9.png',
            fit: BoxFit.cover,
          ),
        ),
      ],
    );
  }
}
