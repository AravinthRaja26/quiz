import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_outline_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_textform_field.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/user_profile/user_profile_provider.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/user_profile/user_profile_viewmodel.dart';

///
@RoutePage(name: 'userProfileScreen')
class UserProfileScreen extends StatelessWidget {
  ///
  const UserProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return UserProfileProvider(
      builder: (BuildContext context, Widget? child) {
        return Builder(builder: (BuildContext context) {
          UserProfileViewModel viewModel =
              BaseViewModel.watch<UserProfileViewModel>(context);
          return Scaffold(
            backgroundColor: Colors.white,
            resizeToAvoidBottomInset: false,
            appBar: AppBar(
              leadingWidth: 80,
              leading: Image.asset(AssetImagePath.asLogo),
              actions: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(right: 16.0),
                  child: AppOutlineButton(
                    onTap: () {
                      viewModel.navigateToChangeLanguage(context);
                    },
                    text: localLanguage?.keyChangeLanguage ??
                        LocaleKeys.changeLanguage.tr(),
                    trailingPath: AssetImagePath.downArrow,
                  ),
                ),
              ],
            ),
            body: const _UserProfileBody(),
          );
        });
      },
    );
  }
}

class _UserProfileBody extends StatelessWidget {
  const _UserProfileBody();

  @override
  Widget build(BuildContext context) {
    ///
    UserProfileViewModel viewModel =
        BaseViewModel.watch<UserProfileViewModel>(context);
    return SingleChildScrollView(
      child: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: Form(
          key: viewModel.form,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding:
                    const EdgeInsets.only(right: 16.0, left: 16.0, top: 27.0),
                child: TextVariant(
                  data: localLanguage?.keyUserProfile != null &&
                          localLanguage?.keyProfile != null
                      ? '${localLanguage?.keyUserProfile}\n${localLanguage?.keyProfile}'
                      : LocaleKeys.userProfile.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.playfairDisplay,
                  variantType: TextVariantType.displayMedium,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(right: 16.0, left: 16.0, top: 14.0),
                child: TextVariant(
                  data: localLanguage?.keyKnowYourBetter ??
                      LocaleKeys.getKnowYourBetter.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.bodyMedium,
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(top: 24.0, right: 16.0, left: 16.0),
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.all(Radius.circular(6)),
                      border: Border.all(color: CustomColors.whiteTwo)),
                  child: TextFormField(
                    cursorColor: CustomColors.midBlue,
                    onChanged: (String value) {
                      viewModel.setUserNameLength(value: value);
                    },
                    enabled: !viewModel.state.load,
                    textInputAction: TextInputAction.next,
                    textCapitalization: TextCapitalization.words,
                    controller: viewModel.userNameController,
                    maxLength: 32,
                    style: const TextStyle(
                        color: CustomColors.darkBlack,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontSize: 16.0,
                        fontWeight: FontWeight.w700),
                    inputFormatters: <TextInputFormatter>[
                      NoInitialSpaceInputFormatter()
                    ],
                    decoration: InputDecoration(
                        fillColor: Colors.white,
                        counterText: '',
                        hintText: localLanguage?.keyUserName ?? 'User Name*',
                        hintStyle: const TextStyle(
                            color: CustomColors.greyish,
                            fontFamily: FontFamily.quattrocentoSans,
                            fontSize: 16.0,
                            fontWeight: FontWeight.w400),
                        contentPadding: const EdgeInsets.only(
                            top: 12, left: 8, right: 8.0, bottom: 12.0),
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(6)))),
                  ),
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(top: 24.0, right: 16.0, left: 16.0),
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.all(Radius.circular(6)),
                      border: Border.all(color: CustomColors.whiteTwo)),
                  child: TextFormField(
                    cursorColor: CustomColors.midBlue,
                    textInputAction: TextInputAction.done,
                    validator: (String? value) {
                      return viewModel.emailValidation();
                    },
                    maxLength: 60,
                    enabled: !viewModel.state.load,
                    controller: viewModel.emailController,
                    keyboardType: TextInputType.emailAddress,
                    style: const TextStyle(
                        color: CustomColors.darkBlack,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontSize: 16.0,
                        fontWeight: FontWeight.w700),
                    inputFormatters: <TextInputFormatter>[
                      NoInitialSpaceInputFormatter()
                    ],
                    decoration: InputDecoration(
                        counterText: '',
                        fillColor: Colors.white,
                        hintText: localLanguage?.keyEmailId ??
                            LocaleKeys.emailID.tr(),
                        hintStyle: const TextStyle(
                            color: CustomColors.greyish,
                            fontFamily: FontFamily.quattrocentoSans,
                            fontSize: 16.0,
                            fontWeight: FontWeight.w400),
                        contentPadding: const EdgeInsets.only(
                            top: 12, left: 8, right: 8.0, bottom: 12.0),
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(6)))),
                  ),
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(top: 24.0, right: 16.0, left: 16.0),
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.all(Radius.circular(6)),
                      border: Border.all(color: CustomColors.whiteTwo)),
                  child: TextFormField(
                    cursorColor: CustomColors.midBlue,
                    textInputAction: TextInputAction.next,
                    enabled: !viewModel.state.load,
                    controller: viewModel.phoneController,
                    readOnly: true,
                    style: const TextStyle(
                        color: CustomColors.greyish,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontSize: 16.0,
                        fontWeight: FontWeight.w700),
                    inputFormatters: <TextInputFormatter>[
                      NoInitialSpaceInputFormatter()
                    ],
                    decoration: InputDecoration(
                        fillColor: Colors.white,
                        alignLabelWithHint: true,
                        enabled: false,
                        hintText: localLanguage?.keyPhoneNumber ??
                            LocaleKeys.phoneNumber.tr(),
                        prefix: Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: TextVariant(
                              data: viewModel.getCountryCode() ?? '+91',
                              fontSize: 16,
                              color: CustomColors.midGreen,
                              fontFamily: FontFamily.quattrocentoSans,
                              variantType: TextVariantType.titleMedium),
                        ),
                        prefixIconConstraints:
                            const BoxConstraints(minHeight: 0.0, minWidth: 0.0),
                        hintStyle: const TextStyle(
                            color: CustomColors.greyish,
                            fontFamily: FontFamily.quattrocentoSans,
                            fontSize: 16.0,
                            fontWeight: FontWeight.w700),
                        contentPadding: const EdgeInsets.only(
                            top: 12, left: 8, right: 8.0, bottom: 12.0),
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(6)))),
                  ),
                ),
              ),
              Row(
                children: <Widget>[
                  const Padding(
                    padding: EdgeInsets.only(left: 16.0, top: 14.0),
                    child: TextVariant(
                      data: '* ',
                      color: CustomColors.lipstick,
                      fontFamily: FontFamily.quattrocentoSans,
                      variantType: TextVariantType.bodyMedium,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 16.0, top: 14.0),
                    child: TextVariant(
                      data: localLanguage?.keyMandatoryHelpText ??
                          LocaleKeys.markedFieldsAreMandatory.tr(),
                      color: CustomColors.purpleBrown,
                      fontFamily: FontFamily.quattrocentoSans,
                      variantType: TextVariantType.bodyMedium,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(
                    left: 16.0, right: 16.0, top: 26.0, bottom: 16),
                child: AppButton(
                  width: MediaQuery.of(context).size.width,
                  btnName: localLanguage?.keyProceed ?? 'Proceed'.toUpperCase(),
                  center: true,
                  load: viewModel.state.load,
                  isEnable: viewModel.state.userNameLength > 2,
                  onTap: () {
                    viewModel.saveUserProfile(context: context);
                    // viewModel.checkValidate(context: context);
                  },
                  variantType: TextVariantType.titleMedium,
                  fontFamily: FontFamily.quattrocentoSans,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: AppButton(
                  width: MediaQuery.of(context).size.width,
                  btnName: localLanguage?.keyCancelLogin ??
                      'Cancel Login'.toUpperCase(),
                  center: true,
                  isEnable: true,
                  onTap: () {
                    viewModel.goToLogin(context: context);
                  },
                  variantType: TextVariantType.titleMedium,
                  fontFamily: FontFamily.quattrocentoSans,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
/*///
@RoutePage(name: 'userProfileScreen')
class UserProfileScreen extends StatelessWidget {
  ///
  const UserProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return UserProfileProvider(
      builder: (BuildContext context, Widget? child) {
        return Builder(builder: (BuildContext context) {
          return const Scaffold(
            backgroundColor: Colors.white,
            resizeToAvoidBottomInset: false,

            body: _UserProfileBody(),
          );
        });
      },
    );
  }
}

class _UserProfileBody extends StatelessWidget {
  const _UserProfileBody();

  @override
  Widget build(BuildContext context) {
    ///
    UserProfileViewModel viewModel =
        BaseViewModel.watch<UserProfileViewModel>(context);
    return SingleChildScrollView(
      child: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: Form(
          key: viewModel.form,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  decoration: const BoxDecoration(
                      color: CustomColors.red,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(30),
                          bottomLeft: Radius.circular(30))),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(top: 68),
                        child: Align(
                          alignment: Alignment.topRight,
                          child: Padding(
                              padding: const EdgeInsets.only(
                                right: 18.0,
                                left: 18.0,
                              ),
                              child: AppTextButton(
                                onTap: () {
                                  viewModel.navigateToChangeLanguage(context);
                                },
                                isShowArrowIcon: true,
                                btnName: localLanguage?.keyChangeLanguage ??
                                    LocaleKeys.changeLanguage.tr(),
                              )),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 18.0, right: 18.0, top: 2.0),
                        child: Image.asset(AssetImagePath.asLogo),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            right: 16.0, left: 16.0, top: 27.0),
                        child: TextVariant(
                          data: localLanguage?.keyUserProfile != null &&
                                  localLanguage?.keyProfile != null
                              ? '${localLanguage?.keyUserProfile}${localLanguage?.keyProfile}'
                              : LocaleKeys.userProfile.tr(),
                          color: CustomColors.white,
                          fontFamily: FontFamily.playfairDisplay,
                          variantType: TextVariantType.displayMedium,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            right: 16.0, left: 16.0, top: 14.0),
                        child: TextVariant(
                          data: localLanguage?.keyKnowYourBetter ??
                              LocaleKeys.getKnowYourBetter.tr(),
                          color: CustomColors.white,
                          fontFamily: FontFamily.quattrocentoSans,
                          variantType: TextVariantType.bodyMedium,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 24.0, right: 16.0, left: 16.0),
                        child: TextFormField(
                          onChanged: (String value) {
                            viewModel.setUserNameLength(value: value);
                          },
                          enabled: !viewModel.state.load,
                          textInputAction: TextInputAction.next,
                          textCapitalization: TextCapitalization.words,
                          controller: viewModel.userNameController,
                          maxLength: 32,
                          style: const TextStyle(
                              color: CustomColors.white,
                              fontFamily: FontFamily.quattrocentoSans,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w700),
                          inputFormatters: <TextInputFormatter>[
                            NoInitialSpaceInputFormatter()
                          ],
                          decoration: InputDecoration(
                            fillColor: Colors.white,
                            counterText: '',
                            hintText: localLanguage?.keyUserName ?? 'User Name*',
                            hintStyle: const TextStyle(
                                color: CustomColors.white,
                                fontFamily: FontFamily.quattrocentoSans,
                                fontSize: 16.0,
                                fontWeight: FontWeight.w400),

                            border: const UnderlineInputBorder(
                                borderSide: BorderSide(color: Colors.white)),
                            disabledBorder: const UnderlineInputBorder(
                                borderSide: BorderSide(color: Colors.white)),
                            enabledBorder: const UnderlineInputBorder(
                                borderSide: BorderSide(color: Colors.white)),
                            focusedBorder: const UnderlineInputBorder(
                                borderSide: BorderSide(color: Colors.white)),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 24.0, right: 16.0, left: 16.0),
                        child: TextFormField(
                          textInputAction: TextInputAction.done,
                          validator: (String? value) {
                            return viewModel.emailValidation();
                          },
                          maxLength: 60,
                          enabled: !viewModel.state.load,
                          controller: viewModel.emailController,
                          keyboardType: TextInputType.emailAddress,
                          style: const TextStyle(
                              color: CustomColors.white,
                              fontFamily: FontFamily.quattrocentoSans,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w700),
                          inputFormatters: <TextInputFormatter>[
                            NoInitialSpaceInputFormatter()
                          ],
                          decoration: InputDecoration(
                              counterText: '',
                              fillColor: Colors.white,
                              hintText: localLanguage?.keyEmailId ??
                                  LocaleKeys.emailID.tr(),
                              hintStyle: const TextStyle(
                                  color: CustomColors.white,
                                  fontFamily: FontFamily.quattrocentoSans,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w400),

                              border: const UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white)),
                              disabledBorder: const UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white)),
                              enabledBorder: const UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white)),
                              focusedBorder: const UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white))),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 24.0, right: 16.0, left: 16.0),
                        child: TextFormField(
                          textInputAction: TextInputAction.next,
                          enabled: !viewModel.state.load,
                          controller: viewModel.phoneController,
                          readOnly: true,
                          style: const TextStyle(
                              color: CustomColors.white,
                              fontFamily: FontFamily.quattrocentoSans,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w700),
                          inputFormatters: <TextInputFormatter>[
                            NoInitialSpaceInputFormatter()
                          ],
                          decoration: InputDecoration(
                              fillColor: Colors.white,
                              alignLabelWithHint: true,
                              enabled: false,
                              hintText: localLanguage?.keyPhoneNumber ??
                                  LocaleKeys.phoneNumber.tr(),
                              prefix: const Padding(
                                padding: EdgeInsets.only(right: 8.0),
                                child: TextVariant(
                                    data: '+ 91 ',
                                    fontSize: 16,
                                    color: CustomColors.white,
                                    fontFamily: FontFamily.quattrocentoSans,
                                    variantType: TextVariantType.titleMedium),
                              ),
                              prefixIconConstraints: const BoxConstraints(
                                  minHeight: 0.0, minWidth: 0.0),
                              hintStyle: const TextStyle(
                                  color: CustomColors.white,
                                  fontFamily: FontFamily.quattrocentoSans,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w700),
                              border: const UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white)),
                              disabledBorder: const UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white)),
                              enabledBorder: const UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white)),
                              focusedBorder: const UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.white))),
                        ),
                      ),
                      Row(
                        children: <Widget>[
                          const Padding(
                            padding: EdgeInsets.only(left: 16.0, top: 14.0),
                            child: TextVariant(
                              data: '* ',
                              color: CustomColors.white,
                              fontFamily: FontFamily.quattrocentoSans,
                              variantType: TextVariantType.bodyMedium,
                            ),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.only(right: 16.0, top: 14.0),
                            child: TextVariant(
                              data: localLanguage?.keyMandatoryHelpText ??
                                  LocaleKeys.markedFieldsAreMandatory.tr(),
                              color: CustomColors.white,
                              fontFamily: FontFamily.quattrocentoSans,
                              variantType: TextVariantType.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 16.0, right: 16.0, top: 26.0, bottom: 16),
                        child: AppButton(
                          isGoIconShow: true,
                          isBackgroundColorWhite: true,
                          width: MediaQuery.of(context).size.width,
                          btnName: localLanguage?.keyVerify?.toUpperCase() ??
                              'Verify'.toUpperCase(),
                          center: true,
                          load: viewModel.state.load,
                          isEnable: viewModel.state.userNameLength > 2,
                          onTap: () {
                            viewModel.saveUserProfile(context: context);
                            // viewModel.checkValidate(context: context);
                          },
                          variantType: TextVariantType.titleMedium,
                          fontFamily: FontFamily.quattrocentoSans,
                        ),
                      ),
                     */ /* Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: AppButton(
                          width: MediaQuery.of(context).size.width,
                          btnName: localLanguage?.keyCancelLogin ??
                              'Cancel Login'.toUpperCase(),
                          center: true,
                          isEnable: true,
                          onTap: () {
                            viewModel.goToLogin(context: context);
                          },
                          variantType: TextVariantType.titleMedium,
                          fontFamily: FontFamily.quattrocentoSans,
                        ),
                      ),*/ /*
                      const SizedBox(
                        height: 16.0,
                      ),
                    ],
                  ),
                ),
                Center(
                  child: Image.asset(
                    AssetImagePath.profilePic,
                    fit: BoxFit.fill,
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}*/
