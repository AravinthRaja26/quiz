

import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'tutorial.viewstate.g.dart';

///
@CopyWith()
class TutorialViewState extends ViewState{


  ///
  final int currentIndex;

  ///
  const TutorialViewState({required this.currentIndex});

  ///
  TutorialViewState.initial():currentIndex=0;

  @override
  List<Object?> get props => <Object>[currentIndex];

}