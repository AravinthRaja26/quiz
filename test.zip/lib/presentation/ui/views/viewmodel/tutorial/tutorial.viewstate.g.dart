// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tutorial.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$TutorialViewStateCWProxy {
  TutorialViewState currentIndex(int currentIndex);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `TutorialViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// TutorialViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  TutorialViewState call({
    int? currentIndex,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfTutorialViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfTutorialViewState.copyWith.fieldName(...)`
class _$TutorialViewStateCWProxyImpl implements _$TutorialViewStateCWProxy {
  const _$TutorialViewStateCWProxyImpl(this._value);

  final TutorialViewState _value;

  @override
  TutorialViewState currentIndex(int currentIndex) =>
      this(currentIndex: currentIndex);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `TutorialViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// TutorialViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  TutorialViewState call({
    Object? currentIndex = const $CopyWithPlaceholder(),
  }) {
    return TutorialViewState(
      currentIndex:
          currentIndex == const $CopyWithPlaceholder() || currentIndex == null
              ? _value.currentIndex
              // ignore: cast_nullable_to_non_nullable
              : currentIndex as int,
    );
  }
}

extension $TutorialViewStateCopyWith on TutorialViewState {
  /// Returns a callable class that can be used as follows: `instanceOfTutorialViewState.copyWith(...)` or like so:`instanceOfTutorialViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$TutorialViewStateCWProxy get copyWith =>
      _$TutorialViewStateCWProxyImpl(this);
}
