import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/events/network_event.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/tutorial/tutorial.viewstate.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/material.dart';

///
class TutorialViewModel extends BaseViewModel<TutorialViewState>
    with EventMixin<AppEvent> {
  ///
  final AppNavigation appNavigation;

  ///
  final LocalStorage localStorage;

  ///
  final GlobalKey<ScaffoldState> key = GlobalKey<ScaffoldState>();

  /// page controller
  final PageController pageController = PageController();

  ///
  StreamSubscription<AppEvent>? streamSubscription;


  ///
  TutorialViewModel(this.appNavigation, this.localStorage)
      : super(TutorialViewState.initial());
  ///
  void init(BuildContext context) async {

    streamSubscription = listenEvents((AppEvent event) {
      if (event is NetWorkOnlineEvent) {

        AutoRouter.of(context).maybePop();

      } else if (event is NetWorkOfflineEvent) {

        appNavigation.navigationToNetWorkScreen(context);

      } else if (event is LanguageEvent) {
        notifyListeners();
      }
    });

    List<ConnectivityResult> connectivityResult =
        await (Connectivity().checkConnectivity());
    if (connectivityResult.contains( ConnectivityResult.none)) {

        appNavigation.navigationToNetWorkScreen(context);

    }
  }

  ///
  void setCurrentIndex(int? currentIndex) {
    setState(state.copyWith(currentIndex: currentIndex));
  }

  ///
  void navigateToLogin({required BuildContext context}) {
    localStorage.save(StorageKey.isFinishedTutorial, true);
    appNavigation.navigationToLoginScreen(context);
  }
}
