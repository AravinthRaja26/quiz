import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/account/account_details_response.model.dart';
import 'package:nikitchem/data/models/bank_trnasfer/bank_transfer.response.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'bank_account.viewstate.g.dart';

///
@CopyWith()
class AccountViewState extends ViewState {
  ///
  AccountDetailsResponse? accountDetailsResponse;

  ///
  BankTransferResponse? bankTransferResponse;

  ///
  final bool isLoad;
  ///
  final bool buttonLoad;

  ///
  AccountViewState(
    this.accountDetailsResponse,
    this.bankTransferResponse,
    this.isLoad,
    this.buttonLoad,
  );

  ///
  AccountViewState.initial()
      : accountDetailsResponse = AccountDetailsResponse(),
        bankTransferResponse = BankTransferResponse(),

        isLoad = false,buttonLoad=false;

  @override
  List<Object?> get props => <Object?>[accountDetailsResponse,bankTransferResponse, isLoad,buttonLoad];
}
