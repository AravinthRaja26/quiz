// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bank_account.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$AccountViewStateCWProxy {
  AccountViewState accountDetailsResponse(
      AccountDetailsResponse? accountDetailsResponse);

  AccountViewState bankTransferResponse(
      BankTransferResponse? bankTransferResponse);

  AccountViewState isLoad(bool isLoad);

  AccountViewState buttonLoad(bool buttonLoad);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `AccountViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// AccountViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  AccountViewState call({
    AccountDetailsResponse? accountDetailsResponse,
    BankTransferResponse? bankTransferResponse,
    bool? isLoad,
    bool? buttonLoad,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfAccountViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfAccountViewState.copyWith.fieldName(...)`
class _$AccountViewStateCWProxyImpl implements _$AccountViewStateCWProxy {
  const _$AccountViewStateCWProxyImpl(this._value);

  final AccountViewState _value;

  @override
  AccountViewState accountDetailsResponse(
          AccountDetailsResponse? accountDetailsResponse) =>
      this(accountDetailsResponse: accountDetailsResponse);

  @override
  AccountViewState bankTransferResponse(
          BankTransferResponse? bankTransferResponse) =>
      this(bankTransferResponse: bankTransferResponse);

  @override
  AccountViewState isLoad(bool isLoad) => this(isLoad: isLoad);

  @override
  AccountViewState buttonLoad(bool buttonLoad) => this(buttonLoad: buttonLoad);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `AccountViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// AccountViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  AccountViewState call({
    Object? accountDetailsResponse = const $CopyWithPlaceholder(),
    Object? bankTransferResponse = const $CopyWithPlaceholder(),
    Object? isLoad = const $CopyWithPlaceholder(),
    Object? buttonLoad = const $CopyWithPlaceholder(),
  }) {
    return AccountViewState(
      accountDetailsResponse == const $CopyWithPlaceholder()
          ? _value.accountDetailsResponse
          // ignore: cast_nullable_to_non_nullable
          : accountDetailsResponse as AccountDetailsResponse?,
      bankTransferResponse == const $CopyWithPlaceholder()
          ? _value.bankTransferResponse
          // ignore: cast_nullable_to_non_nullable
          : bankTransferResponse as BankTransferResponse?,
      isLoad == const $CopyWithPlaceholder() || isLoad == null
          ? _value.isLoad
          // ignore: cast_nullable_to_non_nullable
          : isLoad as bool,
      buttonLoad == const $CopyWithPlaceholder() || buttonLoad == null
          ? _value.buttonLoad
          // ignore: cast_nullable_to_non_nullable
          : buttonLoad as bool,
    );
  }
}

extension $AccountViewStateCopyWith on AccountViewState {
  /// Returns a callable class that can be used as follows: `instanceOfAccountViewState.copyWith(...)` or like so:`instanceOfAccountViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$AccountViewStateCWProxy get copyWith => _$AccountViewStateCWProxyImpl(this);
}
