import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/account/account_details_request.model.dart';
import 'package:nikitchem/data/models/account/account_details_response.model.dart';
import 'package:nikitchem/data/models/account/ifsc_reponse.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/account/account_details.repository.dart';
import 'package:nikitchem/data/repository/account/ifsc_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/gen/assets.gen.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/account/bank_account.viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/material.dart';

///
class BankAccountViewModel extends BaseViewModel<AccountViewState>
    with EventMixin<AppEvent> {
  ///
  final AppNavigation appNavigation;

  ///
  final AccountDetailsRepository accountDetailsRepository;

  ///
  final IfscRepository ifscRepository;

  ///
  final LocalStorage localStorage;

  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  TextEditingController accountHolderController = TextEditingController();

  ///
  TextEditingController accountNoController = TextEditingController();

  ///
  TextEditingController reAccountNoController = TextEditingController();

  ///
  TextEditingController ifscController = TextEditingController();

  ///
  TextEditingController bankNameController = TextEditingController();

  ///
  TextEditingController branchController = TextEditingController();

  ///
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  ///
  BankAccountViewModel(this.appNavigation, this.localStorage,
      this.accountDetailsRepository, this.ifscRepository)
      : super(AccountViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        notifyListeners();
      }
    });
  }

  ///
  void init(BuildContext context) {
    accountDetailConsumer(context);
  }

  ///
  void checkValidate({required BuildContext context}) {
    accountDetailsSave(context);
  }
  ///
  void clearText({required BuildContext context}) {
    AutoRouter.of(context).maybePop();
    accountHolderController.clear();
    accountNoController.clear();
    reAccountNoController.clear();
    ifscController.clear();
    bankNameController.clear();
    branchController.clear();
  }

  ///
  ///accountDetailSave
  ///
  void accountDetailsSave(BuildContext context) async {
    showLoader(context);
    setState(state.copyWith(isLoad: true, buttonLoad: true));
    ApiResult<AccountDetailsResponse> result = await runApiInSafeZone(() =>
        accountDetailsRepository.accountDetailSave(AccountDetailsRequest(
                keykjm: localStorage.retrieveString(StorageKey.keykjm),
                ifscCode: ifscController.text.trim(),
                accId: 0,
                accHolderName: accountHolderController.text.trim(),
                accNo: accountNoController.text.trim(),
                branchName: branchController.text.trim(),
                bankName: bankNameController.text.trim())
            .toJson()));
    if (result.isSucceeded) {
      hideLoader(context);
      setState(state.copyWith(isLoad: false, buttonLoad: false));
      AutoRouter.of(context).maybePop();
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: false,
              doneButtonText: LocaleKeys.ok.tr(),
              subTitle: localLanguage?.keyYouAreLoggedInAnotherDevice ?? LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      }
      if (result.data?.data?.message == 'Account Number is Already Exist') {
        AppSnackBar.warningSnackBar(context,
            contentMessage: localLanguage?.keyAccountNumberAlreadyExist ??LocaleKeys.accountNumberAlreadyExist.tr());
      } else {
        await navigateToSuccess(context);
        clearTextField();
      }
      accountDetailConsumer(context);
    } else {
      hideLoader(context);
      setState(state.copyWith(isLoad: false, buttonLoad: false));
      ApiResult.catchError(result, context);
    }
  }

  ///
  void getBranchName() async {
    if (ifscController.text.length == 11) {
      ApiResult<IfscResponse> result = await runApiInSafeZone(
          () => ifscRepository.fetchIfsc(ifscController.text));

      if (result.isSucceeded) {
        bankNameController.text = result.data?.bank ?? '';
        branchController.text = result.data?.branch ?? '';
      }
    }
  }

  ///
  Future<void> navigateToSuccess(BuildContext context) async {
    await AutoRouter.of(context).push(ApiSuccessScreen(
        onTap: () {
          AutoRouter.of(context).maybePop();
        },
        title: localLanguage?.keySuccessful ?? LocaleKeys.successful.tr(),
        image: Assets.images.group321.path,
        subTitle: LocaleKeys.bankAccountAdded.tr()));
  }

  ///
  void clearTextField() {
    accountHolderController.clear();
    accountNoController.clear();
    reAccountNoController.clear();
    ifscController.clear();
    bankNameController.clear();
    branchController.clear();
  }

  ///
  void showConfirmDialog(
    BuildContext context,
    int accId, {
    String? okText,
    String? cancelText,
  }) {
    confirmationDialog(context,
        cancelButtonText: cancelText,
        doneButtonText: okText,
        image: Assets.images.imgAccountRemoved.path,
        subTitle: localLanguage?.keyYouWantDeleteAccount ??
            LocaleKeys.doYouWantDeleteAccount.tr(), onTap: () {
      AutoRouter.of(context).maybePop();
      accountDetailDelete(
        context,
        accId,
      );
    });
  }

  ///
  ///accountDetailDelete
  ///

  void accountDetailDelete(BuildContext context, int accId) async {
    showLoader(context);
    ApiResult<AccountDetailsResponse?> result = await runApiInSafeZone(
        () => accountDetailsRepository.accountDetailDelete(accId));
    if (result.isSucceeded) {
      debugPrint(result.data?.toString());
      hideLoader(context);
      AutoRouter.of(context).maybePop();
      await AutoRouter.of(context).push(ApiSuccessScreen(
          onTap: () {
            AutoRouter.of(context).maybePop();
          },
          title: localLanguage?.keySuccessful ?? LocaleKeys.successful.tr(),
          image: Assets.images.imgAccountRemoved.path,
          subTitle: localLanguage?.keyBankAccountRemoved ??
              LocaleKeys.bankAccountRemoved.tr()));
      accountDetailConsumer(context);
    } else {
      hideLoader(context);
      ApiResult.catchError(result, context);
    }
  }

  ///
  ///accountDetailConsumer
  ///

  void accountDetailConsumer(
    BuildContext context,
  ) async {
    setState(state.copyWith(isLoad: true));
    ApiResult<AccountDetailsResponse?> result = await runApiInSafeZone(
        () => accountDetailsRepository.accountDetailConsumer());
    if (result.isSucceeded) {
      setState(state.copyWith(isLoad: false));
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              doneButtonText: LocaleKeys.ok.tr(),
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          },
              title: localLanguage?.keyYourLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      } else {
        setState(state.copyWith(accountDetailsResponse: result.data));
        localStorage.save(
            'accId', result.data?.data?.accountDetails?[0].accId ?? 0);
      }
    } else {
      setState(state.copyWith(isLoad: false));
      ApiResult.catchError(result, context);
    }
  }
}
