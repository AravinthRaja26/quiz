import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/repository/language/language_repository.dart';
import 'package:nikitchem/data/repository/user_profile/user_profile_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/user_profile/user_profile_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class UserProfileProvider extends StatelessWidget {
  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;

  ///
  const UserProfileProvider({super.key, required this.builder, this.child});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<UserProfileViewModel>(
        builder: builder,
        lazy: false,
        create: (BuildContext context) {
          return UserProfileViewModel(
            injector<LocalStorage>(),
            injector<UserProfileRepository>(),
            injector<AppNavigation>(),
            injector<LanguageRepository>(),
          )..init(context);
        });
  }
}
