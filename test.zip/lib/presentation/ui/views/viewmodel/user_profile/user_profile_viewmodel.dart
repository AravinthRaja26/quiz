import 'dart:async';
import 'dart:io';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/language_model/local_language.dart';
import 'package:nikitchem/data/models/user_profile/profile_update_body.dart';
import 'package:nikitchem/data/models/user_profile/user_profile.dart';
import 'package:nikitchem/data/models/user_profile/version_validate.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/language/language_repository.dart';
import 'package:nikitchem/data/repository/user_profile/user_profile_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/utils/valitaion.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/user_profile/user_profile_viewstate.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:string_extensions/string_extensions.dart';

///
class UserProfileViewModel extends BaseViewModel<UserProfileViewState>
    with EventMixin<AppEvent> {
  ///
  final LocalStorage localStorage;

  ///
  final UserProfileRepository userProfileRepository;

  ///
  final LanguageRepository languageRepository;

  ///
  GlobalKey<FormState> form = GlobalKey<FormState>();

  ///
  AppNavigation appNavigation;

  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  TextEditingController emailController = TextEditingController();

  ///
  TextEditingController phoneController = TextEditingController();

  ///
  TextEditingController userNameController = TextEditingController();

  ///
  UserProfileViewModel(this.localStorage, this.userProfileRepository,  this.appNavigation, this.languageRepository)
      : super(UserProfileViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        notifyListeners();
      }
    });
  }

  ///
  void init(BuildContext context) async {
    List<ConnectivityResult> connectivityResult =
        await (Connectivity().checkConnectivity());
    if (connectivityResult.contains( ConnectivityResult.none)) {
      appNavigation.navigationToNetWorkScreen(context);
    }
    String? phoneNumber =
        localStorage.retrieveString(StorageKey.userPhoneNumber);
    phoneController.text = phoneNumber.toString();
    ApiResult<VersionValidateResponse> result =
        await runApiInSafeZone(() => userProfileRepository.versionValidation());

    if (result.isSucceeded) {
      if (result.data?.data?.status == 'error') {
        confirmationDialog(context,
            showCancelButton: false,
            doneButtonText: LocaleKeys.ok.tr(), onTap: () {
          AutoRouter.of(context).maybePop();
        }, subTitle: result.data?.data?.message);
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              showCancelButton: false,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        }
      } else {
        userNameController.text =
            result.data?.data?.consumer?.firstName?.toTitleCase!.toString() ??
                ''.trim();
        emailController.text = result.data?.data?.consumer?.email?.trim() ?? '';
        setState(
            state.copyWith(userNameLength: userNameController.text.length));
        dynamic accountBalance = result.data?.data?.consumer?.accBalance;
        if (accountBalance != null) {
          if (accountBalance is String) {
            localStorage.save(
                StorageKey.accountBalance, double.parse(accountBalance));
          } else if (accountBalance is int) {
            localStorage.save(StorageKey.accountBalance,
                double.parse(accountBalance.toString()));
          }
        }
      }
    } else {
      ApiResult.catchError(result, context);
    }

    getLanguage();

    setState(state.copyWith(phoneNumber: phoneNumber));
  }

  ///
  Future<void> getLanguage() async {
    ApiResult<LanguageResponse> result = await runApiInSafeZone(() =>
        languageRepository.getLanguage(
            language: localStorage.retrieveString(StorageKey.selectLanguage) ??
                '${Platform.localeName[0]}${Platform.localeName[1]}'));
    if (result.isSucceeded) {
      localLanguage = result.data?.language;
      notifyListeners();
      fireEvent(const LanguageEvent());
    } else {}
  }

  ///
  void goToLogin({required BuildContext context}) {
    localStorage.save(StorageKey.isLogin, false);
    localStorage.save(StorageKey.isFinishedTutorial, true);
    appNavigation.navigationToLoginScreen(context);
  }

  ///
  void saveUserProfile({required BuildContext context}) async {
    if (emailController.text != '' && emailValidation() != null) {
      AppSnackBar.successSnackBar(context, contentMessage: emailValidation());
    } else {
      setState(state.copyWith(load: true));
      ApiResult<UserProfileResponse> result = await runApiInSafeZone(() =>
          userProfileRepository.saveConsumerDetail(
              userName: userNameController.text, email: emailController.text));

      if (result.isSucceeded) {
        setState(state.copyWith(load: false));
        saveDate();
        navigateHomeScreen(context);

        if (emailController.text != '') {
          localStorage.save(StorageKey.userEmail, emailController.text);
        }
      } else {
        setState(state.copyWith(load: false));
        ApiResult.catchError(result, context);
      }
    }
  }

  ///
  String? getCountryCode(){
    return localStorage.retrieveString(StorageKey.countryCode);
  }

  ///
  void saveDate() {
    localStorage.save(StorageKey.isProfileUpdate, true);
    localStorage.save(StorageKey.isLogin, false);
    localStorage.save(StorageKey.isFinishedTutorial, false);
    localStorage.save(StorageKey.userName, userNameController.text);
  }

  ///
  void navigateHomeScreen(BuildContext context) {
    appNavigation.toHomeScreen(context, isShowSuccessAlert: false);
  }

  ///
  String? userNameValidation() {
    return AppValidation.userNameVerification(userNameController.text);
  }

  ///
  String? emailValidation() {
    return AppValidation.emailVerification(emailController.text);
  }

  ///
  void navigateToChangeLanguage(BuildContext context) {
    appNavigation.navigationToLanguage(context);
  }

  ///
  void setUserNameLength({required String value}) {
    setState(state.copyWith(userNameLength: value.length));
  }
}
