// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_profile_viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$UserProfileViewStateCWProxy {
  UserProfileViewState phoneNumber(String phoneNumber);

  UserProfileViewState userNameLength(int userNameLength);

  UserProfileViewState load(bool load);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `UserProfileViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// UserProfileViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  UserProfileViewState call({
    String? phoneNumber,
    int? userNameLength,
    bool? load,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfUserProfileViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfUserProfileViewState.copyWith.fieldName(...)`
class _$UserProfileViewStateCWProxyImpl
    implements _$UserProfileViewStateCWProxy {
  const _$UserProfileViewStateCWProxyImpl(this._value);

  final UserProfileViewState _value;

  @override
  UserProfileViewState phoneNumber(String phoneNumber) =>
      this(phoneNumber: phoneNumber);

  @override
  UserProfileViewState userNameLength(int userNameLength) =>
      this(userNameLength: userNameLength);

  @override
  UserProfileViewState load(bool load) => this(load: load);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `UserProfileViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// UserProfileViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  UserProfileViewState call({
    Object? phoneNumber = const $CopyWithPlaceholder(),
    Object? userNameLength = const $CopyWithPlaceholder(),
    Object? load = const $CopyWithPlaceholder(),
  }) {
    return UserProfileViewState(
      phoneNumber:
          phoneNumber == const $CopyWithPlaceholder() || phoneNumber == null
              ? _value.phoneNumber
              // ignore: cast_nullable_to_non_nullable
              : phoneNumber as String,
      userNameLength: userNameLength == const $CopyWithPlaceholder() ||
              userNameLength == null
          ? _value.userNameLength
          // ignore: cast_nullable_to_non_nullable
          : userNameLength as int,
      load: load == const $CopyWithPlaceholder() || load == null
          ? _value.load
          // ignore: cast_nullable_to_non_nullable
          : load as bool,
    );
  }
}

extension $UserProfileViewStateCopyWith on UserProfileViewState {
  /// Returns a callable class that can be used as follows: `instanceOfUserProfileViewState.copyWith(...)` or like so:`instanceOfUserProfileViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$UserProfileViewStateCWProxy get copyWith =>
      _$UserProfileViewStateCWProxyImpl(this);
}
