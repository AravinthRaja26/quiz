import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:copy_with_extension/copy_with_extension.dart';

part 'user_profile_viewstate.g.dart';

///
@CopyWith()
class UserProfileViewState extends ViewState {
  ///
  final String phoneNumber;

  ///
  final int userNameLength;

  ///
  final bool load;

  ///
  const UserProfileViewState(
      {required this.phoneNumber,
      required this.userNameLength,
      required this.load});

  ///
  UserProfileViewState.initial()
      : phoneNumber = '',
        userNameLength = 0,
        load = false;

  @override
  List<Object?> get props => <Object>[phoneNumber, userNameLength, load];
}
