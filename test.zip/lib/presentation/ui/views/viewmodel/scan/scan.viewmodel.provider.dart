import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/repository/scan/scan.repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/scan/scan.viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class ScanProvider extends StatelessWidget {
  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;
  final TickerProvider? tickerProvider;

  ///
  const ScanProvider({super.key, required this.builder, this.child,required this.tickerProvider});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<ScanViewModel>(
        builder: builder,
        lazy: false,
        child: child,
        create: (BuildContext context) {
          return ScanViewModel(
            injector<LocalStorage>(),
            injector<AppNavigation>(),
            injector<ScanRepository>(),
            context
          )..init(context,ticker: tickerProvider);
        });
  }
}
