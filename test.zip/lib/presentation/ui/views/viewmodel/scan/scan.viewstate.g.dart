// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'scan.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$ScanViewStateCWProxy {
  ScanViewState onCameraAccess(bool onCameraAccess);

  ScanViewState cameraPermission(bool cameraPermission);

  ScanViewState proceedButton(bool proceedButton);

  ScanViewState cameraPermissionText(String? cameraPermissionText);

  ScanViewState onFlashLight(bool onFlashLight);

  ScanViewState isEnable(bool isEnable);

  ScanViewState scanCouponResponse(ScanCouponResponse? scanCouponResponse);

  ScanViewState isScanEffect(bool isScanEffect);

  ScanViewState isTryAgain(bool isTryAgain);

  ScanViewState isCameraPermissionGranted(bool isCameraPermissionGranted);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `ScanViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// ScanViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  ScanViewState call({
    bool? onCameraAccess,
    bool? cameraPermission,
    bool? proceedButton,
    String? cameraPermissionText,
    bool? onFlashLight,
    bool? isEnable,
    ScanCouponResponse? scanCouponResponse,
    bool? isScanEffect,
    bool? isTryAgain,
    bool? isCameraPermissionGranted,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfScanViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfScanViewState.copyWith.fieldName(...)`
class _$ScanViewStateCWProxyImpl implements _$ScanViewStateCWProxy {
  const _$ScanViewStateCWProxyImpl(this._value);

  final ScanViewState _value;

  @override
  ScanViewState onCameraAccess(bool onCameraAccess) =>
      this(onCameraAccess: onCameraAccess);

  @override
  ScanViewState cameraPermission(bool cameraPermission) =>
      this(cameraPermission: cameraPermission);

  @override
  ScanViewState proceedButton(bool proceedButton) =>
      this(proceedButton: proceedButton);

  @override
  ScanViewState cameraPermissionText(String? cameraPermissionText) =>
      this(cameraPermissionText: cameraPermissionText);

  @override
  ScanViewState onFlashLight(bool onFlashLight) =>
      this(onFlashLight: onFlashLight);

  @override
  ScanViewState isEnable(bool isEnable) => this(isEnable: isEnable);

  @override
  ScanViewState scanCouponResponse(ScanCouponResponse? scanCouponResponse) =>
      this(scanCouponResponse: scanCouponResponse);

  @override
  ScanViewState isScanEffect(bool isScanEffect) =>
      this(isScanEffect: isScanEffect);

  @override
  ScanViewState isTryAgain(bool isTryAgain) => this(isTryAgain: isTryAgain);

  @override
  ScanViewState isCameraPermissionGranted(bool isCameraPermissionGranted) =>
      this(isCameraPermissionGranted: isCameraPermissionGranted);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `ScanViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// ScanViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  ScanViewState call({
    Object? onCameraAccess = const $CopyWithPlaceholder(),
    Object? cameraPermission = const $CopyWithPlaceholder(),
    Object? proceedButton = const $CopyWithPlaceholder(),
    Object? cameraPermissionText = const $CopyWithPlaceholder(),
    Object? onFlashLight = const $CopyWithPlaceholder(),
    Object? isEnable = const $CopyWithPlaceholder(),
    Object? scanCouponResponse = const $CopyWithPlaceholder(),
    Object? isScanEffect = const $CopyWithPlaceholder(),
    Object? isTryAgain = const $CopyWithPlaceholder(),
    Object? isCameraPermissionGranted = const $CopyWithPlaceholder(),
  }) {
    return ScanViewState(
      onCameraAccess == const $CopyWithPlaceholder() || onCameraAccess == null
          ? _value.onCameraAccess
          // ignore: cast_nullable_to_non_nullable
          : onCameraAccess as bool,
      cameraPermission: cameraPermission == const $CopyWithPlaceholder() ||
              cameraPermission == null
          ? _value.cameraPermission
          // ignore: cast_nullable_to_non_nullable
          : cameraPermission as bool,
      proceedButton:
          proceedButton == const $CopyWithPlaceholder() || proceedButton == null
              ? _value.proceedButton
              // ignore: cast_nullable_to_non_nullable
              : proceedButton as bool,
      cameraPermissionText: cameraPermissionText == const $CopyWithPlaceholder()
          ? _value.cameraPermissionText
          // ignore: cast_nullable_to_non_nullable
          : cameraPermissionText as String?,
      onFlashLight:
          onFlashLight == const $CopyWithPlaceholder() || onFlashLight == null
              ? _value.onFlashLight
              // ignore: cast_nullable_to_non_nullable
              : onFlashLight as bool,
      isEnable: isEnable == const $CopyWithPlaceholder() || isEnable == null
          ? _value.isEnable
          // ignore: cast_nullable_to_non_nullable
          : isEnable as bool,
      scanCouponResponse: scanCouponResponse == const $CopyWithPlaceholder()
          ? _value.scanCouponResponse
          // ignore: cast_nullable_to_non_nullable
          : scanCouponResponse as ScanCouponResponse?,
      isScanEffect:
          isScanEffect == const $CopyWithPlaceholder() || isScanEffect == null
              ? _value.isScanEffect
              // ignore: cast_nullable_to_non_nullable
              : isScanEffect as bool,
      isTryAgain:
          isTryAgain == const $CopyWithPlaceholder() || isTryAgain == null
              ? _value.isTryAgain
              // ignore: cast_nullable_to_non_nullable
              : isTryAgain as bool,
      isCameraPermissionGranted:
          isCameraPermissionGranted == const $CopyWithPlaceholder() ||
                  isCameraPermissionGranted == null
              ? _value.isCameraPermissionGranted
              // ignore: cast_nullable_to_non_nullable
              : isCameraPermissionGranted as bool,
    );
  }
}

extension $ScanViewStateCopyWith on ScanViewState {
  /// Returns a callable class that can be used as follows: `instanceOfScanViewState.copyWith(...)` or like so:`instanceOfScanViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$ScanViewStateCWProxy get copyWith => _$ScanViewStateCWProxyImpl(this);
}
