import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/scan/scan_coupon_response.model.dart';
import 'package:copy_with_extension/copy_with_extension.dart';

part 'scan.viewstate.g.dart';

///
@CopyWith()
class ScanViewState extends ViewState {
  ///
  final bool cameraPermission;

  ///
  bool isScanEffect = false;

  ///
  bool isTryAgain = false;

  ///
  final bool isCameraPermissionGranted;

  ///
  final bool onFlashLight;

  ///
  final bool isEnable;

  ///
  final bool onCameraAccess;

  ///
  final bool proceedButton;

  ///
  final String? cameraPermissionText;

  ///
  ScanCouponResponse? scanCouponResponse;

  ///

  ScanViewState(this.onCameraAccess,
      {required this.cameraPermission,
      required this.proceedButton,
      required this.cameraPermissionText,
      required this.onFlashLight,
      required this.isEnable,
      this.scanCouponResponse,
      required this.isScanEffect,
      required this.isTryAgain,
      required this.isCameraPermissionGranted});

  ///
  /// Named Constructor for initial state
  ///
  ScanViewState.initial()
      : cameraPermission = false,
        cameraPermissionText = '',
        onFlashLight = false,
        isScanEffect = false,
        isTryAgain = false,
        proceedButton = false,
        onCameraAccess = false,
        isEnable = false,
        scanCouponResponse = ScanCouponResponse(),
        isCameraPermissionGranted = false;

  ///
  /// Props
  ///
  @override
  List<Object?> get props => <Object?>[
        cameraPermission,
        cameraPermissionText,
        isScanEffect,
        onFlashLight,
        scanCouponResponse,
        onCameraAccess,
        proceedButton,
        isEnable,
        isTryAgain,
        isCameraPermissionGranted
      ];
}
