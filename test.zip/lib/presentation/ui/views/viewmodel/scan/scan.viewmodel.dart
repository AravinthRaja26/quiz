import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:ai_barcode_scanner/ai_barcode_scanner.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter/scheduler.dart';
import 'package:nikitchem/application/events/dashboard_event.dart';
import 'package:nikitchem/application/events/enquiry_event.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/events/scan_coupon_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/scan/scan_coupon_request.model.dart';
import 'package:nikitchem/data/models/scan/scan_coupon_response.model.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/scan/scan.repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/scan/scan.viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

///
class ScanViewModel extends BaseViewModel<ScanViewState>
    with EventMixin<AppEvent>, WidgetsBindingObserver {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  final RegExp _phoneRegex = RegExp(r'^([0-9])\1{2}\1{3}\1{4}$');

  ///
  FocusNode focusNode = FocusNode();


  ///
  MobileScannerController qrController =  MobileScannerController(
    detectionSpeed: DetectionSpeed.noDuplicates,
    autoStart: true,
  );


  ///
  AnimationController? controller;
  ///
  AnimationController? resetController;
  ///
  BuildContext context;

  ///
  ScanViewModel(
      this.localStorage, this.appNavigation, this.scanRepository, this.context)
      : super(ScanViewState.initial()) {
    WidgetsBinding.instance.addObserver(this);
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        notifyListeners();
      }
    });
  }

  ///

  ///
  ScanRepository scanRepository;

  ///
  LocalStorage localStorage;

  ///
  AppNavigation appNavigation;

  ///

  Barcode? qrData;

  ///
  PermissionStatus? status;

  ///
  TextEditingController couponController = TextEditingController();

  ///
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  ///
  // QRViewController? controller;

  ///
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');

  ///
  /// enter to load initial
  ///
  void init(BuildContext context,{required TickerProvider? ticker}) async {

    controller =  AnimationController(
      duration: const Duration(seconds: 2),
      vsync: ticker!,
    )..repeat(reverse: true);

    resetController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: ticker,
    )..repeat(reverse: true);

    // _determinePosition();

    status = await Permission.camera.status;
    setState(state.copyWith(
        isCameraPermissionGranted: status == PermissionStatus.granted));
    if (!state.isCameraPermissionGranted) {
      PermissionStatus currentPermission = await Permission.camera.request();
      setState(state.copyWith(
          isCameraPermissionGranted:
              currentPermission == PermissionStatus.granted));
      if (!state.isCameraPermissionGranted) {
        confirmationDialog(
          context,
          doneButtonText: localLanguage?.keyAllow ?? LocaleKeys.allow.tr(),
          subTitle: localLanguage?.keyDisabledCamera ??
              'You have disabled the camera access earlier. Please enable it again.' ??
              'You have disabled the camera access earlier. Please enable it again.',
          onTap: () {
            AutoRouter.of(context).maybePop();
            openAppSettings();
          },
          title: localLanguage?.appPermission ?? LocaleKeys.appPermission,
          image: AssetImagePath.cameraAccess,
        );
      }
    }
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      permission = await Geolocator.requestPermission();
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
    }
    if (permission == LocationPermission.deniedForever) {
      permission = await Geolocator.requestPermission();

      confirmationDialog(
        context,
        doneButtonText: localLanguage?.keyAllow ?? LocaleKeys.allow.tr(),
        subTitle: localLanguage?.keyYouHaveDisabledLocationAccessEarlier ??
            LocaleKeys.YouHaveDisabledLocationAccessEarlier.tr(),
        onTap: () {
          AutoRouter.of(context).maybePop();
        },
        title: localLanguage?.appPermission ??
            LocaleKeys.appPermission.tr() ??
            'App Permission',
        image: AssetImagePath.locationPermission,
      );
    }
    return Geolocator.getCurrentPosition();
  }

  ///
  void updateCameraPermissionStatus() async {
    bool isCameraPermissionGranted =
        await Permission.camera.status == PermissionStatus.granted;
    setState(
        state.copyWith(isCameraPermissionGranted: isCameraPermissionGranted));
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      updateCameraPermissionStatus();
    }
    super.didChangeAppLifecycleState(state);
  }

  ///
  void couponCodeButtonEnable() {
    if (couponController.text.isNotEmpty) {
      setState(state.copyWith(isEnable: true, isScanEffect: true));
      qrController.stop();
    } else {
      setState(state.copyWith(
          isEnable: false, isScanEffect: false, proceedButton: false));
      qrController.start();
      controller = resetController;
    }
    if (couponController.text.length > 7) {
      setState(state.copyWith(proceedButton: true));
      qrController.stop();
    } else if (couponController.text.length < 8) {
      setState(state.copyWith(proceedButton: false));
      qrController.stop();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  ///
  void checkEvent(BuildContext context) {
    fireEvent(const DashboardEvent('Online'));
  }

  ///
  // onQRViewCreated(QRViewController controller) async {
  //   this.controller = controller;
  //
  //   controller.scannedDataStream.listen((Barcode scanData) async {
  //     qrData = scanData;
  //     debugPrint('====>${qrData?.code}');
  //     notifyListeners();
  //     if (qrData?.code?.isNotEmpty == true) {
  //       setState(state.copyWith(
  //         isScanEffect: true,
  //       ));
  //       controller.pauseCamera();
  //       await _determinePosition().catchError((dynamic onError) {
  //         controller.resumeCamera();
  //       });
  //       showLoader(context);
  //       scanCouponDetail(context: context);
  //     }
  //     controller.resumeCamera();
  //   });
  // }

  ///
  Future<void> getData() async {
    await qrController.toggleTorch();
    if (!state.onFlashLight) {
      setState(state.copyWith(onFlashLight: true));
    } else {
      setState(state.copyWith(onFlashLight: false));
    }
  }

  ///
  Future<void> getCameraAccess() async {
    await qrController.switchCamera();
    if (!state.onCameraAccess) {
      setState(state.copyWith(onCameraAccess: true));
    } else {
      setState(state.copyWith(onCameraAccess: false));
    }
  }

  ///
  void resumeCamera() {
    setState(state.copyWith(isScanEffect: true));
    qrController.start();
    controller = resetController;
  }

  ///
  void navigationToCouponCodeScreen(BuildContext context) async {
    qrController.stop();
    setState(state.copyWith(isScanEffect: true));
    await appNavigation.navigationToCouponCodeScreen(context).then((value) {
      setState(state.copyWith(isScanEffect: false));
      qrController.start();
      controller = resetController;
    });
  }

  ///
  void onPermissionSet(
      BuildContext context,  bool permission) {
    log('${DateTime.now().toIso8601String()}_onPermissionSet $permission');
    if (!permission) {
      localStorage.save(StorageKey.cameraPermission, true);
      setState(state.copyWith(cameraPermission: true));
    } else {
      localStorage.save(StorageKey.cameraPermission, false);
      setState(state.copyWith(cameraPermission: false));
    }
    notifyListeners();
  }

  ///
  void clearText() {
    couponController.clear();
    qrController.start();
    controller = resetController;
    setState(state.copyWith(isScanEffect: true, isEnable: false));
  }

  ///
  void codeCoupon(BuildContext context) async {
    if (_phoneRegex.hasMatch(couponController.text)) {
      AppSnackBar.successSnackBar(context,
          contentMessage: localLanguage?.keyInvalidPhoneNumber ??
              LocaleKeys.invalidPhoneNumber.tr());
    } else {
      showLoader(context);
      await _determinePosition();
      scanCouponDetail(context: context);
    }
  }

  ///
  /// scan Coupon Detail
  ///
  void scanCouponDetail({required BuildContext? context,String? qrValue}) async {
    qrController.stop();
    focusNode.unfocus();
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    ApiResult<ScanCouponResponse?> result = await runApiInSafeZone(
        () => scanRepository.scanCouponDetail(ScanCouponRequest(
              deviceOs: Platform.operatingSystem.toString(),
              keykjm: localStorage.retrieveString(StorageKey.keykjm).toString(),
              couponCode: couponController.text.isEmpty
                  ? qrValue.toString()
                  : couponController.text,
              platForm: Platform.isAndroid ? 'android' : 'ios',
              latitude: '${localStorage.retrieveDouble(StorageKey.latitude)}',
              longitude: '${localStorage.retrieveDouble(StorageKey.longitude)}',
            ).toJson()));
    if (result.isSucceeded) {
      qrController.start();
      controller = resetController;
      fireEvent(const EnquiryEvent());
      if (context!.mounted) {
        hideLoader(context);
      }

      if (result.data?.status == 'error') {
        setState(state.copyWith(isScanEffect: true));
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              doneButtonText: localLanguage?.keyOk ?? LocaleKeys.ok.tr(),
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: false,
              subTitle: localLanguage?.keyYouAreLoggedInAnotherDevice ??
                  LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          },
              title: localLanguage?.keyYouAreLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
        } else {
          couponAlert(context,
              doneButtonText:
                  localLanguage?.keyTryAgain ?? LocaleKeys.tryAgain.tr(),
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: true,
              image: result.data?.data?.errorMessage == 'Invalid Coupon!'
                  ? 'assets/images/group_402.png'
                  : result.data?.data?.errorMessage == 'Coupon expired'
                      ? 'assets/images/group_403.png'
                      : 'assets/images/log_out.png',
              subTitle: result.data?.data?.errorMessage == 'Invalid Coupon!'
                  ? localLanguage?.keyInvalidCouponCode ??
                      LocaleKeys.invalidCouponCode.tr()
                  : result.data?.data?.errorMessage == 'Coupon expired'
                      ? localLanguage?.keyExpiredCouponCode ??
                          LocaleKeys.expiredCouponCode.tr()
                      : '',
              subTitle2: result.data?.data?.errorMessage == 'Invalid Coupon!' ||
                      result.data?.data?.errorMessage == 'Coupon expired'
                  ? localLanguage?.keyValidCoupon ?? 'Please use a valid one.'
                  : result.data?.data?.errorMessage, onTap: () {
            state.isTryAgain == true;
            if (state.isTryAgain == true) {
              AutoRouter.of(context).maybePop();
            }
            AutoRouter.of(context).maybePop();
            setState(state.copyWith(isScanEffect: false));
            qrController.start();
            controller = resetController;
          });
        }
      } else {
        couponController.clear();
        setState(state.copyWith(
            isScanEffect: true,
            scanCouponResponse: result.data,
            proceedButton: false));
        clearText();
        localStorage.save(
            StorageKey.accountBalance, result.data?.data?.balance);
        fireEvent(const ScanCouponEvent());
        if (result.data?.data?.couponAmount != null) {
          qrController.start();
          controller = resetController;
          await navigateToSuccessScreen(
              context, result.data?.data?.couponAmount);
          setState(state.copyWith(isScanEffect: false));
          notifyListeners();
          qrController.start();
          controller = resetController;
        } else {
          confirmationDialog(context,
              doneButtonText:
                  localLanguage?.keyTryAgain ?? LocaleKeys.tryAgain.tr(),
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: true,
              image: 'assets/images/already_scan.png',
              subTitle: 'Already coupon scanned', onTap: () {
            AutoRouter.of(context).maybePop();
            qrController.start();
            controller = resetController;
            setState(state.copyWith(isScanEffect: false));
          });
        }
      }
    } else {
      qrController.stop();
      setState(state.copyWith(isScanEffect: false));
      if (context!.mounted) {
        hideLoader(context);
        await ApiResult.catchError(result, context);
      }
      qrController.start();
      controller = resetController;
    }
  }

  ///
  Future<void> navigateToSuccessScreen(
      BuildContext context, double? couponAmount) async {
    await AutoRouter.of(context).push(ApiSuccessScreen(
        onTap: () async {
         await AutoRouter.of(context).maybePop();
         AutoRouter.of(context).maybePop();
        },
        image: AssetImagePath.scanCouponSuccess,
        subTitle: localLanguage?.keyYourCouponPoints != null &&
                localLanguage?.keyAddedIntoYourWalletSuccessfully != null
            ? '${localLanguage?.keyYourCouponPoints} $couponAmount ${localLanguage?.keyAddedIntoYourWalletSuccessfully}'
            : LocaleKeys.yourCouponPointsAddedIntoYourWalletSuccessfully.tr(
                namedArgs: <String, String>{
                    'points': '${couponAmount?.toInt()}'
                  }),
        title: localLanguage?.keyCongratulations ??
            LocaleKeys.congratulations.tr(),
        isScanScreen: true,
        buttonName: localLanguage?.keyGoBackHome ?? 'Go Back Home'));
  }
}
