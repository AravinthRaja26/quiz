import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/login/otp_response.dart';
import 'package:nikitchem/data/models/login/otp_verification_response.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/login/login_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/infrastructure/utils/app.text.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/utils/valitaion.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/login/otp_verification_viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

///
class OtpVerificationVieModel extends BaseViewModel<OtpVerificationViewState>
    with EventMixin<AppEvent> {
  ///
  TextEditingController otpController = TextEditingController();

  ///
  ///
  LoginRepository loginRepository;

  ///
  AppNavigation appNavigation;

  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  LocalStorage localStorage;

  ///
  GlobalKey<FormState> form = GlobalKey<FormState>();

  ///
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  ///
  OtpVerificationVieModel(
      this.loginRepository, this.localStorage, this.appNavigation)
      : super(OtpVerificationViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        notifyListeners();
      }
    });
  }

  ///
  void init({String? phoneNumber}) {
    setState(state.copyWith(phoneNumber: phoneNumber));
    /* Future<dynamic>.delayed(const Duration(seconds: 6), () {
      setState(state.copyWith(reSendButtonEnable: true));
    });*/
  }

  ///
  String? otpValidate() {
    return AppValidation.otpVerification(otpController.text);
  }

  ///
  void reSendGetOtp({required BuildContext context}) async {
    setState(state.copyWith(reSendButtonEnable: false));
    showLoader(context);
    ApiResult<OtpResponse> result = await runApiInSafeZone(
        () => loginRepository.getOtp(phoneNumber: state.phoneNumber,countryCode: AppText.defaultCountryCode));
    if (result.isSucceeded) {
      otpController.clear();
      SnackBar(
          content:
              TextVariant(data: result.data?.otp?.message.toString() ?? ''));
      /* Future<dynamic>.delayed(const Duration(seconds: 30), () {
        setState(state.copyWith(reSendButtonEnable: true));
      });*/
    } else {
      hideLoader(context);
      ApiResult.catchError(result, context);
      /*    Future<dynamic>.delayed(const Duration(seconds: 30), () {
        setState(state.copyWith(reSendButtonEnable: true));
      });*/
    }
    hideLoader(context);
  }

  ///
  String? phoneValidate(String value) {
    return AppValidation.phoneValidation(value);
  }

  ///

  void enableResendCode() {
    setState(state.copyWith(reSendButtonEnable: true));
  }

  ///
  void otpVerificationCall({required BuildContext context}) async {
    setState(state.copyWith(load: true));
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    if (state.otpLength != 4) {
      AppSnackBar.successSnackBar(context, contentMessage: otpValidate());
    } else {
      ApiResult<OtpVerificationResponse> response = await runApiInSafeZone(() =>
          loginRepository.verifyOtp(otpController.text,
              countryCode: AppText.defaultCountryCode,
              phoneNumber:
                  localStorage.retrieveString(StorageKey.userPhoneNumber)));
      if (response.isSucceeded) {
        setState(state.copyWith(load: false));
        if (response.data?.otpVerification?.status == 'Success') {
          localStorage.save(
              StorageKey.keykjm, response.data?.otpVerification?.key);
          localStorage.save(StorageKey.isLogin, true);
          localStorage.save(StorageKey.isFinishedTutorial, false);

          navigationToUserProfile(context: context);
        } else {
          confirmationDialog(context,
              title: 'OTP Verification',
              showCancelButton: false,
              image: 'assets/images/top_wrong.png',
              doneButtonText: localLanguage?.keyOk ?? LocaleKeys.ok.tr(),
              onTap: () {
            AutoRouter.of(context).maybePop();
          },
              subTitle: response.data?.otpVerification?.message ==
                      'OTP is wrong,Please request for new one'
                  ? localLanguage?.keyOtpIsWrong
                  : ' OTP is wrong,Please request for new one');
        }
      } else {
        setState(state.copyWith(load: false));
        ApiResult.catchError(response, context);
      }
      setState(state.copyWith(load: false));
    }
  }

  ///
  void navigationToUserProfile({required BuildContext context}) {
    appNavigation.userProfile(context);
  }

  ///
  void setOtpLength({required String value}) {
    setState(state.copyWith(otpLength: value.length));
  }

  ///
  void navigationToChangeLanguage({required BuildContext context}) {
    appNavigation.navigationToLanguage(context);
  }
}
