// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'otp_verification_viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$OtpVerificationViewStateCWProxy {
  OtpVerificationViewState phoneNumber(String phoneNumber);

  OtpVerificationViewState otpLength(int otpLength);

  OtpVerificationViewState load(bool load);

  OtpVerificationViewState reSendButtonEnable(bool reSendButtonEnable);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `OtpVerificationViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// OtpVerificationViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  OtpVerificationViewState call({
    String? phoneNumber,
    int? otpLength,
    bool? load,
    bool? reSendButtonEnable,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfOtpVerificationViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfOtpVerificationViewState.copyWith.fieldName(...)`
class _$OtpVerificationViewStateCWProxyImpl
    implements _$OtpVerificationViewStateCWProxy {
  const _$OtpVerificationViewStateCWProxyImpl(this._value);

  final OtpVerificationViewState _value;

  @override
  OtpVerificationViewState phoneNumber(String phoneNumber) =>
      this(phoneNumber: phoneNumber);

  @override
  OtpVerificationViewState otpLength(int otpLength) =>
      this(otpLength: otpLength);

  @override
  OtpVerificationViewState load(bool load) => this(load: load);

  @override
  OtpVerificationViewState reSendButtonEnable(bool reSendButtonEnable) =>
      this(reSendButtonEnable: reSendButtonEnable);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `OtpVerificationViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// OtpVerificationViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  OtpVerificationViewState call({
    Object? phoneNumber = const $CopyWithPlaceholder(),
    Object? otpLength = const $CopyWithPlaceholder(),
    Object? load = const $CopyWithPlaceholder(),
    Object? reSendButtonEnable = const $CopyWithPlaceholder(),
  }) {
    return OtpVerificationViewState(
      phoneNumber:
          phoneNumber == const $CopyWithPlaceholder() || phoneNumber == null
              ? _value.phoneNumber
              // ignore: cast_nullable_to_non_nullable
              : phoneNumber as String,
      otpLength: otpLength == const $CopyWithPlaceholder() || otpLength == null
          ? _value.otpLength
          // ignore: cast_nullable_to_non_nullable
          : otpLength as int,
      load: load == const $CopyWithPlaceholder() || load == null
          ? _value.load
          // ignore: cast_nullable_to_non_nullable
          : load as bool,
      reSendButtonEnable: reSendButtonEnable == const $CopyWithPlaceholder() ||
              reSendButtonEnable == null
          ? _value.reSendButtonEnable
          // ignore: cast_nullable_to_non_nullable
          : reSendButtonEnable as bool,
    );
  }
}

extension $OtpVerificationViewStateCopyWith on OtpVerificationViewState {
  /// Returns a callable class that can be used as follows: `instanceOfOtpVerificationViewState.copyWith(...)` or like so:`instanceOfOtpVerificationViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$OtpVerificationViewStateCWProxy get copyWith =>
      _$OtpVerificationViewStateCWProxyImpl(this);
}
