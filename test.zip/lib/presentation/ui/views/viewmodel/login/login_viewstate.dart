import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:copy_with_extension/copy_with_extension.dart';

part 'login_viewstate.g.dart';

///
@CopyWith()
class LoginViewState extends ViewState {
  ///
  final String phoneNumber;
  ///
  final String selectCountry;

  ///
  final int phoneNumberLength;

  ///
  final bool isGetOtp;
  ///
  final bool showPinCode;

  ///
  final bool isLoad;

  ///
  const LoginViewState({
    required this.phoneNumber,
    required this.selectCountry,
    required this.isGetOtp,
    required this.phoneNumberLength,
    required this.showPinCode,
    required this.isLoad,
  });

  ///
  LoginViewState.initial()
      : phoneNumber = '',
        isGetOtp = false,
        phoneNumberLength = 0,
        selectCountry = '+91',
        showPinCode = false,
        isLoad = false;

  @override
  List<Object?> get props =>
      <Object>[phoneNumber, isGetOtp, phoneNumberLength, isLoad,selectCountry,showPinCode];
}
