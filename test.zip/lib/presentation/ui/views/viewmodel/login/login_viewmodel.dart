import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/login/otp_response.dart';
import 'package:nikitchem/data/models/login/otp_verification_response.dart';
import 'package:nikitchem/data/models/login/rest_m_pin_response.dart';
import 'package:nikitchem/data/models/user_profile/user_profile.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/login/login_repository.dart';
import 'package:nikitchem/data/repository/user_profile/user_profile_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_bottom_sheet.dart';
import 'package:nikitchem/presentation/ui/custom_widget/mpin_alert.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/utils/valitaion.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/login/login_viewstate.dart';

///
class LoginViewModel extends BaseViewModel<LoginViewState>
    with EventMixin<AppEvent> {
  final RegExp _phoneRegex = RegExp(r'^([0-9])\1{2}\1{3}\1{4}$');

  ///
  TextEditingController phoneController = TextEditingController();

  ///
  TextEditingController otpController = TextEditingController();

  ///
  AppNavigation appNavigation;

  ///
  List<String> countryList = <String>['+91', '+977'];

  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  LoginRepository loginRepository;

  ///
  UserProfileRepository userProfileRepository =
      injector<UserProfileRepository>();

  ///
  LocalStorage localStorage;

  ///
  GlobalKey<FormState> form = GlobalKey<FormState>();

  ///
  LoginViewModel(this.appNavigation, this.loginRepository, this.localStorage)
      : super(LoginViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  String? phoneValidate(String value) {
    return AppValidation.phoneValidation(value);
  }

  ///
  void init(BuildContext context, {String? phoneNumber}) async {
    List<ConnectivityResult> connectivityResult =
        await (Connectivity().checkConnectivity());
    if (connectivityResult.contains(ConnectivityResult.none)) {
      appNavigation.navigationToNetWorkScreen(context);
    }
    setState(state.copyWith(phoneNumber: phoneNumber));

  }

  ///
  void callGetOtp(BuildContext context) async {
    setState(state.copyWith(isLoad: true));
    ApiResult<OtpResponse> result = await runApiInSafeZone(() =>
        loginRepository.getOtp(
            phoneNumber: phoneController.text,
            countryCode: state.selectCountry));
    if (result.isSucceeded) {
      localStorage.save(StorageKey.countryCode, state.selectCountry);
      setState(state.copyWith(isLoad: false));
      if (result.data?.status == 'error') {
        hideLoader(context);
        if (result.data?.otp?.errorMessage == 'Your account is deleted') {
          confirmationDialog(
            context,
            subTitle: localLanguage?.keyPhoneNumberIsAlreadyRegistered ??
                LocaleKeys.phoneNumberIsAlreadyRegistered.tr(),
            onTap: () {
              reActiveConsumer(context);
            },
            doneButtonText: localLanguage?.keyReActive ?? 'ReActive',
            cancelButtonText: localLanguage?.keyNo ?? 'NO',
          );
        }
        else {
          apiAlertDialog(
            context,
            contentMessage: result.data?.otp?.errorMessage,
            title: 'Oops!',
            buttonName: 'Okay',
            callBack: (){
              AutoRouter.of(context).maybePop();
            }
          );
        }
      } else {
        localStorage.save(StorageKey.userPhoneNumber, phoneController.text);
        navigateToOtpVerification(context: context);
      }
    } else {
      setState(state.copyWith(isLoad: false));
      ApiResult.catchError(result, context);
    }
  }

  ///
  void navigateToOtpVerification({required BuildContext context}) {
    appNavigation.navigationToOtpVerification(context, phoneController.text);
  }

  ///
  void reActiveConsumer(BuildContext context) async {
    showLoader(context);
    ApiResult<UserProfileResponse> reActiveResult = await runApiInSafeZone(
        () => userProfileRepository.reActiveConsumer(phoneController.text));

    if (reActiveResult.isSucceeded) {
      if (reActiveResult.data?.status == 'error') {
        hideLoader(context);
        await AutoRouter.of(context).maybePop();
        AppSnackBar.failureSnackBar(context,
            contentMessage: reActiveResult.data?.consumerDetail?.errorMessage);
      } else {
        hideLoader(context);
        await AutoRouter.of(context).maybePop();
        AppSnackBar.successSnackBar(context,
            contentMessage: reActiveResult.data?.consumerDetail?.message);
      }
    } else {
      ApiResult.catchError(reActiveResult, context);
    }
  }

  ///
  ///
  ///
  void resetMPin(BuildContext context) async {
    setState(state.copyWith(isLoad: true));
    ApiResult<RestMPinResponse> result = await runApiInSafeZone(() =>
        loginRepository.resetMPin(
            countryCode: localStorage.retrieveString(StorageKey.countryCode),
            phoneNumber: phoneController.text));

    if (result.isSucceeded) {
      setState(state.copyWith(isLoad: false));
      if (result.data?.restMPinData?.message != null &&
          result.data!.restMPinData!.message!.contains('is not available!')) {
        apiAlertDialog(context,
            contentMessage: result.data!.restMPinData!.message, callBack: () {
          AutoRouter.of(context).maybePop();
        }, buttonName: 'Okay', title: 'Oops!');
      } else {
        forgetPasswordBottomSheet(
            context: context,
            phoneNumber: result.data?.restMPinData?.phone?.trim(),
            whatsappNumber: '${result.data?.restMPinData?.whatsappNumber?.trim()}');
      }
    } else {
      setState(state.copyWith(isLoad: false));
      ApiResult.catchError(result, context);
    }
  }

  ///
  void checkValidate({required BuildContext context}) {
    setState(state.copyWith(isLoad: true));
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    if (phoneController.text == '') {
      AppSnackBar.successSnackBar(context,
          contentMessage: phoneValidate(phoneController.text));
    } else if (_phoneRegex.hasMatch(phoneController.text)) {
      AppSnackBar.successSnackBar(context,
          contentMessage: localLanguage?.keyInvalidPhoneNumber ??
              LocaleKeys.invalidPhoneNumber.tr());
    } else {
      setState(state.copyWith(isLoad: true));
      callGetOtp(context);
    }
  }

  ///
  void callMethod(BuildContext context) {
    if (otpController.text.length == 4) {
      otpVerificationCall(context: context);
    } else {
      getMPin(context);
    }
  }

  ///
  Future<void> getMPin(BuildContext context) async {
    setState(state.copyWith(isLoad: true));
    ApiResult<OtpResponse> result = await runApiInSafeZone(() =>
        loginRepository.getOtp(
            phoneNumber: phoneController.text,
            countryCode: state.selectCountry));
    try {
      if (result.isSucceeded) {
        setState(state.copyWith(isLoad: false));
        if (result.data?.status == 'error') {
          confirmationDialog(
            context,
            subTitle: result.data?.otp?.errorMessage,
            doneButtonText: 'okay',
            showCancelButton: false,
            onTap: (){
              AutoRouter.of(context).maybePop();
            }
          );
        } else {
          setState(state.copyWith(isLoad: false));
          localStorage.save(StorageKey.userPhoneNumber, phoneController.text);
          setState(state.copyWith(showPinCode: true));
          if (result.data?.otp?.mPin != null &&
              result.data?.otp?.mPin != '' &&
              result.data?.otp?.isFirstTime == true) {
            await mPinAlert(context,
                alertMessage: result.data?.otp?.alertMessage,
                copyButton: () {
                  otpController.text = '${result.data?.otp?.mPin}';
                },
                pin: result.data?.otp?.mPin,
                onTap: () {
                  otpController.text = '${result.data?.otp?.mPin}';
                  AutoRouter.of(context).maybePop();

                  ///
                  // localStorage.save(StorageKey.keykjm, result.data?.otpVerification?.key);
                  // localStorage.save(StorageKey.isLogin, true);
                  // localStorage.save(StorageKey.isFinishedTutorial, false);
                });
          }
        }
      } else {
        setState(state.copyWith(isLoad: false));
        confirmationDialog(
          context,
          subTitle: result.data?.otp?.errorMessage,
          doneButtonText: 'okay',
          onTap: () => AutoRouter.of(context).maybePop(),
        );
      }
    } catch (e) {
      setState(state.copyWith(isLoad: false));
      ApiResult.catchError(result, context);
    }
  }

  ///
  /// otp verification method
  ///
  void otpVerificationCall({required BuildContext context}) async {
    setState(state.copyWith(isLoad: true));
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    if (otpController.text.length != 4) {
      AppSnackBar.successSnackBar(context,
          contentMessage: 'Please enter the valid otp');
    } else {
      ApiResult<OtpVerificationResponse> response = await runApiInSafeZone(() =>
          loginRepository.verifyOtp(otpController.text,
              countryCode: state.selectCountry,
              phoneNumber:
                  localStorage.retrieveString(StorageKey.userPhoneNumber)));
      if (response.isSucceeded) {
        setState(state.copyWith(isLoad: false));
        if (response.data?.otpVerification?.status == 'Success') {
          localStorage.save(
              StorageKey.keykjm, response.data?.otpVerification?.key);
          localStorage.save(StorageKey.isLogin, true);
          localStorage.save(StorageKey.isFinishedTutorial, false);

          navigationToUserProfile(context: context);
        } else {
          confirmationDialog(context,
              title: 'OTP Verification',
              showCancelButton: false,
              image: 'assets/images/top_wrong.png',
              doneButtonText: localLanguage?.keyOk ?? LocaleKeys.ok.tr(),
              onTap: () {
            AutoRouter.of(context).maybePop();
          }, subTitle: response.data?.otpVerification?.message ?? '');

          /// show for error case message
          // ? localLanguage?.nepalOtpVerificationErrorMessage
          // : ' OTP is wrong,Please request for new one');
        }
      } else {
        setState(state.copyWith(isLoad: false));
        otpController.clear();
        ApiResult.catchError(response, context);
      }
      setState(state.copyWith(isLoad: false));
    }
  }

  ///
  void navigationToUserProfile({required BuildContext context}) {
    appNavigation.userProfile(context);
  }

  ///
  void navigateToChooseLanguage({required BuildContext context}) {
    appNavigation.navigationToLanguage(context);
  }

  ///
  void navigateToForgetPassword({required BuildContext context}) {
    appNavigation.navigationToForgetPassword(context);
  }

  ///
  void setPhoneNumberLength({required String value}) {
    setState(state.copyWith(phoneNumberLength: value.length));
    if (otpController.text.length != 10) {
      otpController.text = '';
      setState(state.copyWith(showPinCode: false));
    }
  }

  ///
  void selectCountryCode(String? s) {
    setState(state.copyWith(selectCountry: s));

    localStorage.save(StorageKey.countryCode, s ?? '+91');
    otpController.clear();
    if (s == '+91') {
      setState(state.copyWith(showPinCode: false));
    }
  }
}
