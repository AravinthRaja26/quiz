import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:copy_with_extension/copy_with_extension.dart';

part 'otp_verification_viewstate.g.dart';

///
@CopyWith()
class OtpVerificationViewState extends ViewState {
  ///
  final String phoneNumber;

  ///
  final int otpLength;

  ///
  final bool load;

  ///
  final bool reSendButtonEnable;

  ///
  const OtpVerificationViewState(
      {required this.phoneNumber, required this.otpLength, required this.load,required this.reSendButtonEnable});

  ///
  OtpVerificationViewState.initial()
      : phoneNumber = '',
        otpLength = 0,
        load = false,reSendButtonEnable= false;

  @override
  List<Object?> get props => <Object>[phoneNumber, otpLength, load,reSendButtonEnable];
}
