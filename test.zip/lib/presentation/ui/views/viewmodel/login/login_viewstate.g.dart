// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'login_viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$LoginViewStateCWProxy {
  LoginViewState phoneNumber(String phoneNumber);

  LoginViewState selectCountry(String selectCountry);

  LoginViewState isGetOtp(bool isGetOtp);

  LoginViewState phoneNumberLength(int phoneNumberLength);

  LoginViewState showPinCode(bool showPinCode);

  LoginViewState isLoad(bool isLoad);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `LoginViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// LoginViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  LoginViewState call({
    String? phoneNumber,
    String? selectCountry,
    bool? isGetOtp,
    int? phoneNumberLength,
    bool? showPinCode,
    bool? isLoad,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfLoginViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfLoginViewState.copyWith.fieldName(...)`
class _$LoginViewStateCWProxyImpl implements _$LoginViewStateCWProxy {
  const _$LoginViewStateCWProxyImpl(this._value);

  final LoginViewState _value;

  @override
  LoginViewState phoneNumber(String phoneNumber) =>
      this(phoneNumber: phoneNumber);

  @override
  LoginViewState selectCountry(String selectCountry) =>
      this(selectCountry: selectCountry);

  @override
  LoginViewState isGetOtp(bool isGetOtp) => this(isGetOtp: isGetOtp);

  @override
  LoginViewState phoneNumberLength(int phoneNumberLength) =>
      this(phoneNumberLength: phoneNumberLength);

  @override
  LoginViewState showPinCode(bool showPinCode) =>
      this(showPinCode: showPinCode);

  @override
  LoginViewState isLoad(bool isLoad) => this(isLoad: isLoad);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `LoginViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// LoginViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  LoginViewState call({
    Object? phoneNumber = const $CopyWithPlaceholder(),
    Object? selectCountry = const $CopyWithPlaceholder(),
    Object? isGetOtp = const $CopyWithPlaceholder(),
    Object? phoneNumberLength = const $CopyWithPlaceholder(),
    Object? showPinCode = const $CopyWithPlaceholder(),
    Object? isLoad = const $CopyWithPlaceholder(),
  }) {
    return LoginViewState(
      phoneNumber:
          phoneNumber == const $CopyWithPlaceholder() || phoneNumber == null
              ? _value.phoneNumber
              // ignore: cast_nullable_to_non_nullable
              : phoneNumber as String,
      selectCountry:
          selectCountry == const $CopyWithPlaceholder() || selectCountry == null
              ? _value.selectCountry
              // ignore: cast_nullable_to_non_nullable
              : selectCountry as String,
      isGetOtp: isGetOtp == const $CopyWithPlaceholder() || isGetOtp == null
          ? _value.isGetOtp
          // ignore: cast_nullable_to_non_nullable
          : isGetOtp as bool,
      phoneNumberLength: phoneNumberLength == const $CopyWithPlaceholder() ||
              phoneNumberLength == null
          ? _value.phoneNumberLength
          // ignore: cast_nullable_to_non_nullable
          : phoneNumberLength as int,
      showPinCode:
          showPinCode == const $CopyWithPlaceholder() || showPinCode == null
              ? _value.showPinCode
              // ignore: cast_nullable_to_non_nullable
              : showPinCode as bool,
      isLoad: isLoad == const $CopyWithPlaceholder() || isLoad == null
          ? _value.isLoad
          // ignore: cast_nullable_to_non_nullable
          : isLoad as bool,
    );
  }
}

extension $LoginViewStateCopyWith on LoginViewState {
  /// Returns a callable class that can be used as follows: `instanceOfLoginViewState.copyWith(...)` or like so:`instanceOfLoginViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$LoginViewStateCWProxy get copyWith => _$LoginViewStateCWProxyImpl(this);
}
