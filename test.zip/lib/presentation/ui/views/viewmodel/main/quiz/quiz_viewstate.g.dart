// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'quiz_viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$QuizViewStateCWProxy {
  QuizViewState isLoading(bool? isLoading);

  QuizViewState quizModel(QuizModel? quizModel);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `QuizViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// QuizViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  QuizViewState call({
    bool? isLoading,
    QuizModel? quizModel,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfQuizViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfQuizViewState.copyWith.fieldName(...)`
class _$QuizViewStateCWProxyImpl implements _$QuizViewStateCWProxy {
  const _$QuizViewStateCWProxyImpl(this._value);

  final QuizViewState _value;

  @override
  QuizViewState isLoading(bool? isLoading) => this(isLoading: isLoading);

  @override
  QuizViewState quizModel(QuizModel? quizModel) => this(quizModel: quizModel);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `QuizViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// QuizViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  QuizViewState call({
    Object? isLoading = const $CopyWithPlaceholder(),
    Object? quizModel = const $CopyWithPlaceholder(),
  }) {
    return QuizViewState(
      isLoading: isLoading == const $CopyWithPlaceholder()
          ? _value.isLoading
          // ignore: cast_nullable_to_non_nullable
          : isLoading as bool?,
      quizModel: quizModel == const $CopyWithPlaceholder()
          ? _value.quizModel
          // ignore: cast_nullable_to_non_nullable
          : quizModel as QuizModel?,
    );
  }
}

extension $QuizViewStateCopyWith on QuizViewState {
  /// Returns a callable class that can be used as follows: `instanceOfQuizViewState.copyWith(...)` or like so:`instanceOfQuizViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$QuizViewStateCWProxy get copyWith => _$QuizViewStateCWProxyImpl(this);
}
