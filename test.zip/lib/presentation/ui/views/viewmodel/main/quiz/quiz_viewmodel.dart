
import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';

import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/material.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/quiz/quiz_model.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/quiz/quiz_viewstate.dart';

///
class QuizViewModel extends BaseViewModel<QuizViewState>
    with EventMixin<AppEvent>, WidgetsBindingObserver {
  ///
  QuizViewModel():super(QuizViewState.initial());
  PageController controller =
  PageController(viewportFraction: 1, keepPage: false);
  ///
  ///
///
init(){
  _loadData();
}


  ///
  Future<void> _loadData() async {

    await loadJsonData();
  }

  ///
  Future<void> loadJsonData() async {
    String data = await rootBundle.loadString('assets/quizJson/quizz.json');
    QuizModel quizData = QuizModel.fromJson(jsonDecode(data));
    if (quizData.quiz != null && quizData.quiz?.isNotEmpty == true) {
      setState(state.copyWith(quizModel: quizData));
    } else {
      print('::=>{quizData}');
    }
  }


  void nextQuiz(){
  controller.nextPage(duration: Duration(milliseconds:400 ), curve: Curves.easeInSine);
  }

  void previousQuiz(){
    controller.previousPage(duration: Duration(milliseconds:400 ), curve: Curves.easeInSine);
  }
}