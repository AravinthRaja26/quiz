
import 'package:copy_with_extension/copy_with_extension.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/quiz/quiz_model.dart';
part 'quiz_viewstate.g.dart';
///
@CopyWith()
class QuizViewState extends ViewState {
  ///
  final bool? isLoading;

  final int? currentIndex;

  ///
  final QuizModel? quizModel;

  ///
  QuizViewState(
      {required this.isLoading,required this.quizModel,required this.currentIndex
        });

  ///
  /// Named Constructor for initial state
  ///
  QuizViewState.initial()
      : isLoading = false,quizModel = QuizModel(),currentIndex=0 ;

  ///
  /// Props
  ///
  @override
  List<Object?> get props => <Object?>[
    isLoading,quizModel,currentIndex

  ];
}
