// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'transaction.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$TransactionViewStateCWProxy {
  TransactionViewState name(String? name);

  TransactionViewState consumerTransactionResponse(
      ConsumerTransactionResponse? consumerTransactionResponse);

  TransactionViewState load(bool? load);

  TransactionViewState transactionPage(TransactionEnum? transactionPage);

  TransactionViewState earnedResponse(EarnedResponse? earnedResponse);

  TransactionViewState expiredResponse(ExpiredResponse? expiredResponse);

  TransactionViewState transferResponse(TransferResponse? transferResponse);

  TransactionViewState verifiedResponse(VerifiedResponse? verifiedResponse);

  TransactionViewState transcationPagination(int? transcationPagination);

  TransactionViewState couponDetail(CouponDetail? couponDetail);

  TransactionViewState dataSize(int? dataSize);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `TransactionViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// TransactionViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  TransactionViewState call({
    String? name,
    ConsumerTransactionResponse? consumerTransactionResponse,
    bool? load,
    TransactionEnum? transactionPage,
    EarnedResponse? earnedResponse,
    ExpiredResponse? expiredResponse,
    TransferResponse? transferResponse,
    VerifiedResponse? verifiedResponse,
    int? transcationPagination,
    CouponDetail? couponDetail,
    int? dataSize,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfTransactionViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfTransactionViewState.copyWith.fieldName(...)`
class _$TransactionViewStateCWProxyImpl
    implements _$TransactionViewStateCWProxy {
  const _$TransactionViewStateCWProxyImpl(this._value);

  final TransactionViewState _value;

  @override
  TransactionViewState name(String? name) => this(name: name);

  @override
  TransactionViewState consumerTransactionResponse(
          ConsumerTransactionResponse? consumerTransactionResponse) =>
      this(consumerTransactionResponse: consumerTransactionResponse);

  @override
  TransactionViewState load(bool? load) => this(load: load);

  @override
  TransactionViewState transactionPage(TransactionEnum? transactionPage) =>
      this(transactionPage: transactionPage);

  @override
  TransactionViewState earnedResponse(EarnedResponse? earnedResponse) =>
      this(earnedResponse: earnedResponse);

  @override
  TransactionViewState expiredResponse(ExpiredResponse? expiredResponse) =>
      this(expiredResponse: expiredResponse);

  @override
  TransactionViewState transferResponse(TransferResponse? transferResponse) =>
      this(transferResponse: transferResponse);

  @override
  TransactionViewState verifiedResponse(VerifiedResponse? verifiedResponse) =>
      this(verifiedResponse: verifiedResponse);

  @override
  TransactionViewState transcationPagination(int? transcationPagination) =>
      this(transcationPagination: transcationPagination);

  @override
  TransactionViewState couponDetail(CouponDetail? couponDetail) =>
      this(couponDetail: couponDetail);

  @override
  TransactionViewState dataSize(int? dataSize) => this(dataSize: dataSize);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `TransactionViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// TransactionViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  TransactionViewState call({
    Object? name = const $CopyWithPlaceholder(),
    Object? consumerTransactionResponse = const $CopyWithPlaceholder(),
    Object? load = const $CopyWithPlaceholder(),
    Object? transactionPage = const $CopyWithPlaceholder(),
    Object? earnedResponse = const $CopyWithPlaceholder(),
    Object? expiredResponse = const $CopyWithPlaceholder(),
    Object? transferResponse = const $CopyWithPlaceholder(),
    Object? verifiedResponse = const $CopyWithPlaceholder(),
    Object? transcationPagination = const $CopyWithPlaceholder(),
    Object? couponDetail = const $CopyWithPlaceholder(),
    Object? dataSize = const $CopyWithPlaceholder(),
  }) {
    return TransactionViewState(
      name: name == const $CopyWithPlaceholder()
          ? _value.name
          // ignore: cast_nullable_to_non_nullable
          : name as String?,
      consumerTransactionResponse:
          consumerTransactionResponse == const $CopyWithPlaceholder()
              ? _value.consumerTransactionResponse
              // ignore: cast_nullable_to_non_nullable
              : consumerTransactionResponse as ConsumerTransactionResponse?,
      load: load == const $CopyWithPlaceholder()
          ? _value.load
          // ignore: cast_nullable_to_non_nullable
          : load as bool?,
      transactionPage: transactionPage == const $CopyWithPlaceholder()
          ? _value.transactionPage
          // ignore: cast_nullable_to_non_nullable
          : transactionPage as TransactionEnum?,
      earnedResponse: earnedResponse == const $CopyWithPlaceholder()
          ? _value.earnedResponse
          // ignore: cast_nullable_to_non_nullable
          : earnedResponse as EarnedResponse?,
      expiredResponse: expiredResponse == const $CopyWithPlaceholder()
          ? _value.expiredResponse
          // ignore: cast_nullable_to_non_nullable
          : expiredResponse as ExpiredResponse?,
      transferResponse: transferResponse == const $CopyWithPlaceholder()
          ? _value.transferResponse
          // ignore: cast_nullable_to_non_nullable
          : transferResponse as TransferResponse?,
      verifiedResponse: verifiedResponse == const $CopyWithPlaceholder()
          ? _value.verifiedResponse
          // ignore: cast_nullable_to_non_nullable
          : verifiedResponse as VerifiedResponse?,
      transcationPagination:
          transcationPagination == const $CopyWithPlaceholder()
              ? _value.transcationPagination
              // ignore: cast_nullable_to_non_nullable
              : transcationPagination as int?,
      couponDetail: couponDetail == const $CopyWithPlaceholder()
          ? _value.couponDetail
          // ignore: cast_nullable_to_non_nullable
          : couponDetail as CouponDetail?,
      dataSize: dataSize == const $CopyWithPlaceholder()
          ? _value.dataSize
          // ignore: cast_nullable_to_non_nullable
          : dataSize as int?,
    );
  }
}

extension $TransactionViewStateCopyWith on TransactionViewState {
  /// Returns a callable class that can be used as follows: `instanceOfTransactionViewState.copyWith(...)` or like so:`instanceOfTransactionViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$TransactionViewStateCWProxy get copyWith =>
      _$TransactionViewStateCWProxyImpl(this);
}
