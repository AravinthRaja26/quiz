import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/enum/transaction_enum.dart';
import 'package:nikitchem/data/models/consumer/consumer_transaction.model.dart';
import 'package:nikitchem/data/models/transcation/coupon/coupon_detail.model.dart';
import 'package:nikitchem/data/models/transcation/earned/earned_model.dart';
import 'package:nikitchem/data/models/transcation/expired/expired_model.dart';
import 'package:nikitchem/data/models/transcation/transfer/transfer_model.dart';
import 'package:nikitchem/data/models/transcation/verified/verified_model.dart';
import 'package:copy_with_extension/copy_with_extension.dart';

part 'transaction.viewstate.g.dart';

///
@CopyWith()
class TransactionViewState extends ViewState {
  ///
  ConsumerTransactionResponse? consumerTransactionResponse;

  ///
  final String? name;

  ///
  int? transcationPagination;

  ///
  int? dataSize;

  ///
  TransactionEnum? transactionPage;

  ///
  EarnedResponse? earnedResponse;

  ///
  TransferResponse? transferResponse;

  ///
  VerifiedResponse? verifiedResponse;

  ///
  ExpiredResponse? expiredResponse;

  ///
  CouponDetail? couponDetail;

  ///
  final bool? load;

  ///
  TransactionViewState({
    this.name,
    this.consumerTransactionResponse,
    this.load,
    this.transactionPage,
    this.earnedResponse,
    this.expiredResponse,
    this.transferResponse,
    this.verifiedResponse,
    this.transcationPagination,
    this.couponDetail,
    this.dataSize,
  });

  ///
  TransactionViewState.initial()
      : name = 'Offline',
        consumerTransactionResponse = ConsumerTransactionResponse(),
        earnedResponse = EarnedResponse(),
        expiredResponse = ExpiredResponse(),
        transferResponse = TransferResponse(),
        verifiedResponse = VerifiedResponse(),
        couponDetail = CouponDetail(),
        transactionPage = TransactionEnum.earned,
        transcationPagination = 0,
        dataSize = 10,
        load = false;

  @override
  List<Object?> get props => <Object?>[
        name,
        transcationPagination,
        consumerTransactionResponse,
        couponDetail,
        load,
        transactionPage,
        earnedResponse,
        expiredResponse,
        transferResponse,
        verifiedResponse,
        dataSize
      ];
}
