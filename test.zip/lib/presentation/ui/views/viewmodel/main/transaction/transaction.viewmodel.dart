import 'dart:async';
import 'dart:math';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/dashboard_event.dart';
import 'package:nikitchem/application/events/enquiry_event.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/events/transaction_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/enum/transaction_enum.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/consumer/consumer_transaction.model.dart';
import 'package:nikitchem/data/models/transcation/coupon/coupon_detail.model.dart';
import 'package:nikitchem/data/models/transcation/earned/earned_model.dart';
import 'package:nikitchem/data/models/transcation/expired/expired_model.dart';
import 'package:nikitchem/data/models/transcation/transfer/transfer_model.dart';
import 'package:nikitchem/data/models/transcation/verified/verified_model.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/transaction/transaction.repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_bottom_sheet.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/transaction/transaction.viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';

///
class TransactionViwModel extends BaseViewModel<TransactionViewState>
    with EventMixin<AppEvent> {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  int? transcationPagination = 0;
  int? dataSize = 5;

  ///
  AppNavigation appNavigation;

  ///
  final LocalStorage localStorage;

  ///
  GlobalKey<ScaffoldState> key = GlobalKey<ScaffoldState>();

  ///
  final ScrollController transactionScrollController = ScrollController();

  ///
  final PageController controller = PageController();

  ///
  TransactionRepository transactionRepository;


  ///
  TransactionViwModel(
      this.appNavigation, this.transactionRepository, this.localStorage)
      : super(TransactionViewState.initial()) {
    
  }

  ///
  void init(BuildContext context) {

    streamSubscription = listenEvents((AppEvent event) {
      Random random = Random();
      if (event is DashboardEvent) {
        setState(
            state.copyWith(name: event.sample + random.nextInt(20).toString()));
      } else if (event is TransactionEvent) {

        getTransactionDetails(context);
        setState(state.copyWith(transactionPage: TransactionEnum.earned));

      } else if (event is LanguageEvent) {
        notifyListeners();
      }
    });
    
    transactionScrollController.addListener(() {
      if (transactionScrollController.position.pixels ==
          transactionScrollController.position.maxScrollExtent) {
        print(transactionScrollController.position.maxScrollExtent);
        print(transactionScrollController.position.pixels);
        int? isScroll = state.transcationPagination ?? 0;
        int? dataSizeTemp = state.dataSize ?? 0;
        setState(state.copyWith(
            transcationPagination: isScroll++, dataSize: dataSizeTemp + 10));
        loadData(context);
      } else {
        // notifyListeners();
      }
    });
    getTransactionDetails(context);
    getEarnedDataDetail(context);
    getTransferDataDetail(context);
    getExpiredDataDetail(context);
    getVerifiedDataDetail(context);
  }

  ///
  void navigationToNotificationScreen(BuildContext context) async {
    fireEvent(const EnquiryEvent());
    await appNavigation.navigationToNotificationScreen(context);
    fireEvent(const EnquiryEvent());
  }

  ///
  String title() {
    fireEvent(const EnquiryEvent());
    switch (state.transactionPage) {
      case TransactionEnum.earned:
        return localLanguage?.keyEarnedQrCodes ?? LocaleKeys.earnedQrCodes.tr();
      case TransactionEnum.redeemed:
        return localLanguage?.keyRedeemedQrCodes ??
            LocaleKeys.redeemedQrCodes.tr();
      case TransactionEnum.expired:
        return localLanguage?.keyExpiredQrCodes ??
            LocaleKeys.expiredQrCodes.tr();
        case TransactionEnum.transfer:
        return localLanguage?.keyTransferQrCodes ??
            'Transferred QR Codes';
      case TransactionEnum.verified:
        return localLanguage?.keyVerifiedQrCodes ??
            LocaleKeys.verifiedQrCodes.tr();
      default:
        return localLanguage?.keyEarnedQrCodes ?? LocaleKeys.earnedQrCodes.tr();
    }
  }

/*  ///
  String dateConverter(String? date) {
    // Input date Format
    final DateFormat format = DateFormat('dd-MM-yyyy');
    DateTime gettingDate = format.parse(date!);
    final DateFormat formatter = DateFormat('yyyy-MM-dd');
    // Output Date Format
    final String formatted = formatter.format(gettingDate);
    return date;
  }*/

  ///
  void navigationToEarnedDetailScreen(
      BuildContext context, Earned? consumerEarnedDetails) async {
    fireEvent(const EnquiryEvent());
    await appNavigation.navigationToEarnedDetailScreen(
        context, consumerEarnedDetails);
    fireEvent(const EnquiryEvent());
  }

  ///
  void navigationToExpiredDetailScreen(
    BuildContext context,
    Expired? consumerExpiredDetails,
  ) async {
    fireEvent(const EnquiryEvent());
    await appNavigation.navigationToExpiredDetailScreen(
        context, consumerExpiredDetails);
    fireEvent(const EnquiryEvent());
  }

  ///
  ///
  navigateToHomeScreen(BuildContext context) async {
    await AutoRouter.of(context)
        .pushAndPopUntil(MainScreen(), predicate: (_) => false);
  }

  ///
  void getTransactionDetails(BuildContext context) async {
    setState(state.copyWith(load: true));
    ApiResult<ConsumerTransactionResponse> result = await runApiInSafeZone(
        () => transactionRepository.getTransactionDetail());
    if (result.isSucceeded) {
      setState(state.copyWith(load: false));
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              doneButtonText: localLanguage?.keyOk ?? 'ok',
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: false,
              subTitle: localLanguage?.keyYouAreLoggedInAnotherDevice ??
                  LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          },
              title: localLanguage?.keyYouAreLoggedOut ??
                  LocaleKeys.youAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      } else {
        setState(state.copyWith(
            load: false, consumerTransactionResponse: result.data));
      }
    } else {
      setState(state.copyWith(load: false));
      ApiResult.catchError(result, context);
    }
  }

  ///
  void currentTransaction(TransactionEnum transactionData, BuildContext context) {
    setState(state.copyWith(
        transactionPage: transactionData,
        dataSize: 10,
        transcationPagination: 0));

      loadData(context);

  }

  ///
  void loadData(BuildContext context) {

      switch (state.transactionPage) {
        case TransactionEnum.earned:
          if (state.earnedResponse!.data?.list?.length != state.earnedResponse!.data!.count!.toInt()) {
            getEarnedDataDetail(context);
          }
        case TransactionEnum.redeemed:
          if (state.transferResponse!.data?.list?.length != state.transferResponse!.data!.count!.toInt()) {
            getTransferDataDetail(context);
          }
        case TransactionEnum.expired:
          if (state.expiredResponse!.data?.list?.length != state.expiredResponse!.data!.count!.toInt()) {
          getExpiredDataDetail(context);}
        case TransactionEnum.verified:
          if (state.verifiedResponse!.data?.list?.length != state.verifiedResponse!.data!.count!.toInt()) {
            getVerifiedDataDetail(context);
          }
        default:
          if (state.transferResponse!.data?.list?.length != state.transferResponse!.data!.count!.toInt()) {
            getTransferDataDetail(context);
          }

      // getEarnedDataDetail(context!);
    }
  }

  ///
  /// Earned Detail
  ///
  void getEarnedDataDetail(
    BuildContext context,
  ) async {
    setState(state.copyWith(load: true));
    Map<String, dynamic> data = <String, dynamic>{
      'page': state.transcationPagination,
      'size': state.dataSize,
      'keykjm': localStorage.retrieveString(StorageKey.keykjm),
    };
    ApiResult<EarnedResponse?> result =
        await runApiInSafeZone(() => transactionRepository.earnedDetail(data));
    if (result.isSucceeded) {
      setState(state.copyWith(
        earnedResponse: result.data,
        load: false,
      ));
    }
  }

  ///
  /// Transfer Detail
  ///
  void getTransferDataDetail(
    BuildContext context,
  ) async {
    setState(state.copyWith(load: true));

    Map<String, dynamic> data = <String, dynamic>{
      'page': state.transcationPagination,
      'size': state.dataSize,
      'keykjm': localStorage.retrieveString(StorageKey.keykjm),
    };
    ApiResult<TransferResponse?> result = await runApiInSafeZone(
        () => transactionRepository.transferDetail(data));
    if (result.isSucceeded) {
      setState(state.copyWith(
        transferResponse: result.data,
        load: false,
      ));
    }
  }

  ///
  /// Expired Detail
  ///
  void getExpiredDataDetail(
    BuildContext context,
  ) async {
    setState(state.copyWith(load: true));
    Map<String, dynamic> data = <String, dynamic>{
      'page': state.transcationPagination,
      'size': state.dataSize,
      'keykjm': localStorage.retrieveString(StorageKey.keykjm),
    };
    ApiResult<ExpiredResponse?> result =
        await runApiInSafeZone(() => transactionRepository.expiredDetail(data));
    if (result.isSucceeded) {
      setState(state.copyWith(
        expiredResponse: result.data,
        load: false,
      ));
    }
  }

  ///
  /// Verified Detail
  ///
  void getVerifiedDataDetail(
    BuildContext context,
  ) async {
    setState(state.copyWith(load: true));
    Map<String, dynamic> data = <String, dynamic>{
      'page': state.transcationPagination,
      'size': state.dataSize,
      'keykjm': localStorage.retrieveString(StorageKey.keykjm),
    };
    ApiResult<VerifiedResponse?> result = await runApiInSafeZone(
        () => transactionRepository.verifiedDetail(data));
    if (result.isSucceeded) {
      setState(state.copyWith(
        verifiedResponse: result.data,
        load: false,
      ));
    }
  }

  ///
  /// Coupon Detail
  ///
  void getCouponDetail(BuildContext context, String couponData) async {
    //setState(state.copyWith(load: true));
    Map<String, dynamic> data = <String, dynamic>{
      'keykjm': localStorage.retrieveString(StorageKey.keykjm),
      'couponCode': couponData
    };
    ApiResult<CouponDetail?> result =
        await runApiInSafeZone(() => transactionRepository.couponDetail(data));
    if (result.isSucceeded) {
      setState(state.copyWith(
        couponDetail: result.data,
        load: false,
      ));
      transcationBottomSheet(
        context: context,
        couponCode: state.couponDetail?.data?.QRcode ?? couponData,
        amount: state.couponDetail?.data?.amountEarned?.toDouble(),
        expireDate: state.couponDetail?.data?.expiryDate,
        scanDate: state.couponDetail?.data?.scanDate,
        addtionalPoint: state.couponDetail?.data?.additionalPoints?.toDouble(),
        basePoint: state.couponDetail?.data?.basepoints?.toDouble(),
      );
    }
  }
}
