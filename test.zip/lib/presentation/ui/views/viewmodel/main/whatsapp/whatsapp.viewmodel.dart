import 'dart:async';
import 'dart:io';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/config/application.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/events/previous_page_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/utils/app.text.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/whatsapp/whatsapp.viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:url_launcher/url_launcher.dart';

///
class WhatsAppViewModel extends BaseViewModel<WhatsAppViewState>
    with EventMixin<AppEvent> {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  LocalStorage localStorage;

  ///
  WhatsAppViewModel(this.localStorage) : super(WhatsAppViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  void confirmDialog(BuildContext context) {
    confirmationDialog(
      context,
      doneButtonText: LocaleKeys.open.tr(),
      subTitle:
          'You are taken to an external app to proceed with the chat. Do you want to continue?',
      onTap: () {
        AutoRouter.of(context).maybePop();
        openWhatsapp(context);
      },
      title: 'App Permission',
      image: 'assets/images/longin_success.png',
    );
  }

  ///
  navigateToHomeScreen(BuildContext context) async {
    await AutoRouter.of(context)
        .pushAndPopUntil(MainScreen(), predicate: (_) => false);
  }

  ///
  void previousPage({required BuildContext context}) {
    fireEvent(const PreviousPageEvent());
    final TabsRouter router =
        context.router.root.innerRouterOf(MainScreen.name) as TabsRouter;
    router.setActiveIndex(
        localStorage.retrieveInt(StorageKey.currentPageIndex) ?? 0,
        notify: true);
  }

  ///
  void openWhatsapp(BuildContext context) async {
    String whatsapp =
        '${localStorage.retrieveString(StorageKey.countryCode)}${appConfig?.flavor == 'dev' ? localStorage.retrieveString(StorageKey.countryCode) == '+977' ? AppText.whatsAppNumberNepal : AppText.devWhatsAppNumber : localStorage.retrieveString(StorageKey.countryCode) == '+977' ? AppText.whatsAppNumberNepal : AppText.whatsAppNumber}';
    String whatsappURlAndroid =
        'whatsapp://send?phone=$whatsapp&text=${AppText.whatsappContent}';
    String whatsappURLIos =
        'https://wa.me/$whatsapp?text=${Uri.parse(AppText.whatsappContent)}';
    if (Platform.isIOS) {
      if (await canLaunchUrl(Uri.parse(whatsappURLIos))) {
        await launchUrl(Uri.parse(whatsappURLIos));
      } else {
        AppSnackBar.warningSnackBar(context,
            contentMessage: 'Whatsapp is not installed');
      }
    } else {
      if (await canLaunchUrl(Uri.parse(whatsappURlAndroid))) {
        await launchUrl(Uri.parse(whatsappURlAndroid));
      } else {
        AppSnackBar.warningSnackBar(context,
            contentMessage: 'Whatsapp is not installed');
      }
    }
  }
}
