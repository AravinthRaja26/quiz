// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'whatsapp.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$WhatsAppViewStateCWProxy {
  WhatsAppViewState name(String name);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `WhatsAppViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// WhatsAppViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  WhatsAppViewState call({
    String? name,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfWhatsAppViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfWhatsAppViewState.copyWith.fieldName(...)`
class _$WhatsAppViewStateCWProxyImpl implements _$WhatsAppViewStateCWProxy {
  const _$WhatsAppViewStateCWProxyImpl(this._value);

  final WhatsAppViewState _value;

  @override
  WhatsAppViewState name(String name) => this(name: name);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `WhatsAppViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// WhatsAppViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  WhatsAppViewState call({
    Object? name = const $CopyWithPlaceholder(),
  }) {
    return WhatsAppViewState(
      name: name == const $CopyWithPlaceholder() || name == null
          ? _value.name
          // ignore: cast_nullable_to_non_nullable
          : name as String,
    );
  }
}

extension $WhatsAppViewStateCopyWith on WhatsAppViewState {
  /// Returns a callable class that can be used as follows: `instanceOfWhatsAppViewState.copyWith(...)` or like so:`instanceOfWhatsAppViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$WhatsAppViewStateCWProxy get copyWith =>
      _$WhatsAppViewStateCWProxyImpl(this);
}
