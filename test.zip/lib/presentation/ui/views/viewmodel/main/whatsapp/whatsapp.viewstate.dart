import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'whatsapp.viewstate.g.dart';

///
@CopyWith()
class WhatsAppViewState extends ViewState {
  ///
  final String name;

  ///
  const WhatsAppViewState({required this.name});

  ///
  WhatsAppViewState.initial() : name = 'Offline';

  @override
  List<Object?> get props => <Object>[name];
}
