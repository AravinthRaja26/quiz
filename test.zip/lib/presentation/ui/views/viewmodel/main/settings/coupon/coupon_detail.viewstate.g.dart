// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'coupon_detail.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$CouponDetailViewStateCWProxy {
  CouponDetailViewState isEnabled(bool? isEnabled);

  CouponDetailViewState isShimmer(bool? isShimmer);

  CouponDetailViewState name(String? name);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `CouponDetailViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// CouponDetailViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  CouponDetailViewState call({
    bool? isEnabled,
    bool? isShimmer,
    String? name,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfCouponDetailViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfCouponDetailViewState.copyWith.fieldName(...)`
class _$CouponDetailViewStateCWProxyImpl
    implements _$CouponDetailViewStateCWProxy {
  const _$CouponDetailViewStateCWProxyImpl(this._value);

  final CouponDetailViewState _value;

  @override
  CouponDetailViewState isEnabled(bool? isEnabled) =>
      this(isEnabled: isEnabled);

  @override
  CouponDetailViewState isShimmer(bool? isShimmer) =>
      this(isShimmer: isShimmer);

  @override
  CouponDetailViewState name(String? name) => this(name: name);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `CouponDetailViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// CouponDetailViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  CouponDetailViewState call({
    Object? isEnabled = const $CopyWithPlaceholder(),
    Object? isShimmer = const $CopyWithPlaceholder(),
    Object? name = const $CopyWithPlaceholder(),
  }) {
    return CouponDetailViewState(
      isEnabled == const $CopyWithPlaceholder()
          ? _value.isEnabled
          // ignore: cast_nullable_to_non_nullable
          : isEnabled as bool?,
      isShimmer == const $CopyWithPlaceholder()
          ? _value.isShimmer
          // ignore: cast_nullable_to_non_nullable
          : isShimmer as bool?,
      name == const $CopyWithPlaceholder()
          ? _value.name
          // ignore: cast_nullable_to_non_nullable
          : name as String?,
    );
  }
}

extension $CouponDetailViewStateCopyWith on CouponDetailViewState {
  /// Returns a callable class that can be used as follows: `instanceOfCouponDetailViewState.copyWith(...)` or like so:`instanceOfCouponDetailViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$CouponDetailViewStateCWProxy get copyWith =>
      _$CouponDetailViewStateCWProxyImpl(this);
}
