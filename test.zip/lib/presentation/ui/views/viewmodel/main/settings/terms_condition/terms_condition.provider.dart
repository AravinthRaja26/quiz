import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/terms_condition/terms_condition.viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


///
class TermsConditionProvider extends StatelessWidget {
  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;

  ///
  final dynamic vsync;

  ///
  const TermsConditionProvider(
      {super.key, required this.builder, this.child, this.vsync});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<TermsConditionViewModel>(
        builder: builder,
        lazy: false,
        create: (BuildContext context) {
          return TermsConditionViewModel()..init();
        });
  }
}
