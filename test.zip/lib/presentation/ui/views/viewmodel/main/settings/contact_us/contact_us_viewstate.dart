import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/contact_us/contact_us_response.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'contact_us_viewstate.g.dart';

///
@CopyWith()
class ContactUsViewState extends ViewState {
  ///
  final  bool isEnabled;
  ///
  final  bool isShimmer;
  ///
  final  ContactUsResponse contactUsResponse;

  ///
  const ContactUsViewState(
      {required this.isEnabled,required this.isShimmer,required this.contactUsResponse});

  ///
  ContactUsViewState.initial()
      : isEnabled = false,isShimmer = false,contactUsResponse = const ContactUsResponse();

  @override
  List<Object?> get props => <Object>[isEnabled,isShimmer,contactUsResponse];
}
