import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/scan/scan_coupon_response.model.dart';
import 'package:copy_with_extension/copy_with_extension.dart';

part 'coupon.viewstate.g.dart';

///
@CopyWith()
class CouponViewState extends ViewState {
  ///
  final String? name;

  ///
  final bool? isEnabled;
  ///
  final bool? isLoad;

  ///
  final bool? isShimmer;
  ///
  final ScanCouponResponse? scanCouponResponse;

  ///
  const CouponViewState(
      this.isEnabled, this.isShimmer, this.name, this.scanCouponResponse,this.isLoad);

  ///
  CouponViewState.initial()
      : name = 'Offline',
        isShimmer = false,
        isEnabled = false,
        isLoad = false,
        scanCouponResponse = null;

  @override
  List<Object?> get props =>
      <Object?>[name, isEnabled, isShimmer, scanCouponResponse,isLoad];
}
