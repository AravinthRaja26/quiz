// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'setting.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$SettingViewStateCWProxy {
  SettingViewState listData(List<SettingModel> listData);

  SettingViewState settingsType(SettingsType settingsType);

  SettingViewState name(String name);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `SettingViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// SettingViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  SettingViewState call({
    List<SettingModel>? listData,
    SettingsType? settingsType,
    String? name,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfSettingViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfSettingViewState.copyWith.fieldName(...)`
class _$SettingViewStateCWProxyImpl implements _$SettingViewStateCWProxy {
  const _$SettingViewStateCWProxyImpl(this._value);

  final SettingViewState _value;

  @override
  SettingViewState listData(List<SettingModel> listData) =>
      this(listData: listData);

  @override
  SettingViewState settingsType(SettingsType settingsType) =>
      this(settingsType: settingsType);

  @override
  SettingViewState name(String name) => this(name: name);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `SettingViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// SettingViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  SettingViewState call({
    Object? listData = const $CopyWithPlaceholder(),
    Object? settingsType = const $CopyWithPlaceholder(),
    Object? name = const $CopyWithPlaceholder(),
  }) {
    return SettingViewState(
      listData == const $CopyWithPlaceholder() || listData == null
          ? _value.listData
          // ignore: cast_nullable_to_non_nullable
          : listData as List<SettingModel>,
      settingsType == const $CopyWithPlaceholder() || settingsType == null
          ? _value.settingsType
          // ignore: cast_nullable_to_non_nullable
          : settingsType as SettingsType,
      name: name == const $CopyWithPlaceholder() || name == null
          ? _value.name
          // ignore: cast_nullable_to_non_nullable
          : name as String,
    );
  }
}

extension $SettingViewStateCopyWith on SettingViewState {
  /// Returns a callable class that can be used as follows: `instanceOfSettingViewState.copyWith(...)` or like so:`instanceOfSettingViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$SettingViewStateCWProxy get copyWith => _$SettingViewStateCWProxyImpl(this);
}
