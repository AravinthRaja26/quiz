

import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/contact_us/contact_us_response.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'about_view_state.g.dart';
///
@CopyWith()
class AboutUsViewState extends ViewState {
  ///
  final  bool isEnabled;
  ///
  final  bool isShimmer;
  ///
  final  int currentIndex;
  ///
  final  ContactUsResponse contactUsResponse;

  ///
  const AboutUsViewState(
      {required this.isEnabled,required this.isShimmer,required this.currentIndex,required this.contactUsResponse});

  ///
  AboutUsViewState.initial()
      : isEnabled = false,isShimmer = false,currentIndex = 0,contactUsResponse = const ContactUsResponse();

  @override
  List<Object?> get props => <Object>[isEnabled,isShimmer,currentIndex,contactUsResponse];
}