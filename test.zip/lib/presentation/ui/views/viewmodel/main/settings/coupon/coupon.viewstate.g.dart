// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'coupon.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$CouponViewStateCWProxy {
  CouponViewState isEnabled(bool? isEnabled);

  CouponViewState isShimmer(bool? isShimmer);

  CouponViewState name(String? name);

  CouponViewState scanCouponResponse(ScanCouponResponse? scanCouponResponse);

  CouponViewState isLoad(bool? isLoad);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `CouponViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// CouponViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  CouponViewState call({
    bool? isEnabled,
    bool? isShimmer,
    String? name,
    ScanCouponResponse? scanCouponResponse,
    bool? isLoad,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfCouponViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfCouponViewState.copyWith.fieldName(...)`
class _$CouponViewStateCWProxyImpl implements _$CouponViewStateCWProxy {
  const _$CouponViewStateCWProxyImpl(this._value);

  final CouponViewState _value;

  @override
  CouponViewState isEnabled(bool? isEnabled) => this(isEnabled: isEnabled);

  @override
  CouponViewState isShimmer(bool? isShimmer) => this(isShimmer: isShimmer);

  @override
  CouponViewState name(String? name) => this(name: name);

  @override
  CouponViewState scanCouponResponse(ScanCouponResponse? scanCouponResponse) =>
      this(scanCouponResponse: scanCouponResponse);

  @override
  CouponViewState isLoad(bool? isLoad) => this(isLoad: isLoad);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `CouponViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// CouponViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  CouponViewState call({
    Object? isEnabled = const $CopyWithPlaceholder(),
    Object? isShimmer = const $CopyWithPlaceholder(),
    Object? name = const $CopyWithPlaceholder(),
    Object? scanCouponResponse = const $CopyWithPlaceholder(),
    Object? isLoad = const $CopyWithPlaceholder(),
  }) {
    return CouponViewState(
      isEnabled == const $CopyWithPlaceholder()
          ? _value.isEnabled
          // ignore: cast_nullable_to_non_nullable
          : isEnabled as bool?,
      isShimmer == const $CopyWithPlaceholder()
          ? _value.isShimmer
          // ignore: cast_nullable_to_non_nullable
          : isShimmer as bool?,
      name == const $CopyWithPlaceholder()
          ? _value.name
          // ignore: cast_nullable_to_non_nullable
          : name as String?,
      scanCouponResponse == const $CopyWithPlaceholder()
          ? _value.scanCouponResponse
          // ignore: cast_nullable_to_non_nullable
          : scanCouponResponse as ScanCouponResponse?,
      isLoad == const $CopyWithPlaceholder()
          ? _value.isLoad
          // ignore: cast_nullable_to_non_nullable
          : isLoad as bool?,
    );
  }
}

extension $CouponViewStateCopyWith on CouponViewState {
  /// Returns a callable class that can be used as follows: `instanceOfCouponViewState.copyWith(...)` or like so:`instanceOfCouponViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$CouponViewStateCWProxy get copyWith => _$CouponViewStateCWProxyImpl(this);
}
