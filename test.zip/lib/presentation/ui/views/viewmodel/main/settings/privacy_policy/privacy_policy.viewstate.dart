import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'privacy_policy.viewstate.g.dart';

///
@CopyWith()
class PrivacyPolicyViewState extends ViewState {
  ///
  final bool isEnabled;

  ///
  final bool isShimmer;

  ///
  final int currentIndex;

  ///
  const PrivacyPolicyViewState({
    required this.isEnabled,
    required this.isShimmer,
    required this.currentIndex,
  });

  ///
  PrivacyPolicyViewState.initial()
      : isEnabled = false,
        isShimmer = false,
        currentIndex = 0;

  @override
  List<Object?> get props => <Object>[
        isEnabled,
        isShimmer,
        currentIndex,
      ];
}
