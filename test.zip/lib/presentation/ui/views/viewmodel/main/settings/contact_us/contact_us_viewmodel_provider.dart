import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/repository/contact_us/contact_us_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/contact_us/contact_us_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class ContactUsProvider extends StatelessWidget {
  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;

  ///
  const ContactUsProvider({super.key, required this.builder, this.child});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<ContactUsViewModel>(
        builder: builder,
        lazy: false,
        create: (BuildContext context) {
          return ContactUsViewModel(
              injector<ContactUsRepository>(), injector<LocalStorage>())
            ..init();
        });
  }
}
