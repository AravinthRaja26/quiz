// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'support.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$SupportViewStateCWProxy {
  SupportViewState consumerDetails(ConsumerDetails? consumerDetails);

  SupportViewState viewMoreConsumerDetails(
      ConsumerDetails? viewMoreConsumerDetails);

  SupportViewState isLoad(bool? isLoad);

  SupportViewState isEnabled(bool? isEnabled);

  SupportViewState isShimmer(bool? isShimmer);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `SupportViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// SupportViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  SupportViewState call({
    ConsumerDetails? consumerDetails,
    ConsumerDetails? viewMoreConsumerDetails,
    bool? isLoad,
    bool? isEnabled,
    bool? isShimmer,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfSupportViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfSupportViewState.copyWith.fieldName(...)`
class _$SupportViewStateCWProxyImpl implements _$SupportViewStateCWProxy {
  const _$SupportViewStateCWProxyImpl(this._value);

  final SupportViewState _value;

  @override
  SupportViewState consumerDetails(ConsumerDetails? consumerDetails) =>
      this(consumerDetails: consumerDetails);

  @override
  SupportViewState viewMoreConsumerDetails(
          ConsumerDetails? viewMoreConsumerDetails) =>
      this(viewMoreConsumerDetails: viewMoreConsumerDetails);

  @override
  SupportViewState isLoad(bool? isLoad) => this(isLoad: isLoad);

  @override
  SupportViewState isEnabled(bool? isEnabled) => this(isEnabled: isEnabled);

  @override
  SupportViewState isShimmer(bool? isShimmer) => this(isShimmer: isShimmer);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `SupportViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// SupportViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  SupportViewState call({
    Object? consumerDetails = const $CopyWithPlaceholder(),
    Object? viewMoreConsumerDetails = const $CopyWithPlaceholder(),
    Object? isLoad = const $CopyWithPlaceholder(),
    Object? isEnabled = const $CopyWithPlaceholder(),
    Object? isShimmer = const $CopyWithPlaceholder(),
  }) {
    return SupportViewState(
      consumerDetails: consumerDetails == const $CopyWithPlaceholder()
          ? _value.consumerDetails
          // ignore: cast_nullable_to_non_nullable
          : consumerDetails as ConsumerDetails?,
      viewMoreConsumerDetails:
          viewMoreConsumerDetails == const $CopyWithPlaceholder()
              ? _value.viewMoreConsumerDetails
              // ignore: cast_nullable_to_non_nullable
              : viewMoreConsumerDetails as ConsumerDetails?,
      isLoad: isLoad == const $CopyWithPlaceholder()
          ? _value.isLoad
          // ignore: cast_nullable_to_non_nullable
          : isLoad as bool?,
      isEnabled: isEnabled == const $CopyWithPlaceholder()
          ? _value.isEnabled
          // ignore: cast_nullable_to_non_nullable
          : isEnabled as bool?,
      isShimmer: isShimmer == const $CopyWithPlaceholder()
          ? _value.isShimmer
          // ignore: cast_nullable_to_non_nullable
          : isShimmer as bool?,
    );
  }
}

extension $SupportViewStateCopyWith on SupportViewState {
  /// Returns a callable class that can be used as follows: `instanceOfSupportViewState.copyWith(...)` or like so:`instanceOfSupportViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$SupportViewStateCWProxy get copyWith => _$SupportViewStateCWProxyImpl(this);
}
