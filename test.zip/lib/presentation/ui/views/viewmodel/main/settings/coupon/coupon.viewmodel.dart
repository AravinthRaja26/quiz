import 'dart:async';
import 'dart:io';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/events/scan_coupon_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/scan/scan_coupon_request.model.dart';
import 'package:nikitchem/data/models/scan/scan_coupon_response.model.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/scan/scan.repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/utils/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';
import 'coupon.viewstate.dart';

///
class CouponViewModel extends BaseViewModel<CouponViewState>
    with EventMixin<AppEvent> {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  ScanRepository scanRepository;

  ///
  LocalStorage localStorage;

  ///
  TextEditingController couponController = TextEditingController();

  ///
  CouponViewModel(this.scanRepository, this.localStorage)
      : super(CouponViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  void enableLoad(String value) {
    if (couponController.text != '') {
      setState(state.copyWith(isShimmer: true));
    } else {
      setState(state.copyWith(isShimmer: false));
    }
  }

  ///
  /// scan Coupon Detail
  ///
  void scanCouponDetail({required BuildContext? context}) async {
    setState(state.copyWith(isLoad: true));
    ApiResult<ScanCouponResponse?> result = await runApiInSafeZone(
        () => scanRepository.scanCouponDetail(ScanCouponRequest(
              deviceOs: Platform.operatingSystem.toString(),
              keykjm: localStorage.retrieveString(StorageKey.keykjm).toString(),
              couponCode: couponController.text,
              platForm: Platform.isAndroid ? 'android' : 'ios',
              latitude: '${localStorage.retrieveDouble(StorageKey.latitude)}',
              longitude: '${localStorage.retrieveDouble(StorageKey.longitude)}',
            ).toJson()));
    debugPrint(result.isSucceeded.toString());
    if (result.isSucceeded) {
      setState(state.copyWith(isLoad: false));
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context!,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              showCancelButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AutoRouter.of(context!).push(ApiSuccessScreen(
              isScanScreen: true,
              onTap: () async {
                await AutoRouter.of(context).maybePop();
                AutoRouter.of(context).maybePop();
              },
              image: 'assets/images/group_338.png',
              subTitle: result.data?.data?.errorMessage,
              title: localLanguage?.keyFailure ?? LocaleKeys.failure.tr(),
              buttonName:
                  localLanguage?.keyScanAgin ?? LocaleKeys.scanAgain.tr()));
        }
      } else {
        setState(state.copyWith(scanCouponResponse: result.data));
        couponController.clear();

        localStorage.save(
            StorageKey.accountBalance, result.data?.data?.balance);
        fireEvent(const ScanCouponEvent());

        if (result.data?.data?.couponAmount != null) {
          await navigateToSuccessScreen(
              context!, result.data?.data?.couponAmount);
        } else {
          await AppSnackBar.failureSnackBar(context!,
              contentMessage: localLanguage?.keyAlreadyCouponScanned ??
                  LocaleKeys.alreadyCouponScanned.tr());
        }
      }
    } else {
      setState(state.copyWith(isLoad: false));
      ApiResult.catchError(result, context!);
    }
  }

  ///
  Future<void> navigateToSuccessScreen(
      BuildContext context, double? couponAmount) async {
    await AutoRouter.of(context).push(ApiSuccessScreen(
        onTap: () {
          AutoRouter.of(context).maybePop();
        },
        image: 'assets/images/group_337.png',
        subTitle: localLanguage?.keyYourCouponPoints != null &&
                localLanguage?.keyAddedIntoYourWalletSuccessfully != null
            ? '${localLanguage?.keyYourCouponPoints} ${couponAmount?.toInt()} ${localLanguage?.keyAddedIntoYourWalletSuccessfully}'
            : LocaleKeys.yourCouponPointsAddedIntoYourWalletSuccessfully.tr(
                namedArgs: <String, String>{
                    'points': '${couponAmount?.toInt()}'
                  }),
        title: localLanguage?.keyCongratulations ??
            LocaleKeys.congratulations.tr(),
        buttonName: localLanguage?.keyGoBack ?? LocaleKeys.goBack.tr()));
  }
}
