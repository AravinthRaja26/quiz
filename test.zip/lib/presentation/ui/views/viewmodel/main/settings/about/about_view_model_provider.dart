
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/about/about_view_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class AboutUsProvider extends StatelessWidget {
  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;
  ///
  final dynamic vsync;

  ///
  const AboutUsProvider({super.key, required this.builder, this.child,this.vsync});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<AboutUsViewModel>(
        builder: builder,
        lazy: false,
        create: (BuildContext context) {
          return AboutUsViewModel(
              )..init(vsync);
        });
  }
}
