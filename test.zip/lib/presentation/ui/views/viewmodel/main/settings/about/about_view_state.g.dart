// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'about_view_state.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$AboutUsViewStateCWProxy {
  AboutUsViewState isEnabled(bool isEnabled);

  AboutUsViewState isShimmer(bool isShimmer);

  AboutUsViewState currentIndex(int currentIndex);

  AboutUsViewState contactUsResponse(ContactUsResponse contactUsResponse);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `AboutUsViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// AboutUsViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  AboutUsViewState call({
    bool? isEnabled,
    bool? isShimmer,
    int? currentIndex,
    ContactUsResponse? contactUsResponse,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfAboutUsViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfAboutUsViewState.copyWith.fieldName(...)`
class _$AboutUsViewStateCWProxyImpl implements _$AboutUsViewStateCWProxy {
  const _$AboutUsViewStateCWProxyImpl(this._value);

  final AboutUsViewState _value;

  @override
  AboutUsViewState isEnabled(bool isEnabled) => this(isEnabled: isEnabled);

  @override
  AboutUsViewState isShimmer(bool isShimmer) => this(isShimmer: isShimmer);

  @override
  AboutUsViewState currentIndex(int currentIndex) =>
      this(currentIndex: currentIndex);

  @override
  AboutUsViewState contactUsResponse(ContactUsResponse contactUsResponse) =>
      this(contactUsResponse: contactUsResponse);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `AboutUsViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// AboutUsViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  AboutUsViewState call({
    Object? isEnabled = const $CopyWithPlaceholder(),
    Object? isShimmer = const $CopyWithPlaceholder(),
    Object? currentIndex = const $CopyWithPlaceholder(),
    Object? contactUsResponse = const $CopyWithPlaceholder(),
  }) {
    return AboutUsViewState(
      isEnabled: isEnabled == const $CopyWithPlaceholder() || isEnabled == null
          ? _value.isEnabled
          // ignore: cast_nullable_to_non_nullable
          : isEnabled as bool,
      isShimmer: isShimmer == const $CopyWithPlaceholder() || isShimmer == null
          ? _value.isShimmer
          // ignore: cast_nullable_to_non_nullable
          : isShimmer as bool,
      currentIndex:
          currentIndex == const $CopyWithPlaceholder() || currentIndex == null
              ? _value.currentIndex
              // ignore: cast_nullable_to_non_nullable
              : currentIndex as int,
      contactUsResponse: contactUsResponse == const $CopyWithPlaceholder() ||
              contactUsResponse == null
          ? _value.contactUsResponse
          // ignore: cast_nullable_to_non_nullable
          : contactUsResponse as ContactUsResponse,
    );
  }
}

extension $AboutUsViewStateCopyWith on AboutUsViewState {
  /// Returns a callable class that can be used as follows: `instanceOfAboutUsViewState.copyWith(...)` or like so:`instanceOfAboutUsViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$AboutUsViewStateCWProxy get copyWith => _$AboutUsViewStateCWProxyImpl(this);
}
