import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/enum/setting_enum.dart';
import 'package:nikitchem/data/models/setting/setting_model.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
part 'setting.viewstate.g.dart';

///
@CopyWith()
class SettingViewState extends ViewState {
  ///
  final String name;

  ///
  final SettingsType settingsType;

  ///
  final List<SettingModel> listData;

  ///
  const SettingViewState(this.listData, this.settingsType,
      {required this.name});

  ///
  SettingViewState.initial()
      : name = 'Offline',
        settingsType = SettingsType.manageAccount,
        listData = <SettingModel>[
          /*SettingModel(
            image: Image.asset(
              AssetImagePath.bankAccount,
              width: 20,
              height: 20,
              fit: BoxFit.fill,
            ),
            title: localLanguage?.keyManageBankAccounts?? LocaleKeys.manageBankAccounts.tr(),
            settingData: SettingsType.manageAccount,
          ),*/
          SettingModel(
            image: Image.asset(
              AssetImagePath.language,
              width: 22,
              height: 21,
              fit: BoxFit.fill,
            ),
            title: localLanguage?.keyLanguageSettings??LocaleKeys.languageSettings.tr(),
            settingData: SettingsType.languageSetting,
          ),
          /*SettingModel(
            image: Image.asset(
              AssetImagePath.email,
              width: 20,
              height: 20,
              fit: BoxFit.fill,
            ),
            title: localLanguage?.keyContactUs??LocaleKeys.contactUs.tr(),
            settingData: SettingsType.contactUs,
          ),*/
          SettingModel(
            image: Image.asset(
              AssetImagePath.about,
              width: 20,
              height: 20,
              fit: BoxFit.fill,
            ),
            title: localLanguage?.keyAboutUs??LocaleKeys.aboutUs.tr(),
            settingData: SettingsType.aboutUs,
          ),
          SettingModel(
            image: Image.asset(
              AssetImagePath.notificationImage,
              width: 23,
              height: 23,
              fit: BoxFit.fill,
            ),
            title:localLanguage?.keyNotifications?? LocaleKeys.notifications.tr(),
            settingData: SettingsType.notifications,
          ),
          SettingModel(
            image: Image.asset(
              AssetImagePath.security,
              width: 20,
              height: 20,
              fit: BoxFit.fill,
            ),
            title: localLanguage?.keyPrivacyPolicy??LocaleKeys.privacyPolicy.tr(),
            settingData: SettingsType.privacyPolicy,
          ),
          SettingModel(
            image: Image.asset(
              AssetImagePath.message,
              width: 20,
              height: 20,
              fit: BoxFit.fill,
            ),
            title: localLanguage?.keyTermsAndConditions??LocaleKeys.termsAndCondition.tr(),
            settingData: SettingsType.termsCondition,
          ),
          SettingModel(
            image: Image.asset(
              AssetImagePath.customerService,
              width: 23,
              height: 20.5,
              fit: BoxFit.fill,
            ),
            title:localLanguage?.keySupport?? LocaleKeys.support.tr(),
            settingData: SettingsType.support,
          ),
          SettingModel(
            image: Image.asset(
              AssetImagePath.tickets,
              width: 20,
              height: 20,
              fit: BoxFit.fill,
            ),
            title: localLanguage?.keyTicketDetails??LocaleKeys.ticketDetails.tr(),
            settingData: SettingsType.ticketDetails,
          ),
        ];

  @override
  List<Object?> get props => <Object>[name, listData, settingsType];
}
