import 'dart:async';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/utils/web_url.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/terms_condition/terms_condition.viewstate.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:webview_flutter/webview_flutter.dart';

///
class TermsConditionViewModel extends BaseViewModel<TermsConditionViewState> with EventMixin<AppEvent>{
  ///
  ///
  WebViewController controller = WebViewController();
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  final LocalStorage localStorage = injector<LocalStorage>();

  ///
  TermsConditionViewModel() : super(TermsConditionViewState.initial()){
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  String webUrl(){
    return '${WebUrl.termsConditions}${localStorage.retrieveString(StorageKey.selectLanguage) ?? 'en'}';
  }

  ///
  void init() {
  }

}
