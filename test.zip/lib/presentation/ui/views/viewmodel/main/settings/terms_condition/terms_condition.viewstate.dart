import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'terms_condition.viewstate.g.dart';

///
@CopyWith()
class TermsConditionViewState extends ViewState {
  ///
  final bool isEnabled;

  ///
  final bool isShimmer;

  ///
  final String? termsConditionList;

  ///
  final int currentIndex;

  ///
  const TermsConditionViewState({
    required this.isEnabled,
    required this.isShimmer,
    required this.currentIndex,
    this.termsConditionList,
  });

  ///
  TermsConditionViewState.initial()
      : isEnabled = false,
        isShimmer = false,
        currentIndex = 0,
        termsConditionList = '';

  @override
  List<Object?> get props =>
      <Object?>[isEnabled, isShimmer, currentIndex, termsConditionList];
}
