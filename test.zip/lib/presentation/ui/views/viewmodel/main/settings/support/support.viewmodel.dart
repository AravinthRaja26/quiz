import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/enquiry_event.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/contact_us/contact_us_response.dart';
import 'package:nikitchem/data/models/support/support_model.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/support/support.repository.dart';
import 'package:nikitchem/data/repository/ticket/ticket.reository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/support/support.viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';

///
class SupportViewModel extends BaseViewModel<SupportViewState>
    with EventMixin<AppEvent> {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  ///
  TextEditingController commentController = TextEditingController();

  ///
  AppNavigation appNavigation;

  ///
  LocalStorage localStorage = injector<LocalStorage>();

  ///
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  ///
  final SupportRepository supportRepository;

  ///
  TicketRepository ticketRepository;

  ///
  SupportViewModel(
      this.supportRepository, this.appNavigation, this.ticketRepository)
      : super(SupportViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  void init(BuildContext context) {
    consumerDetail(context);
  }

  ///
  void navigationToSupportScreen(BuildContext context) {
    fireEvent(const EnquiryEvent());
    appNavigation.navigationToSupportIssueScreen(context);
  }

  ///
  void enableLoad(String value) {
    if (commentController.text != '') {
      setState(state.copyWith(isShimmer: true));
    } else {
      setState(state.copyWith(isShimmer: false));
    }
  }

  ///
  void viewMore(BuildContext context, ConsumerData? consumerData) async {
    await viewMoreConsumerDetail(
        context, consumerData?.questionId.toString() ?? '');

    state.consumerDetails?.data?.forEach((ConsumerData element) {
      if (element == consumerData) {
        element.viewMore = true;
      } else if (element.viewMore ==true &&consumerData?.viewMore == true) {
        element.viewMore = false;
      } else {
        element.viewMore = false;
      }
    });

    ConsumerDetails? temp = state.consumerDetails;
    setState(state.copyWith(consumerDetails: temp));
    notifyListeners();
  }

  ///
  void viewLess(BuildContext context, ConsumerData? consumerData) async {
    await viewMoreConsumerDetail(
        context, consumerData?.questionId.toString() ?? '');

    state.consumerDetails?.data?.forEach((ConsumerData element) {
      element.viewMore = false;
    });

    ConsumerDetails? temp = state.consumerDetails;
    setState(state.copyWith(consumerDetails: temp));
    notifyListeners();
  }

  ///
  void hideViewMore(BuildContext context) async {
    state.consumerDetails?.data?.forEach((ConsumerData element) {
      element.viewMore = false;
    });
    ConsumerDetails? temp = state.consumerDetails;
    setState(state.copyWith(consumerDetails: temp));
    notifyListeners();
  }

  ///
  /// consumer Detail
  ///
  void consumerDetail(BuildContext? context) async {
    setState(state.copyWith(isLoad: true));
    ApiResult<ConsumerDetails?> result =
        await runApiInSafeZone(() => supportRepository.consumerDetail());
    if (result.isSucceeded) {
      setState(state.copyWith(isLoad: false));
      if (result.data?.status == 'error') {
        if (result.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context!,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context!,
              contentMessage: result.data?.errorMessage);
        }
      } else {
        List<ConsumerData> temp = <ConsumerData>[];

        if(result.data?.data !=null){
        for(int i = 0;i<result.data!.data!.length;i++){
          if(result.data?.data?[i].consumerOption !='Other issues'){
            temp.add(result.data!.data![i]);
          }
        }}

        result.data?.data = temp;
        setState(state.copyWith(consumerDetails: result.data, isLoad: false));
      }
    } else {
      ApiResult.catchError(result, context!);
    }
  }

  ///
  Future<void> viewMoreConsumerDetail(BuildContext? context, String id) async {
    ApiResult<ConsumerDetails?> result = await runApiInSafeZone(
        () => supportRepository.viewMoreConsumerDetail(id));
    if (result.isSucceeded) {
      setState(state.copyWith(isLoad: false));
      if (result.data?.status == 'error') {
        if (result.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context!,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context!,
              contentMessage: result.data?.errorMessage);
        }
      } else {
        setState(state.copyWith(
            viewMoreConsumerDetails: result.data, isLoad: false));
      }
    } else {
      ApiResult.catchError(result, context!);
    }
  }

  ///
  /// create Ticket List
  ///
  void createTicket(BuildContext context) async {
    Map<String, dynamic> data = <String, dynamic>{
      'keykjm': localStorage.retrieveString(StorageKey.keykjm),
      'questionId': <int>[1000],
      'text': commentController.text,
      'formData': [
        <String, String>{
          'network': '',
          'networkCircle': '',
          'amount': '',
          'mobileNumber': '',
          'networkType': ''
        }
      ]
    };
    ApiResult<ContactUsResponse?> result =
        await runApiInSafeZone(() => ticketRepository.createTicket(data));

    if (result.isSucceeded) {
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      } else {
        AutoRouter.of(context).push(ApiSuccessScreen(
          onTap: () {
            AutoRouter.of(context).maybePop();
          },
          image: 'assets/images/group_322.png',
          title: localLanguage?.keyCreated ?? 'Created!',
          subTitle: localLanguage?.keyTicketDetailSuccessMessage ??
              'Your ticket has been created. Please check the ticket details from Settings > Ticket Details',
        ));
        commentController.clear();
      }
    }
  }
}
