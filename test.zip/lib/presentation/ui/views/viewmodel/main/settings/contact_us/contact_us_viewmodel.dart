import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/contact_us/contactUsRequstBody.dart';
import 'package:nikitchem/data/models/contact_us/contact_us_response.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/contact_us/contact_us_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/utils/valitaion.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/contact_us/contact_us_viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

///
class ContactUsViewModel extends BaseViewModel<ContactUsViewState>
    with EventMixin<AppEvent> {
  final RegExp _phoneRegex = RegExp(r'^([0-9])\1{2}\1{3}\1{4}$');

  ///
  final ContactUsRepository contactUsRepository;

  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  final LocalStorage localStorage;

  ///
  ContactUsViewModel(this.contactUsRepository, this.localStorage)
      : super(ContactUsViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  TextEditingController phoneController = TextEditingController();

  ///
  TextEditingController emailController = TextEditingController();

  ///
  TextEditingController messageController = TextEditingController();

  ///
  String? emailValidation() {
    return AppValidation.emailVerification(emailController.text);
  }

  ///
  String? phoneValidate(String value) {
    return AppValidation.phoneValidation(value);
  }

  ///
  void enableLoad(String value) {
    if (phoneController.text != '' &&
        emailController.text != '' &&
        messageController.text != '' &&
        messageController.text.length > 4) {
      setState(state.copyWith(isShimmer: true));
    } else {
      setState(state.copyWith(isShimmer: false));
    }
  }

  ///
  void checkValidate({required BuildContext context}) {
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    if (emailController.text.isEmpty) {
      AppSnackBar.successSnackBar(context, contentMessage: emailValidation());
    } else if (emailController.text.isNotEmpty && emailValidation() != null) {
      AppSnackBar.successSnackBar(context, contentMessage: emailValidation());
    } else if (phoneController.text == '') {
      AppSnackBar.successSnackBar(context,
          contentMessage: phoneValidate(phoneController.text));
    } else if (_phoneRegex.hasMatch(phoneController.text)) {
      AppSnackBar.successSnackBar(context,
          contentMessage: localLanguage?.keyInvalidPhoneNumber ??
              LocaleKeys.invalidPhoneNumber.tr());
    } else if (messageController.text == '') {
      AppSnackBar.successSnackBar(context,
          contentMessage: localLanguage?.keyMessageMustShouldNotBeEmpty ??
              LocaleKeys.messageMustShouldNotBeEmpty.tr());
    } else {
      // Call the api
      sendContactUsMail(context);
    }
  }

  ///
  void sendContactUsMail(BuildContext context) async {
    setState(state.copyWith(isEnabled: true));
    ApiResult<ContactUsResponse> result = await runApiInSafeZone(() =>
        contactUsRepository.sendContactUsEmail(
            contactUsRequestBody: ContactUsRequestBody(
                email: emailController.text,
                message: messageController.text,
                mobile: phoneController.text,
                subject: '')));

    if (result.isSucceeded) {
      setState(state.copyWith(isEnabled: false));
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              doneButtonText: LocaleKeys.ok.tr(),
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: false,
              subTitle: localLanguage?.keyYouAreLoggedInAnotherDevice ??
                  LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          },
              title: localLanguage?.keyYouAreLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      } else {
        setState(
            state.copyWith(contactUsResponse: result.data, isShimmer: false));
        clearText();
        navigateToSuccessScreen(context,
            message: result.data?.status == 'error'
                ? result.data?.data?.errorMessage
                : result.data?.data?.data);
      }
    } else {
      ApiResult.catchError(result, context);
    }
  }

  ///
  void clearText() {
    messageController.clear();
  }

  ///
  void navigateToSuccessScreen(BuildContext context, {String? message}) {
    AutoRouter.of(context).push(ApiSuccessScreen(
        title: localLanguage?.keyMailSent ?? LocaleKeys.mailSent.tr(),
        onTap: () {
          AutoRouter.of(context).maybePop();
        },
        image: 'assets/images/mail_sent.png',
        subTitle:
            '${localLanguage?.keyEmailSent ?? LocaleKeys.yourEmailHasBeenSentSuccessfully.tr()} \n${localLanguage?.keyLitaskiTeamWillGetBackToYouSoon ?? 'Litaski team will get back to you soon'}',
        buttonName: localLanguage?.keyGoBack ??LocaleKeys.goBack.tr()));
  }

  ///
  void init() {
    phoneController.text =
        localStorage.retrieveString(StorageKey.userPhoneNumber) ?? '';
    emailController.text =
        localStorage.retrieveString(StorageKey.userEmail) ?? '';
  }
}
