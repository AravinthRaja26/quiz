import 'dart:async';
import 'dart:io';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/utils/web_url.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/about/about_view_state.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

///
class AboutUsViewModel extends BaseViewModel<AboutUsViewState>with EventMixin<AppEvent> {
  ///
  TabController? tabController;

  ///
  WebViewController? controller;

  ///
  String version = '';

  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  WebViewController? aboutAppController;

  ///
  LocalStorage localStorage = injector<LocalStorage>();

  ///
  AboutUsViewModel() : super(AboutUsViewState.initial()){
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  void init(TickerProvider vsync) {
    getAppVersion();
    tabController = TabController(vsync: vsync, length: 2)
      ..addListener(() {
        setCurrentIndex(tabController?.index ?? 0);
      });
  }

  ///
  void getAppVersion()async{
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    version = packageInfo.version;
  }

  ///
  String  aboutUsWebUrl(){
    return '${WebUrl.aboutUsUrl}${localStorage.retrieveString(StorageKey.selectLanguage) ?? 'en'}';
  }
///
  String aboutAppWebUrl(){
    return '${WebUrl.aboutAppUrl}${localStorage.retrieveString(StorageKey.selectLanguage) ?? 'en'}';
  }


  ///
  void openDefaultBrowser() {
    launchUrl(Uri.parse('http://nikitchem.in/'),
        mode: LaunchMode.externalApplication);
  }

  ///
  Future<String?> getAndroidVersion() async {
    if (Platform.isAndroid) {
      DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      return androidInfo.version.release;
    } else if (Platform.isIOS) {
      DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      return iosInfo.systemVersion;
    }
    throw UnsupportedError('Platform is not supported');
  }

  ///
  void setCurrentIndex(int currentIndex) {
    setState(state.copyWith(currentIndex: currentIndex));
  }
}
