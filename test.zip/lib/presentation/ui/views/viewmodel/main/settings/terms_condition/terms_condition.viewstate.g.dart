// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'terms_condition.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$TermsConditionViewStateCWProxy {
  TermsConditionViewState isEnabled(bool isEnabled);

  TermsConditionViewState isShimmer(bool isShimmer);

  TermsConditionViewState currentIndex(int currentIndex);

  TermsConditionViewState termsConditionList(String? termsConditionList);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `TermsConditionViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// TermsConditionViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  TermsConditionViewState call({
    bool? isEnabled,
    bool? isShimmer,
    int? currentIndex,
    String? termsConditionList,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfTermsConditionViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfTermsConditionViewState.copyWith.fieldName(...)`
class _$TermsConditionViewStateCWProxyImpl
    implements _$TermsConditionViewStateCWProxy {
  const _$TermsConditionViewStateCWProxyImpl(this._value);

  final TermsConditionViewState _value;

  @override
  TermsConditionViewState isEnabled(bool isEnabled) =>
      this(isEnabled: isEnabled);

  @override
  TermsConditionViewState isShimmer(bool isShimmer) =>
      this(isShimmer: isShimmer);

  @override
  TermsConditionViewState currentIndex(int currentIndex) =>
      this(currentIndex: currentIndex);

  @override
  TermsConditionViewState termsConditionList(String? termsConditionList) =>
      this(termsConditionList: termsConditionList);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `TermsConditionViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// TermsConditionViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  TermsConditionViewState call({
    Object? isEnabled = const $CopyWithPlaceholder(),
    Object? isShimmer = const $CopyWithPlaceholder(),
    Object? currentIndex = const $CopyWithPlaceholder(),
    Object? termsConditionList = const $CopyWithPlaceholder(),
  }) {
    return TermsConditionViewState(
      isEnabled: isEnabled == const $CopyWithPlaceholder() || isEnabled == null
          ? _value.isEnabled
          // ignore: cast_nullable_to_non_nullable
          : isEnabled as bool,
      isShimmer: isShimmer == const $CopyWithPlaceholder() || isShimmer == null
          ? _value.isShimmer
          // ignore: cast_nullable_to_non_nullable
          : isShimmer as bool,
      currentIndex:
          currentIndex == const $CopyWithPlaceholder() || currentIndex == null
              ? _value.currentIndex
              // ignore: cast_nullable_to_non_nullable
              : currentIndex as int,
      termsConditionList: termsConditionList == const $CopyWithPlaceholder()
          ? _value.termsConditionList
          // ignore: cast_nullable_to_non_nullable
          : termsConditionList as String?,
    );
  }
}

extension $TermsConditionViewStateCopyWith on TermsConditionViewState {
  /// Returns a callable class that can be used as follows: `instanceOfTermsConditionViewState.copyWith(...)` or like so:`instanceOfTermsConditionViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$TermsConditionViewStateCWProxy get copyWith =>
      _$TermsConditionViewStateCWProxyImpl(this);
}
