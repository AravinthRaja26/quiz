// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'privacy_policy.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$PrivacyPolicyViewStateCWProxy {
  PrivacyPolicyViewState isEnabled(bool isEnabled);

  PrivacyPolicyViewState isShimmer(bool isShimmer);

  PrivacyPolicyViewState currentIndex(int currentIndex);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `PrivacyPolicyViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// PrivacyPolicyViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  PrivacyPolicyViewState call({
    bool? isEnabled,
    bool? isShimmer,
    int? currentIndex,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfPrivacyPolicyViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfPrivacyPolicyViewState.copyWith.fieldName(...)`
class _$PrivacyPolicyViewStateCWProxyImpl
    implements _$PrivacyPolicyViewStateCWProxy {
  const _$PrivacyPolicyViewStateCWProxyImpl(this._value);

  final PrivacyPolicyViewState _value;

  @override
  PrivacyPolicyViewState isEnabled(bool isEnabled) =>
      this(isEnabled: isEnabled);

  @override
  PrivacyPolicyViewState isShimmer(bool isShimmer) =>
      this(isShimmer: isShimmer);

  @override
  PrivacyPolicyViewState currentIndex(int currentIndex) =>
      this(currentIndex: currentIndex);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `PrivacyPolicyViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// PrivacyPolicyViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  PrivacyPolicyViewState call({
    Object? isEnabled = const $CopyWithPlaceholder(),
    Object? isShimmer = const $CopyWithPlaceholder(),
    Object? currentIndex = const $CopyWithPlaceholder(),
  }) {
    return PrivacyPolicyViewState(
      isEnabled: isEnabled == const $CopyWithPlaceholder() || isEnabled == null
          ? _value.isEnabled
          // ignore: cast_nullable_to_non_nullable
          : isEnabled as bool,
      isShimmer: isShimmer == const $CopyWithPlaceholder() || isShimmer == null
          ? _value.isShimmer
          // ignore: cast_nullable_to_non_nullable
          : isShimmer as bool,
      currentIndex:
          currentIndex == const $CopyWithPlaceholder() || currentIndex == null
              ? _value.currentIndex
              // ignore: cast_nullable_to_non_nullable
              : currentIndex as int,
    );
  }
}

extension $PrivacyPolicyViewStateCopyWith on PrivacyPolicyViewState {
  /// Returns a callable class that can be used as follows: `instanceOfPrivacyPolicyViewState.copyWith(...)` or like so:`instanceOfPrivacyPolicyViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$PrivacyPolicyViewStateCWProxy get copyWith =>
      _$PrivacyPolicyViewStateCWProxyImpl(this);
}
