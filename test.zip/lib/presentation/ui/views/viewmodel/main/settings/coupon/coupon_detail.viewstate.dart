import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'coupon_detail.viewstate.g.dart';

///
@CopyWith()
class CouponDetailViewState extends ViewState {
  ///
  final String? name;

  ///
  final bool? isEnabled;

  ///
  final bool? isShimmer;

  ///
  const CouponDetailViewState(this.isEnabled, this.isShimmer, this.name);

  ///
  CouponDetailViewState.initial()
      : name = 'Offline',
        isShimmer = false,
        isEnabled = false;

  @override
  List<Object?> get props => <Object?>[name, isEnabled, isShimmer];
}
