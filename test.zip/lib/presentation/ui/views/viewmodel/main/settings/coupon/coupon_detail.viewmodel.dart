import 'dart:async';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/consumer/consumer_transaction.model.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/coupon/coupon_detail.viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';

///
class CouponDetailViewModel extends BaseViewModel<CouponDetailViewState>
    with EventMixin<AppEvent> {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  CouponDetailViewModel() : super(CouponDetailViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  void init(BuildContext context, Earned? consumerEarnedDetails,
      Expired? consumerExpiredDetails) {
    debugPrint('---------------->$consumerEarnedDetails');
    debugPrint('---------------->$consumerExpiredDetails');
  }

  ///
  String scanDateFormat(String? scan) {
    DateTime tempDate = DateFormat('dd MMM yyyy hh:mm a').parse(scan!);
    String date = DateFormat('dd MMM yyyy').format(tempDate);
    return date;
  }
}
