import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/repository/scan/scan.repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/coupon/coupon.viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class CouponProvider extends StatelessWidget {
  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;

  ///
  const CouponProvider({super.key, required this.builder, this.child});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<CouponViewModel>(
        builder: builder,
        lazy: false,
        create: (BuildContext context) {
          return CouponViewModel(injector<ScanRepository>(),injector<LocalStorage>());
        });
  }
}
