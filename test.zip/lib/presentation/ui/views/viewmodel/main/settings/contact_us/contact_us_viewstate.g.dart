// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contact_us_viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$ContactUsViewStateCWProxy {
  ContactUsViewState isEnabled(bool isEnabled);

  ContactUsViewState isShimmer(bool isShimmer);

  ContactUsViewState contactUsResponse(ContactUsResponse contactUsResponse);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `ContactUsViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// ContactUsViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  ContactUsViewState call({
    bool? isEnabled,
    bool? isShimmer,
    ContactUsResponse? contactUsResponse,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfContactUsViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfContactUsViewState.copyWith.fieldName(...)`
class _$ContactUsViewStateCWProxyImpl implements _$ContactUsViewStateCWProxy {
  const _$ContactUsViewStateCWProxyImpl(this._value);

  final ContactUsViewState _value;

  @override
  ContactUsViewState isEnabled(bool isEnabled) => this(isEnabled: isEnabled);

  @override
  ContactUsViewState isShimmer(bool isShimmer) => this(isShimmer: isShimmer);

  @override
  ContactUsViewState contactUsResponse(ContactUsResponse contactUsResponse) =>
      this(contactUsResponse: contactUsResponse);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `ContactUsViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// ContactUsViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  ContactUsViewState call({
    Object? isEnabled = const $CopyWithPlaceholder(),
    Object? isShimmer = const $CopyWithPlaceholder(),
    Object? contactUsResponse = const $CopyWithPlaceholder(),
  }) {
    return ContactUsViewState(
      isEnabled: isEnabled == const $CopyWithPlaceholder() || isEnabled == null
          ? _value.isEnabled
          // ignore: cast_nullable_to_non_nullable
          : isEnabled as bool,
      isShimmer: isShimmer == const $CopyWithPlaceholder() || isShimmer == null
          ? _value.isShimmer
          // ignore: cast_nullable_to_non_nullable
          : isShimmer as bool,
      contactUsResponse: contactUsResponse == const $CopyWithPlaceholder() ||
              contactUsResponse == null
          ? _value.contactUsResponse
          // ignore: cast_nullable_to_non_nullable
          : contactUsResponse as ContactUsResponse,
    );
  }
}

extension $ContactUsViewStateCopyWith on ContactUsViewState {
  /// Returns a callable class that can be used as follows: `instanceOfContactUsViewState.copyWith(...)` or like so:`instanceOfContactUsViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$ContactUsViewStateCWProxy get copyWith =>
      _$ContactUsViewStateCWProxyImpl(this);
}
