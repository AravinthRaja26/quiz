import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/support/support_model.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'support.viewstate.g.dart';

///
@CopyWith()
class SupportViewState extends ViewState {
  ///
  ConsumerDetails? consumerDetails;
  ///
  ConsumerDetails? viewMoreConsumerDetails;

  ///
  final bool? isLoad;

  ///
  final bool? isShimmer;

  ///
  final bool? isEnabled;

  ///
  SupportViewState({
    this.consumerDetails,
    this.viewMoreConsumerDetails,
    this.isLoad,
    this.isEnabled,
    this.isShimmer,
  });

  ///
  /// Named Constructor for initial state
  ///
  SupportViewState.initial()
      : consumerDetails = ConsumerDetails(),viewMoreConsumerDetails = ConsumerDetails(),
        isLoad = false,
        isShimmer = false,
        isEnabled = false;

  ///
  /// Props
  ///
  @override
  List<Object?> get props =>
      <Object?>[consumerDetails, isLoad, isShimmer, isEnabled,viewMoreConsumerDetails];
}
