import 'package:nikitchem/data/models/consumer/consumer_transaction.model.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/coupon/coupon_detail.viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class CouponDetailProvider extends StatelessWidget {
  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;

  ///
  final Earned? consumerEarnedDetails;

  ///
  final Expired? consumerExpiredDetails;

  ///
  const CouponDetailProvider(
      {super.key,
      required this.builder,
      this.child,
      this.consumerEarnedDetails,
      this.consumerExpiredDetails});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<CouponDetailViewModel>(
        builder: builder,
        lazy: false,
        create: (BuildContext context) {
          return CouponDetailViewModel()
            ..init(context, consumerEarnedDetails, consumerExpiredDetails);
        });
  }
}
