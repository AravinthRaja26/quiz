import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/enquiry_event.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/enum/setting_enum.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/setting/setting_model.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/utils/valitaion.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/settings/setting.viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';

///
class SettingViewModel extends BaseViewModel<SettingViewState>
    with EventMixin<AppEvent> {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  ///
  final LocalStorage localStorage;

  ///
  AppNavigation appNavigation;

  ///
  SettingViewModel(this.appNavigation, this.localStorage)
      : super(SettingViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith(listData: settingsList()));
        notifyListeners();
      }
    });
  }

  ///
  Future<void> settingScreenNavigation(
      BuildContext context, SettingsType settingListData) async {
    switch (settingListData) {
      case SettingsType.manageAccount:
        fireEvent(const EnquiryEvent());
        await appNavigation.navigationToManageBankAccountScreen(context);
        fireEvent(const EnquiryEvent());
        break;
      case SettingsType.languageSetting:
        fireEvent(const EnquiryEvent());
        await appNavigation.navigationToLanguage(context);
        fireEvent(const EnquiryEvent());
        break;
      case SettingsType.contactUs:
        await appNavigation.navigationToContactScreen(context);
        fireEvent(const EnquiryEvent());
        break;
      case SettingsType.aboutUs:
        await appNavigation.navigationToAboutScreen(context);
        fireEvent(const EnquiryEvent());
        break;
      case SettingsType.notifications:
        await appNavigation.navigationToNotificationScreen(context);
        fireEvent(const EnquiryEvent());
        break;
      case SettingsType.privacyPolicy:
        await appNavigation.navigationToPrivacyScreen(context);
        fireEvent(const EnquiryEvent());
        break;
      case SettingsType.termsCondition:
        await appNavigation.navigationToTermsAndConditionScreen(context);
        fireEvent(const EnquiryEvent());
        break;
      case SettingsType.support:
        fireEvent(const EnquiryEvent());
        await appNavigation.navigationToSupportScreen(context);
        fireEvent(const EnquiryEvent());
        break;
      case SettingsType.ticketDetails:
        fireEvent(const EnquiryEvent());
        await appNavigation.navigationToTicketListScreen(context);
        fireEvent(const EnquiryEvent());
        break;
    }
  }

  ///
  Future<bool> navigateToHomeScreen(BuildContext context) async {
    AutoTabsRouter.of(context).setActiveIndex(0);
    return false;
  }

  ///
  void logOut(BuildContext context) {
    localStorage.save(StorageKey.isProfileUpdate, false);
    localStorage.save(StorageKey.isLogin, false);
    localStorage.save(StorageKey.isFinishedTutorial, false);
    localStorage.save(StorageKey.isShowKeyWarning, false);
    localStorage.delete(StorageKey.userName);
    localStorage.delete(StorageKey.countryCode);
    appNavigation.navigationToTutorial(context);
  }

  ///
  String? accountHolderNameVerification(String value) {
    return AppValidation.accountHolderNameVerification(value: value);
  }

  ///
  void showConfirmDialog(BuildContext context) {
    confirmationDialog(context,
        image: 'assets/images/log_out.png',
        title: localLanguage?.keyLogout ?? LocaleKeys.logout,
        cancelButtonText: localLanguage?.keyNo ?? 'NO',
        doneButtonText: localLanguage?.keyYes ?? 'YES',
        subTitle: localLanguage?.keyYouAreLoggedOut ??
            LocaleKeys.doYouWantLogout.tr(), onTap: () {
      AutoRouter.of(context).maybePop();
      logOut(context);
    });
  }

  ///
  List<SettingModel> settingsList() {
    return <SettingModel>[
      /*SettingModel(
        image: Image.asset(
          AssetImagePath.bankAccount,
          width: 20,
          height: 20,
          fit: BoxFit.fill,
        ),
        title: localLanguage?.keyManageBankAccounts ??
            LocaleKeys.manageBankAccounts.tr(),
        settingData: SettingsType.manageAccount,
      ),*/
      SettingModel(
        image: Image.asset(
          AssetImagePath.language,
          width: 22,
          height: 21,
          fit: BoxFit.fill,
        ),
        title: localLanguage?.keyLanguageSettings ??
            LocaleKeys.languageSettings.tr(),
        settingData: SettingsType.languageSetting,
      ),
      /*SettingModel(
        image: Image.asset(
          AssetImagePath.email,
          width: 20,
          height: 20,
          fit: BoxFit.fill,
        ),
        title: localLanguage?.keyContactUs ?? LocaleKeys.contactUs.tr(),
        settingData: SettingsType.contactUs,
      ),*/
      SettingModel(
        image: Image.asset(
          AssetImagePath.about,
          width: 20,
          height: 20,
          fit: BoxFit.fill,
        ),
        title: localLanguage?.keyAboutUs ?? LocaleKeys.aboutUs.tr(),
        settingData: SettingsType.aboutUs,
      ),
      SettingModel(
        image: Image.asset(
          AssetImagePath.notificationImage,
          width: 23,
          height: 23,
          fit: BoxFit.fill,
        ),
        title: localLanguage?.keyNotifications ?? LocaleKeys.notifications.tr(),
        settingData: SettingsType.notifications,
      ),
      SettingModel(
        image: Image.asset(
          AssetImagePath.security,
          width: 20,
          height: 20,
          fit: BoxFit.fill,
        ),
        title: localLanguage?.keyPrivacyPolicy ?? LocaleKeys.privacyPolicy.tr(),
        settingData: SettingsType.privacyPolicy,
      ),
      SettingModel(
        image: Image.asset(
          AssetImagePath.message,
          width: 20,
          height: 20,
          fit: BoxFit.fill,
        ),
        title: localLanguage?.keyTermsAndConditions ??
            LocaleKeys.termsAndCondition.tr(),
        settingData: SettingsType.termsCondition,
      ),
      SettingModel(
        image: Image.asset(
          AssetImagePath.customerService,
          width: 23,
          height: 20.5,
          fit: BoxFit.fill,
        ),
        title: localLanguage?.keySupport ?? LocaleKeys.support.tr(),
        settingData: SettingsType.support,
      ),
      SettingModel(
        image: Image.asset(
          AssetImagePath.tickets,
          width: 20,
          height: 20,
          fit: BoxFit.fill,
        ),
        title: localLanguage?.keyTicketDetails ?? LocaleKeys.ticketDetails.tr(),
        settingData: SettingsType.ticketDetails,
      ),
    ];
  }

  ///
  String? accountNumberVerification(String value) {
    return AppValidation.accountNumberVerification(value: value);
  }

  ///
  String? reAccountNumberVerification(String value) {
    return AppValidation.reAccountNumberVerification(
        value: value, accountNumber: '');
  }

  ///
  String? ifscCodeVerification(String value) {
    return AppValidation.ifscCodeVerification(value);
  }
}
