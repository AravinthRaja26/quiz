// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dashboard.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$DashBoardViewStateCWProxy {
  DashBoardViewState isLoading(bool? isLoading);

  DashBoardViewState locationPermission(bool? locationPermission);

  DashBoardViewState userName(String? userName);

  DashBoardViewState currentPage(int? currentPage);

  DashBoardViewState accountBalance(double? accountBalance);

  DashBoardViewState bannerResponse(BannerResponse? bannerResponse);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `DashBoardViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// DashBoardViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  DashBoardViewState call({
    bool? isLoading,
    bool? locationPermission,
    String? userName,
    int? currentPage,
    double? accountBalance,
    BannerResponse? bannerResponse,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfDashBoardViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfDashBoardViewState.copyWith.fieldName(...)`
class _$DashBoardViewStateCWProxyImpl implements _$DashBoardViewStateCWProxy {
  const _$DashBoardViewStateCWProxyImpl(this._value);

  final DashBoardViewState _value;

  @override
  DashBoardViewState isLoading(bool? isLoading) => this(isLoading: isLoading);

  @override
  DashBoardViewState locationPermission(bool? locationPermission) =>
      this(locationPermission: locationPermission);

  @override
  DashBoardViewState userName(String? userName) => this(userName: userName);

  @override
  DashBoardViewState currentPage(int? currentPage) =>
      this(currentPage: currentPage);

  @override
  DashBoardViewState accountBalance(double? accountBalance) =>
      this(accountBalance: accountBalance);

  @override
  DashBoardViewState bannerResponse(BannerResponse? bannerResponse) =>
      this(bannerResponse: bannerResponse);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `DashBoardViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// DashBoardViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  DashBoardViewState call({
    Object? isLoading = const $CopyWithPlaceholder(),
    Object? locationPermission = const $CopyWithPlaceholder(),
    Object? userName = const $CopyWithPlaceholder(),
    Object? currentPage = const $CopyWithPlaceholder(),
    Object? accountBalance = const $CopyWithPlaceholder(),
    Object? bannerResponse = const $CopyWithPlaceholder(),
  }) {
    return DashBoardViewState(
      isLoading: isLoading == const $CopyWithPlaceholder()
          ? _value.isLoading
          // ignore: cast_nullable_to_non_nullable
          : isLoading as bool?,
      locationPermission: locationPermission == const $CopyWithPlaceholder()
          ? _value.locationPermission
          // ignore: cast_nullable_to_non_nullable
          : locationPermission as bool?,
      userName: userName == const $CopyWithPlaceholder()
          ? _value.userName
          // ignore: cast_nullable_to_non_nullable
          : userName as String?,
      currentPage: currentPage == const $CopyWithPlaceholder()
          ? _value.currentPage
          // ignore: cast_nullable_to_non_nullable
          : currentPage as int?,
      accountBalance: accountBalance == const $CopyWithPlaceholder()
          ? _value.accountBalance
          // ignore: cast_nullable_to_non_nullable
          : accountBalance as double?,
      bannerResponse: bannerResponse == const $CopyWithPlaceholder()
          ? _value.bannerResponse
          // ignore: cast_nullable_to_non_nullable
          : bannerResponse as BannerResponse?,
    );
  }
}

extension $DashBoardViewStateCopyWith on DashBoardViewState {
  /// Returns a callable class that can be used as follows: `instanceOfDashBoardViewState.copyWith(...)` or like so:`instanceOfDashBoardViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$DashBoardViewStateCWProxy get copyWith =>
      _$DashBoardViewStateCWProxyImpl(this);
}
