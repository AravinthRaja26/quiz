import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:nikitchem/application/events/dashboard_event.dart';
import 'package:nikitchem/application/events/enquiry_event.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/events/network_event.dart';
import 'package:nikitchem/application/events/profile_event.dart';
import 'package:nikitchem/application/events/scan_coupon_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/banner/banner_response.dart';
import 'package:nikitchem/data/models/user_profile/version_validate.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/bank_transfer/transaction_bank_transfer.repository.dart';
import 'package:nikitchem/data/repository/banner/banner_repository.dart';
import 'package:nikitchem/data/repository/user_profile/user_profile_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import 'dashboard.viewstate.dart';

///
class DashBoardViewModel extends BaseViewModel<DashBoardViewState>
    with EventMixin<AppEvent>, WidgetsBindingObserver {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  String? userName;

  ///
  LocationPermission? permission;

  ///
  DebouncerHelper debouncerHelper = DebouncerHelper();

  ///
  Timer? timer;

  ///
  final BankTransferRepository bankTransferRepository;

  ///
  final GlobalKey<ScaffoldState> key = GlobalKey<ScaffoldState>();

  ///
  final BannerRepository bannerRepository;

  ///
  final UserProfileRepository userProfileRepository =
      injector<UserProfileRepository>();

  ///
  DashBoardViewModel(this.localStorage, this.appNavigation,
      this.bankTransferRepository, this.bannerRepository)
      : super(DashBoardViewState.initial()) {}

  ///
  AppNavigation appNavigation;

  ///
  LocalStorage localStorage;

  ///
  List<String> language = <String>['ml', 'bn', 'hi', 'ta', 'te', 'en'];

  ///
  /// enter to load initial
  ///
  void init(BuildContext context) async {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is NetWorkOnlineEvent) {
        AutoRouter.of(context).maybePop();
      } else if (event is NetWorkOfflineEvent) {
        appNavigation.navigationToNetWorkScreen(context);
      } else if (event is ScanCouponEvent) {
        setBalance();
      } else if (event is ProfileEvent) {
        userName = localStorage.retrieveString(StorageKey.userName);
        setState(state.copyWith(userName: userName));
      } else if (event is LanguageEvent) {
        notifyListeners();
      } else if (event is EnquiryEvent) {
        debouncerHelper.run(() {
          checkAccountBalance(context);
        });
      }
    });

    getBanner(context);

    userName = localStorage.retrieveString(StorageKey.userName);
    setState(state.copyWith(isLoading: true, userName: userName));
    List<ConnectivityResult> connectivityResult =
        await (Connectivity().checkConnectivity());
    if (connectivityResult.contains(ConnectivityResult.none)) {
      appNavigation.navigationToNetWorkScreen(context);
    } else {}
    setBalance();

    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    debugPrint(packageInfo.version);
    debugPrint(packageInfo.appName);
    debugPrint(packageInfo.buildNumber);
    debugPrint(packageInfo.buildSignature);
    debugPrint(packageInfo.packageName);
    debugPrint('${packageInfo.data}');
    checkAccountBalance(context);
    checkPermission();

    customNotifier(context);
  }

  ///
  void checkAccountBalance(BuildContext context) async {
    ApiResult<VersionValidateResponse> result =
        await runApiInSafeZone(() => userProfileRepository.versionValidation());

    if (result.isSucceeded) {
      if (result.data?.data?.status == 'error') {
        confirmationDialog(context,
            showCancelButton: false,
            doneButtonText: LocaleKeys.ok.tr(), onTap: () {
          AutoRouter.of(context).maybePop();
        }, subTitle: result.data?.data?.message);

        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              showCancelButton: false,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              subTitle: localLanguage?.keyYouAreLoggedInAnotherDevice ??
                  LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          },
              title: localLanguage?.keyYouAreLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
        }
      } else {
        if (result.data?.data?.consumer?.accBalance != null) {
          double? accountBalance = double.tryParse(
              result.data?.data?.consumer?.accBalance?.toString() ?? '');
          if (accountBalance != null) {
            localStorage.save(StorageKey.accountBalance, accountBalance);
          }
        }

        bool? isShowWarning =
            localStorage.retrieveBool(StorageKey.isShowKeyWarning);

        if (isShowWarning == null || isShowWarning == false) {
          if (result.data?.data?.isKyc == null ||
              result.data?.data?.isKyc == false) {
            localStorage.save(StorageKey.isShowKeyWarning, true);

            confirmationDialog(
              context,
              showCancelButton: false,
              doneButtonText: LocaleKeys.ok.tr(),
              subTitle: localLanguage?.keyCompleteYourKyc ??
                  LocaleKeys.completeYourKyc.tr(),
              onTap: () {
                AutoRouter.of(context).maybePop();
                AutoRouter.of(context).push(const ProfileScreen());
              },
              title: 'App Permission',
              image: 'assets/images/location_address_cuate.png',
            );
          }
        }

        fireEvent(const ScanCouponEvent());
        notifyListeners();
      }
    } else {
      ApiResult.catchError(result, context);
    }
  }

  ///don`t remove this function
  void customNotifier(BuildContext context) {
    Stream<dynamic>.periodic(const Duration(seconds: 120)).listen((_) {
      ///fetch data
      Future<dynamic>.delayed(const Duration(milliseconds: 500), () async {
        List<ConnectivityResult> connectivityResult =
            await (Connectivity().checkConnectivity());
        if (connectivityResult.contains( ConnectivityResult.none)) {
        } else {
          getBanner(context);
        }
      });
    });
  }

  ////
  void setBalance() {
    setState(state.copyWith(
        accountBalance:
            localStorage.retrieveDouble(StorageKey.accountBalance) ?? 0));
  }

  ///
  bool imageAutoPlay() {
    int temp = state.bannerResponse?.data?.length ?? 0;
    if (temp > 1) {
      return true;
    }
    return false;
  }

  ///
  // void locationPermission() {
  //   confirmationDialog(
  //     context,
  //     doneButtonText: LocaleKeys.allow.tr(),
  //     subTitle: localLanguage?.keyDisabledLocation ??
  //         LocaleKeys.YouHaveDisabledLocationAccessEarlier.tr(),
  //     onTap: () {
  //       AutoRouter.of(context).pop();
  //       openAppSettings();
  //     },
  //     title: 'App Permission',
  //     image: 'assets/images/location_address_cuate.png',
  //   );
  // }

  ///
  void checkPermission() async {
    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      setState(state.copyWith(locationPermission: true));
    } else {
      setState(state.copyWith(locationPermission: false));
    }
  }

  ///
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    checkPermission();
    super.didChangeAppLifecycleState(state);
  }

  ///
  void checkEvent(BuildContext context) {
    fireEvent(const DashboardEvent('Online'));
  }

  ///
  void navigationToScannerScreen(BuildContext context) async {
    fireEvent(const EnquiryEvent());
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      confirmationDialog(
        context,
        showCancelButton: false,
        cancelOnTap: () {
          AutoRouter.of(context).maybePop();
        },
        onTap: () {
          AutoRouter.of(context).maybePop();
          Geolocator.openAppSettings();
        },
        image: AssetImagePath.onlineWorldRafiki,
        subTitle:
            LocaleKeys.locationPermissionIsMandatoryToPerformScanOperation.tr(),
        doneButtonText: LocaleKeys.goToSettings.tr(),
      );
    } else {
      fireEvent(const EnquiryEvent());
      await appNavigation.navigationToScannerScreen(context);
      fireEvent(const EnquiryEvent());
    }
  }

  ///
  void navigationToNotificationScreen(BuildContext context) async {
    fireEvent(const EnquiryEvent());
    await appNavigation.navigationToNotificationScreen(context);
    fireEvent(const EnquiryEvent());
  }

  ///
  void navigationToProfileScreen(BuildContext context) async {
    fireEvent(const EnquiryEvent());
    await appNavigation.navigationToProfileScreen(context);
    fireEvent(const EnquiryEvent());
  }

  ///
  void navigationToBankTransferScreen(BuildContext context) async {
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      permissionAlert(
        context,
        showCancelButton: false,
        cancelOnTap: () {
          AutoRouter.of(context).maybePop();
        },
        onTap: () {
          AutoRouter.of(context).maybePop();
          Geolocator.openAppSettings();
        },
        image: AssetImagePath.onlineWorldRafiki,
        subTitle:
            LocaleKeys.locationPermissionIsMandatoryToPerformScanOperation.tr(),
        doneButtonText: LocaleKeys.goToSettings.tr(),
      );
    } else {
      fireEvent(const EnquiryEvent());
      await appNavigation.navigationToBankTransferScreen(context);
      fireEvent(const EnquiryEvent());
    }
  }

  ///
  void openDefaultBrowser(String url) {
    if (url != '') {
      launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    }
  }

  ///
  void setCurrentIndex(int index) {
    setState(state.copyWith(currentPage: index));
  }

  ///
  void getBanner(BuildContext? context) async {
    ApiResult<BannerResponse?> result =
        await runApiInSafeZone(() => bannerRepository.bannerData());
    if (result.isSucceeded) {
      setState(state.copyWith(bannerResponse: result.data));
    } else {
      ApiResult.catchError(result, context!);
    }
  }
}

///
class DebouncerHelper {
  ///
  final int milliseconds;

  ///
  Timer? _timer;

  ///
  DebouncerHelper({this.milliseconds = 500});

  ///
  void run(Function() action, {Duration? duration}) {
    if (_timer != null) {
      _timer?.cancel();
    }
    _timer = Timer(duration ?? Duration(milliseconds: milliseconds), action);
  }
}
