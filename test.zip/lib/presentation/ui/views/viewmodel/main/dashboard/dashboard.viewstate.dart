import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/banner/banner_response.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'dashboard.viewstate.g.dart';

///
@CopyWith()
class DashBoardViewState extends ViewState {
  ///
  final bool? isLoading;

  ///
  final bool? locationPermission;

  ///
  final String? userName;

  ///
  int? currentPage;

  ///
  double? accountBalance;

  ///
  BannerResponse? bannerResponse;

  ///
  DashBoardViewState(
      {required this.isLoading,
      required this.locationPermission,
      required this.userName,
      required this.currentPage,
      required this.accountBalance,
      this.bannerResponse});

  ///
  /// Named Constructor for initial state
  ///
  DashBoardViewState.initial()
      : isLoading = false,
        userName = '',
        currentPage = 0,
        locationPermission = false,
        accountBalance = 0,
        bannerResponse = BannerResponse();

  ///
  /// Props
  ///
  @override
  List<Object?> get props => <Object?>[
        isLoading,
        userName,
        currentPage,
        locationPermission,
        accountBalance,
        bannerResponse
      ];
}
