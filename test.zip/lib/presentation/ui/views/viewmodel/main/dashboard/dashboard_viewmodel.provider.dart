import 'package:flutter/material.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/repository/bank_transfer/transaction_bank_transfer.repository.dart';
import 'package:nikitchem/data/repository/banner/banner_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/dashboard/dashboard.viewmodel.dart';
import 'package:provider/provider.dart';

///
class DashboardProvider extends StatelessWidget {
  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;

  ///
  const DashboardProvider({super.key, required this.builder, this.child});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<DashBoardViewModel>(
        builder: builder,
        lazy: false,
        child: child,
        create: (BuildContext context) {
          return DashBoardViewModel(
            injector<LocalStorage>(),
            injector<AppNavigation>(),
            injector<BankTransferRepository>(),
            injector<BannerRepository>(),
          )..init(context);
        });
  }
}
