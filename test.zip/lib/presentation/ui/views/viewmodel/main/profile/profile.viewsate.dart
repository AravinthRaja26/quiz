import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/user_profile/city_response.dart';
import 'package:nikitchem/data/models/user_profile/custom_document.dart';
import 'package:nikitchem/data/models/user_profile/get_consumer_by_id.dart';
import 'package:nikitchem/data/models/user_profile/state_response.dart';
import 'package:copy_with_extension/copy_with_extension.dart';

part 'profile.viewsate.g.dart';

///
@CopyWith()
class ProfileViewState extends ViewState {
  ///
  final String userName;

  ///
  final String userMail;

  ///
  final String userPhoneNumber;

  ///
  final int userNameLength;

  ///
  final List<StatesData> states;

  ///
  final StatesData selectedSate;

  ///
  final List<StatesData> searchedList;

  ///
  final ConsumerByIdResponse consumerByIdResponse;

  ///
  final List<CityData> cityList;

  ///
  final List<CityData> citySearchedList;

  ///
  final List<CustomDocument> customDocument;

  ///
  final CityData selectCity;

  ///
  final bool load;

  ///
  const ProfileViewState({
    required this.consumerByIdResponse,
    required this.userName,
    required this.userMail,
    required this.userPhoneNumber,
    required this.load,
    required this.userNameLength,
    required this.states,
    required this.searchedList,
    required this.selectedSate,
    required this.cityList,
    required this.citySearchedList,
    required this.selectCity,
    required this.customDocument,
  });

  ///
  ProfileViewState.initial()
      : userName = '',
        userMail = '',
        userPhoneNumber = '',
        load = false,
        userNameLength = 0,
        states = <StatesData>[],
        searchedList = <StatesData>[],
        selectedSate = const StatesData(),
        citySearchedList = <CityData>[],
        cityList = <CityData>[],
        consumerByIdResponse = const ConsumerByIdResponse(),
        selectCity = const CityData(),
        customDocument = <CustomDocument>[];

  @override
  List<Object?> get props => <Object>[
        userName,
        userMail,
        userPhoneNumber,
        load,
        userNameLength,
        states,
        searchedList,
        selectedSate,
        cityList,
        citySearchedList,
        selectCity,
        consumerByIdResponse,
        customDocument
      ];
}
