import 'dart:async';
import 'dart:io';
import 'package:auto_route/auto_route.dart';
import 'package:dio/dio.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/events/profile_event.dart';
import 'package:nikitchem/application/events/scan_coupon_event.dart';
import 'package:nikitchem/application/events/un_focus_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/enum/document_type.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/user_profile/city_response.dart';
import 'package:nikitchem/data/models/user_profile/custom_document.dart';
import 'package:nikitchem/data/models/user_profile/delete_image_response.dart';
import 'package:nikitchem/data/models/user_profile/get_consumer_by_id.dart';
import 'package:nikitchem/data/models/user_profile/state_response.dart';
import 'package:nikitchem/data/models/user_profile/user_profile.dart';
import 'package:nikitchem/data/models/user_profile/version_validate.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/user_profile/user_profile_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/infrastructure/utils/Rex.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/utils/valitaion.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/main/profile/profile.viewsate.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:string_extensions/string_extensions.dart';

///
class ProfileViewModel extends BaseViewModel<ProfileViewState>
    with EventMixin<AppEvent> {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  AppNavigation appNavigation;

  ///
  LocalStorage localStorage;

  ///
  List<XFile> imageList = <XFile>[];

  ///
  FocusNode userNameFocusNode = FocusNode();

  ///
  FocusNode emailFocusNode = FocusNode();

  ///
  FocusNode phoneFocusNode = FocusNode();

  ///
  TextEditingController userNameController = TextEditingController();

  ///
  GlobalKey<FormState> form = GlobalKey<FormState>();

  ///
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  ///
  TextEditingController emailController = TextEditingController();

  ///
  TextEditingController codeController = TextEditingController();

  ///
  TextEditingController stateController = TextEditingController();

  ///
  TextEditingController cityController = TextEditingController();

  ///
  TextEditingController address1Controller = TextEditingController();

  ///
  TextEditingController address2Controller = TextEditingController();

  ///
  TextEditingController areaController = TextEditingController();

  ///
  TextEditingController pinController = TextEditingController();

  ///
  TextEditingController panController = TextEditingController();

  ///
  UserProfileRepository userProfileRepository;

  ///
  TextEditingController phoneController = TextEditingController();

  ///
  ProfileViewModel(
      this.localStorage, this.userProfileRepository, this.appNavigation)
      : super(ProfileViewState.initial());

  ///
  void init(BuildContext context) async {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is UnFocusEvent) {
        emailFocusNode.unfocus();
        userNameFocusNode.unfocus();
      } else if (event is LanguageEvent) {
        notifyListeners();
      } else if (event is ProfileNameEvent) {
        notifyListeners();
        init(context);
      }
    });

    List<ConnectivityResult> connectivityResult =
        await (Connectivity().checkConnectivity());
    if (connectivityResult.contains(ConnectivityResult.none)) {
      appNavigation.navigationToNetWorkScreen(context);
    }

    await getState(context);
    getConsumerByIdNew();

    String? userName = localStorage.retrieveString(StorageKey.userName);
    String? userEmail = localStorage.retrieveString(StorageKey.userEmail);
    String? userPhoneNumber =
        localStorage.retrieveString(StorageKey.userPhoneNumber);

    userNameController.text = userName.toString().toTitleCase.trim();
    emailController.text = userEmail?.trim() ?? '';
    phoneController.text = userPhoneNumber.toString().trim();
    setState(state.copyWith(
        userName: userName,
        userMail: userEmail,
        userNameLength: 3,
        userPhoneNumber: userPhoneNumber));
  }

  ///
  void checkAccountBalance(BuildContext context) async {
    ApiResult<VersionValidateResponse> result =
        await runApiInSafeZone(() => userProfileRepository.versionValidation());

    if (result.isSucceeded) {
      if (result.data?.data?.status == 'error') {
        confirmationDialog(context,
            showCancelButton: false,
            doneButtonText: LocaleKeys.ok.tr(), onTap: () {
          AutoRouter.of(context).maybePop();
        }, subTitle: result.data?.data?.message);
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              showCancelButton: false,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              subTitle: localLanguage?.keyYouAreLoggedInAnotherDevice ??
                  LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          },
              title: localLanguage?.keyYouAreLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
        }
      } else {
        if (result.data?.data?.consumer?.accBalance != null) {
          double? accountBalance = double.tryParse(
              result.data?.data?.consumer?.accBalance?.toString() ?? '');
          if (accountBalance != null) {
            localStorage.save(StorageKey.accountBalance, accountBalance);
          }
        }

        if (result.data?.data?.isKyc == null ||
            result.data?.data?.isKyc == false) {
          confirmationDialog(context,
              showCancelButton: false,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: true,
              subTitle: /*localLanguage?.keyYouAreLoggedInAnotherDevice ??*/
                  LocaleKeys.KYCIsNotUpdateMessage.tr(), onTap: () {
            AutoRouter.of(context).maybePop();
          },
              title: localLanguage?.keyYouAreLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
        } else {
          updateProfile(context);
        }

        bool? isShowWarning =
            localStorage.retrieveBool(StorageKey.isShowKeyWarning);

        if (isShowWarning == null || isShowWarning == false) {
          if (result.data?.data?.isKyc == null) {
            localStorage.save(StorageKey.isShowKeyWarning, true);
            confirmationDialog(
              context,
              showCancelButton: false,
              doneButtonText: LocaleKeys.ok.tr(),
              subTitle: localLanguage?.keyCompleteYourKyc ??
                  LocaleKeys.completeYourKyc.tr(),
              onTap: () {
                AutoRouter.of(context).maybePop();
                AutoRouter.of(context).push(const ProfileScreen());
              },
              title: 'App Permission',
              image: 'assets/images/location_address_cuate.png',
            );
          }
        }

        fireEvent(const ScanCouponEvent());
        notifyListeners();
      }
    } else {
      ApiResult.catchError(result, context);
    }
  }

  ///
  void showDeleteConfirmDialog(BuildContext context) {
    confirmationDialog(
        subTitle: localLanguage?.keyYouWantDeleteAccount ??
            LocaleKeys.doYouWantDeleteAccount.tr(),
        context,
        cancelButtonText: localLanguage?.keyNo ?? 'NO',
        doneButtonText: localLanguage?.keyYes ?? 'YES', onTap: () {
      AutoRouter.of(context).maybePop();
      deleteAccount(context);
    });
  }

  ///
  void deleteAccount(BuildContext context) async {
    showLoader(context);
    ApiResult<UserProfileResponse> result =
        await runApiInSafeZone(() => userProfileRepository.deleteAccount());
    if (result.isSucceeded) {
      hideLoader(context);
      logOut(context);
    } else {
      ApiResult.catchError(result, context);
    }
  }

  ///
  navigateToHomeScreen(BuildContext context) async {
    await AutoRouter.of(context)
        .pushAndPopUntil(MainScreen(), predicate: (_) => false);
  }

  ///
  void searchTheState({required String searchState}) {
    List<StatesData> searchedData = state.states
        .where((StatesData element) => element.stateName!
            .toLowerCase()
            .contains(searchState.toLowerCase()))
        .toList();
    setState(state.copyWith(searchedList: searchedData));
  }

  ///
  void searchCity({required String searchString}) {
    List<CityData> searchedData = state.cityList
        .where((CityData element) => element.cityName!
            .toLowerCase()
            .contains(searchString.toLowerCase()))
        .toList();
    setState(state.copyWith(citySearchedList: searchedData));
  }

  ///
  void logOut(BuildContext context) {
    localStorage.save(StorageKey.isProfileUpdate, false);
    localStorage.save(StorageKey.isLogin, false);
    localStorage.save(StorageKey.isFinishedTutorial, false);
    localStorage.delete(StorageKey.userName);
    appNavigation.navigationToTutorial(context);
  }

  ///
  void updateProfile(BuildContext context) async {
    String? countryCode = localStorage.retrieveString(StorageKey.countryCode);
    if (countryCode == '+977') {
      updateProfileNepal(context);
    } else {
      if (userNameController.text.trim() == '') {
        AppSnackBar.successSnackBar(context,
            contentMessage: userNameValidation(userNameController.text));
      } else if (panController.text == '') {
        AppSnackBar.successSnackBar(context,
            contentMessage: panNumberValidation(panController.text));
      } else if (panController.text.length != 10 ||
          panController.text.length < 10) {
        AppSnackBar.successSnackBar(context,
            contentMessage: localLanguage?.keyValidPanNumber ??
                'Please enter the valid pan number');
      } else if (emailController.text != '') {
        if (emailValidation(emailController.text) != null) {
          AppSnackBar.successSnackBar(context,
              contentMessage: emailValidation(emailController.text));
        } else {
          setState(state.copyWith(load: true));

          List<MultipartFile> temp = <MultipartFile>[];

          if (state.customDocument.isNotEmpty) {
            for (CustomDocument prop in state.customDocument) {
              if (prop.documentId == null) {
                temp.add(await MultipartFile.fromFile(prop.filePath ?? ''));
              }
            }
          }

          ApiResult<UserProfileResponse> result = await runApiInSafeZone(
              () => userProfileRepository.updateProfile(body: <String, dynamic>{
                    'email': emailController.text,
                    'firstName': userNameController.text,
                    'city': '${state.selectCity.cityCode}',
                    'address1': address1Controller.text,
                    'address2': address2Controller.text,
                    'area': areaController.text,
                    'pincode': pinController.text,
                    'pan': panController.text,
                    'countryCode': getCountryCode(),
                    'state': state.selectedSate.stateCode,
                    'keykjm': localStorage.retrieveString(StorageKey.keykjm),
                  }, file: temp));
          if (result.isSucceeded) {
            localStorage.save(StorageKey.isProfileUpdate, true);
            localStorage.save(StorageKey.isLogin, false);
            localStorage.save(StorageKey.isFinishedTutorial, false);
            fireEvent(const ProfileEvent());
            if (result.data?.status == 'error') {
              String? userName =
                  localStorage.retrieveString(StorageKey.userName);
              String? userEmail =
                  localStorage.retrieveString(StorageKey.userEmail);
              String? userPhoneNumber =
                  localStorage.retrieveString(StorageKey.userPhoneNumber);

              userNameController.text = userName.toString().trim();
              emailController.text = userEmail?.trim() ?? '';
              phoneController.text = userPhoneNumber.toString().trim();

              if (result.data?.consumerDetail?.errorMessage ==
                  'Unauthorized Login') {
                confirmationDialog(context,
                    doneButtonText: LocaleKeys.ok.tr(),
                    barrierDismissible: false,
                    isBackButton: false,
                    showCancelButton: false,
                    subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(),
                    onTap: () {
                  AutoRouter.of(context).maybePop();
                  /*   AutoRouter.of(context).pushAndPopUntil(const LoginScreen(),
                    predicate: (_) => false);*/
                }, title: LocaleKeys.YourAreLoggedOut.tr());
              } else {
                AppSnackBar.failureSnackBar(context,
                    contentMessage: result.data?.consumerDetail?.errorMessage);
              }
            } else {
              getConsumerByIdNew();
              localStorage.save(StorageKey.userName, userNameController.text);
              if (emailController.text != '') {
                localStorage.save(StorageKey.userEmail, emailController.text);
              }
              AppSnackBar.successSnackBar(context,
                  contentMessage: 'Updated successfully');
            }

            setState(state.copyWith(load: false));
          } else {
            setState(state.copyWith(load: false));
            ApiResult.catchError(result, context);
          }
        }
      } else if (panController.text == '') {
        AppSnackBar.successSnackBar(context,
            contentMessage: panNumberValidation(panController.text));
      } else if (panController.text.length != 10 ||
          panController.text.length < 10) {
        AppSnackBar.successSnackBar(context,
            contentMessage: localLanguage?.keyValidPanNumber ??
                'Please enter the valid pan number');
      } else if (!Rex.panCard.hasMatch(panController.text)) {
        AppSnackBar.successSnackBar(context,
            contentMessage: localLanguage?.keyValidPanNumber ??
                'Please enter the valid pan number');
      } else if (state.selectedSate.stateName == '') {
        AppSnackBar.successSnackBar(context,
            contentMessage:
                localLanguage?.keySelectState ?? 'Please select the state');
      } else if (state.selectCity.cityName == '') {
        AppSnackBar.successSnackBar(context,
            contentMessage:
                localLanguage?.keySelectCity ?? 'Please select the city');
      } else if (address1Controller.text == '') {
        AppSnackBar.successSnackBar(context,
            contentMessage: localLanguage?.keyEnterTheAddress ??
                'Please enter the address');
      } else if (address1Controller.text == '') {
        AppSnackBar.successSnackBar(context,
            contentMessage: localLanguage?.keyEnterTheAddress ??
                'Please enter the address');
      } else if (pinController.text == '' || pinController.text.length < 6) {
        AppSnackBar.successSnackBar(context,
            contentMessage: localLanguage?.keyValidPincode ??
                'Please enter the valid pinCode');
      } else if (imageList.isEmpty) {
        AppSnackBar.successSnackBar(context,
            contentMessage: localLanguage?.keyChooseTheDocument ??
                'Please choose the document');
      } else {
        setState(state.copyWith(load: true));

        List<MultipartFile> temp = <MultipartFile>[];

        if (state.customDocument.isNotEmpty) {
          for (CustomDocument prop in state.customDocument) {
            if (prop.documentId == null) {
              temp.add(await MultipartFile.fromFile(prop.filePath ?? ''));
            }
          }
        }
        ApiResult<UserProfileResponse> result = await runApiInSafeZone(
            () => userProfileRepository.updateProfile(body: <String, dynamic>{
                  'email': emailController.text,
                  'firstName': userNameController.text,
                  'city': '${state.selectCity.cityCode}',
                  'address1': address1Controller.text,
                  'address2': address2Controller.text,
                  'area': areaController.text,
                  'pincode': pinController.text,
                  'pan': panController.text,
                  'countryCode': getCountryCode(),
                  'state': state.selectedSate.stateCode,
                  'keykjm': localStorage.retrieveString(StorageKey.keykjm),
                }, file: temp));
        if (result.isSucceeded) {
          localStorage.save(StorageKey.isProfileUpdate, true);
          localStorage.save(StorageKey.isLogin, false);
          localStorage.save(StorageKey.isFinishedTutorial, false);
          fireEvent(const ProfileEvent());
          if (result.data?.status == 'error') {
            String? userName = localStorage.retrieveString(StorageKey.userName);
            String? userEmail =
                localStorage.retrieveString(StorageKey.userEmail);
            String? userPhoneNumber =
                localStorage.retrieveString(StorageKey.userPhoneNumber);

            userNameController.text = userName.toString().trim();
            emailController.text = userEmail?.trim() ?? '';
            phoneController.text = userPhoneNumber.toString().trim();

            if (result.data?.consumerDetail?.errorMessage ==
                'Unauthorized Login') {
              confirmationDialog(context,
                  doneButtonText: LocaleKeys.ok.tr(),
                  barrierDismissible: false,
                  isBackButton: false,
                  subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(),
                  onTap: () {
                AutoRouter.of(context).maybePop();
                /*AutoRouter.of(context).pushAndPopUntil(const LoginScreen(),
                  predicate: (_) => false);*/
              }, title: LocaleKeys.YourAreLoggedOut.tr());
            } else {
              AppSnackBar.failureSnackBar(context,
                  contentMessage: result.data?.consumerDetail?.errorMessage);
            }
          } else {
            getConsumerByIdNew();
            localStorage.save(StorageKey.userName, userNameController.text);
            if (emailController.text != '') {
              localStorage.save(StorageKey.userEmail, emailController.text);
            }
            AppSnackBar.successSnackBar(context,
                contentMessage: 'Updated successfully');
          }

          setState(state.copyWith(load: false));
        } else {
          setState(state.copyWith(load: false));
          ApiResult.catchError(result, context);
        }
      }
    }
  }

  void updateProfileNepal(BuildContext context) async {
    String? countryCode = localStorage.retrieveString(StorageKey.countryCode);

    if (userNameController.text.trim() == '') {
      AppSnackBar.successSnackBar(context,
          contentMessage: userNameValidation(userNameController.text));
    } else if (emailController.text != '') {
      if (emailValidation(emailController.text) != null) {
        AppSnackBar.successSnackBar(context,
            contentMessage: emailValidation(emailController.text));
      } else {
        setState(state.copyWith(load: true));

        List<MultipartFile> temp = <MultipartFile>[];

        if (state.customDocument.isNotEmpty) {
          for (CustomDocument prop in state.customDocument) {
            if (prop.documentId == null) {
              temp.add(await MultipartFile.fromFile(prop.filePath ?? ''));
            }
          }
        }

        ApiResult<UserProfileResponse> result = await runApiInSafeZone(
            () => userProfileRepository.updateProfile(body: <String, dynamic>{
                  'email': emailController.text,
                  'firstName': userNameController.text,
                  'city': '${state.selectCity.cityCode}',
                  'address1': address1Controller.text,
                  'address2': address2Controller.text,
                  'area': areaController.text,
                  'pincode': pinController.text,
                  'pan': panController.text,
                  'countryCode': getCountryCode(),
                  'state': state.selectedSate.stateCode,
                  'keykjm': localStorage.retrieveString(StorageKey.keykjm),
                }, file: temp));
        if (result.isSucceeded) {
          localStorage.save(StorageKey.isProfileUpdate, true);
          localStorage.save(StorageKey.isLogin, false);
          localStorage.save(StorageKey.isFinishedTutorial, false);
          fireEvent(const ProfileEvent());
          if (result.data?.status == 'error') {
            String? userName = localStorage.retrieveString(StorageKey.userName);
            String? userEmail =
                localStorage.retrieveString(StorageKey.userEmail);
            String? userPhoneNumber =
                localStorage.retrieveString(StorageKey.userPhoneNumber);

            userNameController.text = userName.toString().trim();
            emailController.text = userEmail?.trim() ?? '';
            phoneController.text = userPhoneNumber.toString().trim();

            if (result.data?.consumerDetail?.errorMessage ==
                'Unauthorized Login') {
              confirmationDialog(context,
                  doneButtonText: LocaleKeys.ok.tr(),
                  barrierDismissible: false,
                  isBackButton: false,
                  showCancelButton: false,
                  subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(),
                  onTap: () {
                AutoRouter.of(context).maybePop();
                /*   AutoRouter.of(context).pushAndPopUntil(const LoginScreen(),
                    predicate: (_) => false);*/
              }, title: LocaleKeys.YourAreLoggedOut.tr());
            } else {
              AppSnackBar.failureSnackBar(context,
                  contentMessage: result.data?.consumerDetail?.errorMessage);
            }
          } else {
            getConsumerByIdNew();
            localStorage.save(StorageKey.userName, userNameController.text);
            if (emailController.text != '') {
              localStorage.save(StorageKey.userEmail, emailController.text);
            }
            AppSnackBar.successSnackBar(context,
                contentMessage: 'Updated successfully');
          }

          setState(state.copyWith(load: false));
        } else {
          setState(state.copyWith(load: false));
          ApiResult.catchError(result, context);
        }
      }
    } else if (state.selectedSate.stateName == '') {
      AppSnackBar.successSnackBar(context,
          contentMessage:
              localLanguage?.keySelectState ?? 'Please select the state');
    } else if (state.selectCity.cityName == '') {
      AppSnackBar.successSnackBar(context,
          contentMessage:
              localLanguage?.keySelectCity ?? 'Please select the city');
    } else if (address1Controller.text == '') {
      AppSnackBar.successSnackBar(context,
          contentMessage:
              localLanguage?.keyEnterTheAddress ?? 'Please enter the address');
    } else if (address1Controller.text == '') {
      AppSnackBar.successSnackBar(context,
          contentMessage:
              localLanguage?.keyEnterTheAddress ?? 'Please enter the address');
    } else if (pinController.text == '' || pinController.text.length < 6) {
      AppSnackBar.successSnackBar(context,
          contentMessage: localLanguage?.keyValidPincode ??
              'Please enter the valid pinCode');
    } else if (imageList.isEmpty) {
      AppSnackBar.successSnackBar(context,
          contentMessage: localLanguage?.keyChooseTheDocument ??
              'Please choose the document');
    } else {
      setState(state.copyWith(load: true));

      List<MultipartFile> temp = <MultipartFile>[];

      if (state.customDocument.isNotEmpty) {
        for (CustomDocument prop in state.customDocument) {
          if (prop.documentId == null) {
            temp.add(await MultipartFile.fromFile(prop.filePath ?? ''));
          }
        }
      }
      ApiResult<UserProfileResponse> result = await runApiInSafeZone(
          () => userProfileRepository.updateProfile(body: <String, dynamic>{
                'email': emailController.text,
                'firstName': userNameController.text,
                'city': '${state.selectCity.cityCode}',
                'address1': address1Controller.text,
                'address2': address2Controller.text,
                'area': areaController.text,
                'pincode': pinController.text,
                'pan': panController.text,
                'countryCode': getCountryCode(),
                'state': state.selectedSate.stateCode,
                'keykjm': localStorage.retrieveString(StorageKey.keykjm),
              }, file: temp));
      if (result.isSucceeded) {
        localStorage.save(StorageKey.isProfileUpdate, true);
        localStorage.save(StorageKey.isLogin, false);
        localStorage.save(StorageKey.isFinishedTutorial, false);
        fireEvent(const ProfileEvent());
        if (result.data?.status == 'error') {
          String? userName = localStorage.retrieveString(StorageKey.userName);
          String? userEmail = localStorage.retrieveString(StorageKey.userEmail);
          String? userPhoneNumber =
              localStorage.retrieveString(StorageKey.userPhoneNumber);

          userNameController.text = userName.toString().trim();
          emailController.text = userEmail?.trim() ?? '';
          phoneController.text = userPhoneNumber.toString().trim();

          if (result.data?.consumerDetail?.errorMessage ==
              'Unauthorized Login') {
            confirmationDialog(context,
                doneButtonText: LocaleKeys.ok.tr(),
                barrierDismissible: false,
                isBackButton: false,
                subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(),
                onTap: () {
              AutoRouter.of(context).maybePop();
              /*AutoRouter.of(context).pushAndPopUntil(const LoginScreen(),
                  predicate: (_) => false);*/
            }, title: LocaleKeys.YourAreLoggedOut.tr());
          } else {
            AppSnackBar.failureSnackBar(context,
                contentMessage: result.data?.consumerDetail?.errorMessage);
          }
        } else {
          getConsumerByIdNew();
          localStorage.save(StorageKey.userName, userNameController.text);
          if (emailController.text != '') {
            localStorage.save(StorageKey.userEmail, emailController.text);
          }
          AppSnackBar.successSnackBar(context,
              contentMessage: 'Updated successfully');
        }

        setState(state.copyWith(load: false));
      } else {
        setState(state.copyWith(load: false));
        ApiResult.catchError(result, context);
      }
    }
  }

  ///else if (countryCode == '+91') {
  Future<void> camera() async {
    try {
      final ImagePicker picker = ImagePicker();

      final XFile? image =
          await picker.pickImage(source: ImageSource.camera, imageQuality: 20);

      if (image != null) {
        List<CustomDocument> temp = state.customDocument
          ..add(CustomDocument(
              filePath: image.path,
              documentId: null,
              customDocumentType: DocumentType.local,
              documentType: null));

        setState(state.copyWith(customDocument: temp));

        imageList.add(image);
      }

      notifyListeners();
      print('--->${image?.path}');
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  ///
  Future<void> gallery() async {
    try {
      final ImagePicker picker = ImagePicker();

      final XFile? image =
          await picker.pickImage(source: ImageSource.gallery, imageQuality: 20);

      if (image != null) {
        List<CustomDocument> temp = state.customDocument
          ..add(CustomDocument(
              filePath: image.path,
              documentId: null,
              customDocumentType: DocumentType.local,
              documentType: null));

        setState(state.copyWith(customDocument: temp));

        imageList.add(image);
      }

      notifyListeners();
      print('--->${image?.path}');
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  ///
  Future<void> getState(BuildContext context) async {
    setState(state.copyWith(load: true));
    ApiResult<StateResponse> result =
        await runApiInSafeZone(() => userProfileRepository.getState());
    if (result.isSucceeded) {
      setState(state.copyWith(
          states: result.data?.state,
          load: false,
          searchedList: result.data?.state));
    } else {
      setState(state.copyWith(load: false));
      ApiResult.catchError(result, context);
    }
  }

  ///
  void getConsumerByIdNew() async {
    ApiResult<ConsumerByIdResponse> result = await runApiInSafeZone(
        () => userProfileRepository.getConsumerByIdNew());

    List<CustomDocument> tempList = <CustomDocument>[];

    if (result.isSucceeded) {
      if (result.data?.consumerDetail?.documents != null &&
          result.data!.consumerDetail!.documents!.isNotEmpty) {
        for (DocumentDetail data in result.data!.consumerDetail!.documents!) {
          tempList.add(CustomDocument(
              documentType: data.documentType,
              customDocumentType: DocumentType.network,
              documentId: data.documentId,
              filePath: data.document));
        }
      }

      setState(state.copyWith(
          consumerByIdResponse: result.data, customDocument: tempList));

      emailController.text = result.data?.consumerDetail?.email ?? '';
      panController.text = result.data?.consumerDetail?.pan ?? '';
      cityController.text = result.data?.consumerDetail?.city.toString() ?? '';
      address1Controller.text = result.data?.consumerDetail?.address1 ?? '';
      address2Controller.text = result.data?.consumerDetail?.address2 ?? '';
      areaController.text = result.data?.consumerDetail?.locality ?? '';
      pinController.text =
          result.data?.consumerDetail?.pincode.toString() ?? '';
      stateController.text =
          result.data?.consumerDetail?.stateName.toString() ?? '';

      cityController.text =
          result.data?.consumerDetail?.cityName.toString() ?? '';

      setState(state.copyWith(
        selectCity: CityData(
          cityCode: result.data?.consumerDetail?.city,
          cityName: result.data?.consumerDetail?.cityName,
        ),
        selectedSate: StatesData(
            stateCode: result.data?.consumerDetail?.state,
            stateName: result.data?.consumerDetail?.stateName),
      ));
    }
  }

  @override
  void dispose() {
    super.dispose();
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    emailFocusNode.unfocus();
    userNameFocusNode.unfocus();
  }

  ///
  String? userNameValidation(String value) {
    return AppValidation.userNameVerification(value);
  }

  ///
  String? panNumberValidation(String value) {
    return AppValidation.panNumberVerification(value);
  }

  ///
  String? emailValidation(String value) {
    return AppValidation.emailVerification(value);
  }

  ///
  String? phoneNumberValidation(String value) {
    return AppValidation.phoneValidation(value);
  }

  ///
  void setUserNameLength({required String value}) {
    setState(state.copyWith(userNameLength: value.length));
  }

  ///
  Future<void> selectState(StatesData data, BuildContext context) async {
    setState(state.copyWith(selectedSate: data, load: true));
    ApiResult<CityResponse> result = await runApiInSafeZone(
        () => userProfileRepository.getCity(stateCode: data.stateCode ?? 1));
    if (result.isSucceeded) {
      setState(state.copyWith(
          cityList: result.data?.state,
          load: false,
          citySearchedList: result.data?.state));
    } else {
      setState(state.copyWith(load: false));
      ApiResult.catchError(result, context);
    }
  }

  ///
  String? getCountryCode() {
    return localStorage.retrieveString(StorageKey.countryCode);
  }

  ///
  Future<void> selectCity(CityData data) async {
    setState(state.copyWith(selectCity: data));
  }

  ///
  Future<void> deleteImage(int documentId, BuildContext context) async {
    ApiResult<DeleteImageResponse> result = await runApiInSafeZone(
        () => userProfileRepository.deleteKycImage(documentId: documentId));

    if (result.isSucceeded) {
      getConsumerByIdNew();
    } else {
      AppSnackBar.failureSnackBar(context, contentMessage: result.data?.state);
    }
    /*if (result.data?.status == 'error') {
      String? userName = localStorage.retrieveString(StorageKey.userName);
      String? userEmail =
      localStorage.retrieveString(StorageKey.userEmail);
      String? userPhoneNumber =
      localStorage.retrieveString(StorageKey.userPhoneNumber);

      userNameController.text = userName.toString().trim();
      emailController.text = userEmail?.trim() ?? '';
      phoneController.text = userPhoneNumber.toString().trim();

      if (result.data?.consumerDetail?.errorMessage ==
          'Unauthorized Login') {
        confirmationDialog(context,
            doneButtonText: LocaleKeys.ok.tr(),
            barrierDismissible: false,
            isBackButton: false,
            subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(),
            onTap: () {
              AutoRouter.of(context).pushAndPopUntil(const LoginScreen(),
                  predicate: (_) => false);
            }, title: LocaleKeys.YourAreLoggedOut.tr());
      } else {
        AppSnackBar.failureSnackBar(context,
            contentMessage: result.data?.consumerDetail?.errorMessage);
      }
    }*/
  }

  ///
  void removeImageLocally({required CustomDocument? deleteDocument}) {
    List<CustomDocument> temp = state.customDocument;

    List<CustomDocument> temp1 = temp
        .where((CustomDocument element) => deleteDocument != element)
        .toList();

    setState(state.copyWith(customDocument: temp1));

    print('===>${temp1.length}');
  }
}
