// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'profile.viewsate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$ProfileViewStateCWProxy {
  ProfileViewState consumerByIdResponse(
      ConsumerByIdResponse consumerByIdResponse);

  ProfileViewState userName(String userName);

  ProfileViewState userMail(String userMail);

  ProfileViewState userPhoneNumber(String userPhoneNumber);

  ProfileViewState load(bool load);

  ProfileViewState userNameLength(int userNameLength);

  ProfileViewState states(List<StatesData> states);

  ProfileViewState searchedList(List<StatesData> searchedList);

  ProfileViewState selectedSate(StatesData selectedSate);

  ProfileViewState cityList(List<CityData> cityList);

  ProfileViewState citySearchedList(List<CityData> citySearchedList);

  ProfileViewState selectCity(CityData selectCity);

  ProfileViewState customDocument(List<CustomDocument> customDocument);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `ProfileViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// ProfileViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  ProfileViewState call({
    ConsumerByIdResponse? consumerByIdResponse,
    String? userName,
    String? userMail,
    String? userPhoneNumber,
    bool? load,
    int? userNameLength,
    List<StatesData>? states,
    List<StatesData>? searchedList,
    StatesData? selectedSate,
    List<CityData>? cityList,
    List<CityData>? citySearchedList,
    CityData? selectCity,
    List<CustomDocument>? customDocument,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfProfileViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfProfileViewState.copyWith.fieldName(...)`
class _$ProfileViewStateCWProxyImpl implements _$ProfileViewStateCWProxy {
  const _$ProfileViewStateCWProxyImpl(this._value);

  final ProfileViewState _value;

  @override
  ProfileViewState consumerByIdResponse(
          ConsumerByIdResponse consumerByIdResponse) =>
      this(consumerByIdResponse: consumerByIdResponse);

  @override
  ProfileViewState userName(String userName) => this(userName: userName);

  @override
  ProfileViewState userMail(String userMail) => this(userMail: userMail);

  @override
  ProfileViewState userPhoneNumber(String userPhoneNumber) =>
      this(userPhoneNumber: userPhoneNumber);

  @override
  ProfileViewState load(bool load) => this(load: load);

  @override
  ProfileViewState userNameLength(int userNameLength) =>
      this(userNameLength: userNameLength);

  @override
  ProfileViewState states(List<StatesData> states) => this(states: states);

  @override
  ProfileViewState searchedList(List<StatesData> searchedList) =>
      this(searchedList: searchedList);

  @override
  ProfileViewState selectedSate(StatesData selectedSate) =>
      this(selectedSate: selectedSate);

  @override
  ProfileViewState cityList(List<CityData> cityList) =>
      this(cityList: cityList);

  @override
  ProfileViewState citySearchedList(List<CityData> citySearchedList) =>
      this(citySearchedList: citySearchedList);

  @override
  ProfileViewState selectCity(CityData selectCity) =>
      this(selectCity: selectCity);

  @override
  ProfileViewState customDocument(List<CustomDocument> customDocument) =>
      this(customDocument: customDocument);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `ProfileViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// ProfileViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  ProfileViewState call({
    Object? consumerByIdResponse = const $CopyWithPlaceholder(),
    Object? userName = const $CopyWithPlaceholder(),
    Object? userMail = const $CopyWithPlaceholder(),
    Object? userPhoneNumber = const $CopyWithPlaceholder(),
    Object? load = const $CopyWithPlaceholder(),
    Object? userNameLength = const $CopyWithPlaceholder(),
    Object? states = const $CopyWithPlaceholder(),
    Object? searchedList = const $CopyWithPlaceholder(),
    Object? selectedSate = const $CopyWithPlaceholder(),
    Object? cityList = const $CopyWithPlaceholder(),
    Object? citySearchedList = const $CopyWithPlaceholder(),
    Object? selectCity = const $CopyWithPlaceholder(),
    Object? customDocument = const $CopyWithPlaceholder(),
  }) {
    return ProfileViewState(
      consumerByIdResponse:
          consumerByIdResponse == const $CopyWithPlaceholder() ||
                  consumerByIdResponse == null
              ? _value.consumerByIdResponse
              // ignore: cast_nullable_to_non_nullable
              : consumerByIdResponse as ConsumerByIdResponse,
      userName: userName == const $CopyWithPlaceholder() || userName == null
          ? _value.userName
          // ignore: cast_nullable_to_non_nullable
          : userName as String,
      userMail: userMail == const $CopyWithPlaceholder() || userMail == null
          ? _value.userMail
          // ignore: cast_nullable_to_non_nullable
          : userMail as String,
      userPhoneNumber: userPhoneNumber == const $CopyWithPlaceholder() ||
              userPhoneNumber == null
          ? _value.userPhoneNumber
          // ignore: cast_nullable_to_non_nullable
          : userPhoneNumber as String,
      load: load == const $CopyWithPlaceholder() || load == null
          ? _value.load
          // ignore: cast_nullable_to_non_nullable
          : load as bool,
      userNameLength: userNameLength == const $CopyWithPlaceholder() ||
              userNameLength == null
          ? _value.userNameLength
          // ignore: cast_nullable_to_non_nullable
          : userNameLength as int,
      states: states == const $CopyWithPlaceholder() || states == null
          ? _value.states
          // ignore: cast_nullable_to_non_nullable
          : states as List<StatesData>,
      searchedList:
          searchedList == const $CopyWithPlaceholder() || searchedList == null
              ? _value.searchedList
              // ignore: cast_nullable_to_non_nullable
              : searchedList as List<StatesData>,
      selectedSate:
          selectedSate == const $CopyWithPlaceholder() || selectedSate == null
              ? _value.selectedSate
              // ignore: cast_nullable_to_non_nullable
              : selectedSate as StatesData,
      cityList: cityList == const $CopyWithPlaceholder() || cityList == null
          ? _value.cityList
          // ignore: cast_nullable_to_non_nullable
          : cityList as List<CityData>,
      citySearchedList: citySearchedList == const $CopyWithPlaceholder() ||
              citySearchedList == null
          ? _value.citySearchedList
          // ignore: cast_nullable_to_non_nullable
          : citySearchedList as List<CityData>,
      selectCity:
          selectCity == const $CopyWithPlaceholder() || selectCity == null
              ? _value.selectCity
              // ignore: cast_nullable_to_non_nullable
              : selectCity as CityData,
      customDocument: customDocument == const $CopyWithPlaceholder() ||
              customDocument == null
          ? _value.customDocument
          // ignore: cast_nullable_to_non_nullable
          : customDocument as List<CustomDocument>,
    );
  }
}

extension $ProfileViewStateCopyWith on ProfileViewState {
  /// Returns a callable class that can be used as follows: `instanceOfProfileViewState.copyWith(...)` or like so:`instanceOfProfileViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$ProfileViewStateCWProxy get copyWith => _$ProfileViewStateCWProxyImpl(this);
}
