// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'passbook_viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$PassbookViewStateCWProxy {
  PassbookViewState load(bool? load);

  PassbookViewState passbookResponse(PassbookResponse? passbookResponse);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `PassbookViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// PassbookViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  PassbookViewState call({
    bool? load,
    PassbookResponse? passbookResponse,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfPassbookViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfPassbookViewState.copyWith.fieldName(...)`
class _$PassbookViewStateCWProxyImpl implements _$PassbookViewStateCWProxy {
  const _$PassbookViewStateCWProxyImpl(this._value);

  final PassbookViewState _value;

  @override
  PassbookViewState load(bool? load) => this(load: load);

  @override
  PassbookViewState passbookResponse(PassbookResponse? passbookResponse) =>
      this(passbookResponse: passbookResponse);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `PassbookViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// PassbookViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  PassbookViewState call({
    Object? load = const $CopyWithPlaceholder(),
    Object? passbookResponse = const $CopyWithPlaceholder(),
  }) {
    return PassbookViewState(
      load == const $CopyWithPlaceholder()
          ? _value.load
          // ignore: cast_nullable_to_non_nullable
          : load as bool?,
      passbookResponse == const $CopyWithPlaceholder()
          ? _value.passbookResponse
          // ignore: cast_nullable_to_non_nullable
          : passbookResponse as PassbookResponse?,
    );
  }
}

extension $PassbookViewStateCopyWith on PassbookViewState {
  /// Returns a callable class that can be used as follows: `instanceOfPassbookViewState.copyWith(...)` or like so:`instanceOfPassbookViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$PassbookViewStateCWProxy get copyWith =>
      _$PassbookViewStateCWProxyImpl(this);
}
