import 'dart:async';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/passbook/passbook_model.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/passbook/passbook_detail_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/passbook/passbook_viewstate.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/material.dart';

///
class PassbookViewModel extends BaseViewModel<PassbookViewState>with EventMixin<AppEvent> {
  ///
  final AppNavigation appNavigation;

  ///
  final PassbookRepository passbookRepository;

  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  final LocalStorage localStorage;

  ///
  PassbookViewModel(
      this.appNavigation, this.localStorage, this.passbookRepository)
      : super(PassbookViewState.initial()){
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  void init(BuildContext context) {
    passbookDetail(context);
  }
  ///
  void navigationToNotificationScreen(BuildContext context) async {
     appNavigation.navigationToNotificationScreen(context);

  }
  ///
  /// Passbook Detail
  ///
  void passbookDetail(BuildContext context,) async {
    setState(state.copyWith(load: true));
    Map<String, dynamic> data = <String, dynamic>{
      'keykjm': localStorage.retrieveString(StorageKey.keykjm),
      'page':0,
      'size':100
    };
    ApiResult<PassbookResponse?> result =
    await runApiInSafeZone(() => passbookRepository.passbookDetail(data));
    if (result.isSucceeded) {
      setState(state.copyWith(passbookResponse:result.data,load: false,));
    }
  }
}
