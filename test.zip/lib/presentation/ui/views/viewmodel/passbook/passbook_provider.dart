import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/repository/passbook/passbook_detail_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/passbook/passbook_detail.viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class PassbookViewModelProvider extends StatelessWidget {
  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;

  ///
  const PassbookViewModelProvider(
      {super.key, required this.builder, this.child});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<PassbookViewModel>(
        builder: builder,
        lazy: false,
        create: (BuildContext context) {
          return PassbookViewModel(
            injector<AppNavigation>(),
            injector<LocalStorage>(),
            injector<PassbookRepository>(),
          )..init(context);
        });
  }
}
