import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/passbook/passbook_model.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'passbook_viewstate.g.dart';

///
@CopyWith()
class PassbookViewState extends ViewState {
  ///
  PassbookResponse? passbookResponse;
  ///
  final bool? load;
  ///
  PassbookViewState(
      this.load,
      this.passbookResponse
      );

  ///
  PassbookViewState.initial()
      :load=false,
        passbookResponse = PassbookResponse();


  @override
  List<Object?> get props => <Object?>[passbookResponse,load];
}
