import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/notification/notification_model.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'notification_viewstate.g.dart';

///
@CopyWith()
class NotificationViewState extends ViewState {
  ///
  NotificationResponse? notificationResponse;
  ///
  final bool? load;
  ///
  NotificationViewState(
    this.notificationResponse,
      this.load
  );

  ///
  NotificationViewState.initial()
      : notificationResponse = NotificationResponse(),load=false;

  @override
  List<Object?> get props => <Object?>[notificationResponse,load];
}
