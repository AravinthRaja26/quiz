import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/notification/notification_model.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/notification/notification.repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/notification/notification_viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/material.dart';

///
class NotificationViewModel extends BaseViewModel<NotificationViewState>with EventMixin<AppEvent> {
  ///
  final AppNavigation appNavigation;

  ///
  final NotificationRepository notificationRepository;

  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  final LocalStorage localStorage;

  ///
  NotificationViewModel(
      this.appNavigation, this.localStorage, this.notificationRepository)
      : super(NotificationViewState.initial()){
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  void init(BuildContext context) {
    getNotificationDetails(context);
  }

  ///
  void getNotificationDetails(BuildContext context) async {
    setState(state.copyWith(load: true));
    ApiResult<NotificationResponse> result = await runApiInSafeZone(
        () => notificationRepository.getNotificationDetail());
    if (result.isSucceeded) {
      setState(state.copyWith(load: false));
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              showCancelButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      } else {
        setState(state.copyWith(notificationResponse: result.data,load: false));
      }
    } else {
      ApiResult.catchError(result, context);
    }
  }
}
