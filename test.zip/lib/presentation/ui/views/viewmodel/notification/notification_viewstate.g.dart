// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification_viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$NotificationViewStateCWProxy {
  NotificationViewState notificationResponse(
      NotificationResponse? notificationResponse);

  NotificationViewState load(bool? load);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `NotificationViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// NotificationViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  NotificationViewState call({
    NotificationResponse? notificationResponse,
    bool? load,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfNotificationViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfNotificationViewState.copyWith.fieldName(...)`
class _$NotificationViewStateCWProxyImpl
    implements _$NotificationViewStateCWProxy {
  const _$NotificationViewStateCWProxyImpl(this._value);

  final NotificationViewState _value;

  @override
  NotificationViewState notificationResponse(
          NotificationResponse? notificationResponse) =>
      this(notificationResponse: notificationResponse);

  @override
  NotificationViewState load(bool? load) => this(load: load);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `NotificationViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// NotificationViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  NotificationViewState call({
    Object? notificationResponse = const $CopyWithPlaceholder(),
    Object? load = const $CopyWithPlaceholder(),
  }) {
    return NotificationViewState(
      notificationResponse == const $CopyWithPlaceholder()
          ? _value.notificationResponse
          // ignore: cast_nullable_to_non_nullable
          : notificationResponse as NotificationResponse?,
      load == const $CopyWithPlaceholder()
          ? _value.load
          // ignore: cast_nullable_to_non_nullable
          : load as bool?,
    );
  }
}

extension $NotificationViewStateCopyWith on NotificationViewState {
  /// Returns a callable class that can be used as follows: `instanceOfNotificationViewState.copyWith(...)` or like so:`instanceOfNotificationViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$NotificationViewStateCWProxy get copyWith =>
      _$NotificationViewStateCWProxyImpl(this);
}
