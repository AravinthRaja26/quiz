// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ticket_list_viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$TicketListViewStateCWProxy {
  TicketListViewState isEnabled(bool? isEnabled);

  TicketListViewState isShimmer(bool? isShimmer);

  TicketListViewState name(String name);

  TicketListViewState ticketPage(TicketEnum? ticketPage);

  TicketListViewState load(bool? load);

  TicketListViewState consumerTicketList(
      ConsumerTicketList? consumerTicketList);

  TicketListViewState filterTicketList(ConsumerTicketList? filterTicketList);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `TicketListViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// TicketListViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  TicketListViewState call({
    bool? isEnabled,
    bool? isShimmer,
    String? name,
    TicketEnum? ticketPage,
    bool? load,
    ConsumerTicketList? consumerTicketList,
    ConsumerTicketList? filterTicketList,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfTicketListViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfTicketListViewState.copyWith.fieldName(...)`
class _$TicketListViewStateCWProxyImpl implements _$TicketListViewStateCWProxy {
  const _$TicketListViewStateCWProxyImpl(this._value);

  final TicketListViewState _value;

  @override
  TicketListViewState isEnabled(bool? isEnabled) => this(isEnabled: isEnabled);

  @override
  TicketListViewState isShimmer(bool? isShimmer) => this(isShimmer: isShimmer);

  @override
  TicketListViewState name(String name) => this(name: name);

  @override
  TicketListViewState ticketPage(TicketEnum? ticketPage) =>
      this(ticketPage: ticketPage);

  @override
  TicketListViewState load(bool? load) => this(load: load);

  @override
  TicketListViewState consumerTicketList(
          ConsumerTicketList? consumerTicketList) =>
      this(consumerTicketList: consumerTicketList);

  @override
  TicketListViewState filterTicketList(ConsumerTicketList? filterTicketList) =>
      this(filterTicketList: filterTicketList);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `TicketListViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// TicketListViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  TicketListViewState call({
    Object? isEnabled = const $CopyWithPlaceholder(),
    Object? isShimmer = const $CopyWithPlaceholder(),
    Object? name = const $CopyWithPlaceholder(),
    Object? ticketPage = const $CopyWithPlaceholder(),
    Object? load = const $CopyWithPlaceholder(),
    Object? consumerTicketList = const $CopyWithPlaceholder(),
    Object? filterTicketList = const $CopyWithPlaceholder(),
  }) {
    return TicketListViewState(
      isEnabled == const $CopyWithPlaceholder()
          ? _value.isEnabled
          // ignore: cast_nullable_to_non_nullable
          : isEnabled as bool?,
      isShimmer == const $CopyWithPlaceholder()
          ? _value.isShimmer
          // ignore: cast_nullable_to_non_nullable
          : isShimmer as bool?,
      name == const $CopyWithPlaceholder() || name == null
          ? _value.name
          // ignore: cast_nullable_to_non_nullable
          : name as String,
      ticketPage == const $CopyWithPlaceholder()
          ? _value.ticketPage
          // ignore: cast_nullable_to_non_nullable
          : ticketPage as TicketEnum?,
      load == const $CopyWithPlaceholder()
          ? _value.load
          // ignore: cast_nullable_to_non_nullable
          : load as bool?,
      consumerTicketList == const $CopyWithPlaceholder()
          ? _value.consumerTicketList
          // ignore: cast_nullable_to_non_nullable
          : consumerTicketList as ConsumerTicketList?,
      filterTicketList == const $CopyWithPlaceholder()
          ? _value.filterTicketList
          // ignore: cast_nullable_to_non_nullable
          : filterTicketList as ConsumerTicketList?,
    );
  }
}

extension $TicketListViewStateCopyWith on TicketListViewState {
  /// Returns a callable class that can be used as follows: `instanceOfTicketListViewState.copyWith(...)` or like so:`instanceOfTicketListViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$TicketListViewStateCWProxy get copyWith =>
      _$TicketListViewStateCWProxyImpl(this);
}
