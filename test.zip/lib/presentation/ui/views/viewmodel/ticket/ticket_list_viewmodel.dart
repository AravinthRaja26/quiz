import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/enum/ticket_enum.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/contact_us/contact_us_response.dart';
import 'package:nikitchem/data/models/ticket/consumer_ticket_list.model.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/ticket/ticket.reository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/ticket/ticket_list_viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';

///
class TicketListViewModel extends BaseViewModel<TicketListViewState>
    with EventMixin<AppEvent> {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  TicketRepository ticketRepository;

  ///
  ConsumerTicketList? filterTicketList;

  ///
  TextEditingController commentController = TextEditingController();

  ///
  LocalStorage localStorage = injector<LocalStorage>();

  ///
  AppNavigation appNavigation;

  ///
  String? ticketStatus;

  ///
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  ///
  TicketListViewModel(this.appNavigation, this.ticketRepository)
      : super(TicketListViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        notifyListeners();
      }
    });
  }

  ///
  void init(BuildContext context) {
    consumerTicketList(context);
  }

  ///
  void navigateToTicketDetailScreen(
      {required BuildContext context, required String? ticketId}) {
    appNavigation.navigationToTicketDetailScreen(context, ticketId ?? '');
  }

  ///
  void currentTransaction(
      TicketEnum transactionData, String? filterText, BuildContext context) {
    setState(state.copyWith(ticketPage: transactionData));
    ticketStatus = filterText;
    consumerTicketList(context, progressStatus: filterText);
  }

  ///
  /// View Ticket List
  ///
  void consumerTicketList(BuildContext context,
      {String? progressStatus}) async {
    setState(state.copyWith(load: true));
    Map<String, dynamic> data = <String, dynamic>{
      'keykjm': localStorage.retrieveString(StorageKey.keykjm),
    };
    ApiResult<ConsumerTicketList?> result =
        await runApiInSafeZone(() => ticketRepository.consumerTicketList(data));

    if (result.isSucceeded) {
      setState(state.copyWith(load: false));
      if (result.data?.status == 'error') {
        if (result.data?.data?[0].errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?[0].errorMessage);
        }
      } else {
        if (progressStatus != null) {
          List<TicketListData> temp = <TicketListData>[];
          result.data?.data?.forEach((TicketListData element) {
            if (element.ticketStatus == progressStatus) {
              temp.add(element);
            }
          });
          state.consumerTicketList?.data = temp;
          ConsumerTicketList? temp2 = state.consumerTicketList;
          setState(state.copyWith(consumerTicketList: temp2, load: false));
        } else {
          setState(
              state.copyWith(consumerTicketList: result.data, load: false));
        }

        filterTicketList = result.data;
      }
    }
  }

  ///
  String createTicketFormate(int createdDate) {
    DateTime tsdate = DateTime.fromMillisecondsSinceEpoch(createdDate);
    String datetime = 'created on ${DateFormat('dd MMM yyy').format(tsdate)}';
    return datetime;
  }

  ///
  /// create Ticket List
  ///
  void createTicket(BuildContext context) async {
    setState(state.copyWith(load: true));
    Map<String, dynamic> data = <String, dynamic>{
      'keykjm': localStorage.retrieveString(StorageKey.keykjm),
      'questionId': <int>[1000],
      'text': commentController.text,
      'formData': [
        <String, String>{
          'network': '',
          'networkCircle': '',
          'amount': '',
          'mobileNumber': '',
          'networkType': ''
        }
      ]
    };
    ApiResult<ContactUsResponse?> result =
        await runApiInSafeZone(() => ticketRepository.createTicket(data));

    if (result.isSucceeded) {
      setState(state.copyWith(load: false));
      consumerTicketList(context, progressStatus: null);
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      } else {

        setState(state.copyWith(ticketPage: TicketEnum.allTicket));
        AutoRouter.of(context).maybePop();
        AutoRouter.of(context).push(ApiSuccessScreen(
          onTap: () {
            AutoRouter.of(context).maybePop();
          },
          image: 'assets/images/group_322.png',
          title: localLanguage?.keyCreated ?? 'Created!',
          subTitle:
              localLanguage?.keyTicketDetailSuccessMessage ?? 'Your ticket has been created. Please check the ticket details from Settings > Ticket Details',
        ));
        commentController.clear();
      }
    }
  }
}
