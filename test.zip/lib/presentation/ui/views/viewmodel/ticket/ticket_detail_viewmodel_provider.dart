import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/repository/ticket/ticket.reository.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/ticket/ticket_detail_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class TicketDetailProvider extends StatelessWidget {
  ///
  /// TicketDetail view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;

  ///
  final String? ticketId;

  ///
  const TicketDetailProvider(
      {super.key, required this.builder, this.child, this.ticketId});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<TicketDetailViewModel>(
        builder: builder,
        lazy: false,

        create: (BuildContext context) {
          return TicketDetailViewModel(
            injector<AppNavigation>(),
            injector<TicketRepository>(),
          )..init(context,ticketId);
        });
  }
}
