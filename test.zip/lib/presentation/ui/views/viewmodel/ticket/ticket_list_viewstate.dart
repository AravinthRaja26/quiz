import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/enum/ticket_enum.dart';
import 'package:nikitchem/data/models/ticket/consumer_ticket_list.model.dart';
import 'package:nikitchem/data/models/ticket/view_ticket_response.model.dart';
import 'package:copy_with_extension/copy_with_extension.dart';

part 'ticket_list_viewstate.g.dart';

///
@CopyWith()
class TicketListViewState extends ViewState {
  ///
  final String name;

  ///
  TicketEnum? ticketPage;

  ///
  final bool? isEnabled;

  ///
  final bool? isShimmer;

  ///
  final bool? load;

  ///
  ConsumerTicketList? consumerTicketList;

  ///
  ConsumerTicketList? filterTicketList;

  ///
  TicketListViewState(
      this.isEnabled,
      this.isShimmer,
      this.name,
      this.ticketPage,
      this.load,
      this.consumerTicketList,
      this.filterTicketList);

  ///
  TicketListViewState.initial()
      : isShimmer = false,
        isEnabled = false,
        load = false,
        name = 'Offline',
        ticketPage = TicketEnum.allTicket,
        consumerTicketList = ConsumerTicketList(),
        filterTicketList = ConsumerTicketList();

  @override
  List<Object?> get props => <Object?>[
        isShimmer,
        isEnabled,
        load,
        name,
        ticketPage,
        consumerTicketList,
        filterTicketList
      ];
}
