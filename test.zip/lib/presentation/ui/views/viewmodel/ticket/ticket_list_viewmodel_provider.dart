import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/repository/ticket/ticket.reository.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/ticket/ticket_list_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class TicketListProvider extends StatelessWidget {
  ///
  /// TicketList view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;

  ///
  const TicketListProvider({super.key, required this.builder, this.child});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<TicketListViewModel>(
        builder: builder,
        lazy: false,
        create: (BuildContext context) {
          return TicketListViewModel(
            injector<AppNavigation>(),
            injector<TicketRepository>(),
          )..init(context);
        });
  }
}
