import 'dart:async';
import 'dart:convert';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/ticket/view_ticket_response.model.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/ticket/ticket.reository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/ticket/ticket_detail_viewstate.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';

///
class TicketDetailViewModel extends BaseViewModel<TicketDetailViewState>
    with EventMixin<AppEvent> {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  TicketRepository ticketRepository;

  ///
  LocalStorage localStorage = injector<LocalStorage>();

  ///
  AppNavigation appNavigation;

  ///
  TicketDetailViewModel(
    this.appNavigation,
    this.ticketRepository,
  ) : super(TicketDetailViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        notifyListeners();
      }
    });
  }

  ///
  void init(BuildContext context, String? ticketId) {
    debugPrint('---------------->$ticketId');
    viewTicketDetail(context, ticketId);
  }

  ///
  String createTicketFormate(int createdDate) {
    DateTime tsdate = DateTime.fromMillisecondsSinceEpoch(createdDate);
    String datetime = DateFormat('dd MMM yyy').format(tsdate);
    return datetime;
  }
  ///
  String updateTicketFormate(int updateDate) {
    DateTime tsdate = DateTime.fromMillisecondsSinceEpoch(updateDate);
    String datetime = DateFormat('dd MMM yyy').format(tsdate);
    return datetime;
  }

  ///
  /// View Ticket Detail
  ///
  void viewTicketDetail(BuildContext context, String? ticketId) async {
    setState(state.copyWith(load: true));
    Map<String, dynamic> data = <String, dynamic>{
      'keykjm': localStorage.retrieveString(StorageKey.keykjm),
      'ticketId': ticketId.toString(),
    };
    ApiResult<ViewTicketResponse?> result =
        await runApiInSafeZone(() => ticketRepository.viewTicketDetail(data));
    if (result.isSucceeded) {
      setState(state.copyWith(load: false));
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              showCancelButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      } else {
        setState(state.copyWith(viewTicketResponse: result.data, load: false));
      }
    }
  }

  ///
  String? decodeDescriptionData(String description) {
    Map<String, dynamic> encodedString = jsonDecode(description);
    TicketDescription user = TicketDescription.fromJson(encodedString);
    return user.message;
  }

/*  ///
  String? resolvedTicket(String resolvedDate) {
    Map<String, dynamic> encodedString = jsonDecode(resolvedDate);
    TicketDescription user = TicketDescription.fromJson(encodedString);
    return user.date;
  }*/
}
