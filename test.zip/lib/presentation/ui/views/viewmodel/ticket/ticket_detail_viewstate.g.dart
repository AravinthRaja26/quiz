// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ticket_detail_viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$TicketDetailViewStateCWProxy {
  TicketDetailViewState isEnabled(bool? isEnabled);

  TicketDetailViewState isShimmer(bool? isShimmer);

  TicketDetailViewState load(bool? load);

  TicketDetailViewState viewTicketResponse(
      ViewTicketResponse? viewTicketResponse);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `TicketDetailViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// TicketDetailViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  TicketDetailViewState call({
    bool? isEnabled,
    bool? isShimmer,
    bool? load,
    ViewTicketResponse? viewTicketResponse,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfTicketDetailViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfTicketDetailViewState.copyWith.fieldName(...)`
class _$TicketDetailViewStateCWProxyImpl
    implements _$TicketDetailViewStateCWProxy {
  const _$TicketDetailViewStateCWProxyImpl(this._value);

  final TicketDetailViewState _value;

  @override
  TicketDetailViewState isEnabled(bool? isEnabled) =>
      this(isEnabled: isEnabled);

  @override
  TicketDetailViewState isShimmer(bool? isShimmer) =>
      this(isShimmer: isShimmer);

  @override
  TicketDetailViewState load(bool? load) => this(load: load);

  @override
  TicketDetailViewState viewTicketResponse(
          ViewTicketResponse? viewTicketResponse) =>
      this(viewTicketResponse: viewTicketResponse);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `TicketDetailViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// TicketDetailViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  TicketDetailViewState call({
    Object? isEnabled = const $CopyWithPlaceholder(),
    Object? isShimmer = const $CopyWithPlaceholder(),
    Object? load = const $CopyWithPlaceholder(),
    Object? viewTicketResponse = const $CopyWithPlaceholder(),
  }) {
    return TicketDetailViewState(
      isEnabled == const $CopyWithPlaceholder()
          ? _value.isEnabled
          // ignore: cast_nullable_to_non_nullable
          : isEnabled as bool?,
      isShimmer == const $CopyWithPlaceholder()
          ? _value.isShimmer
          // ignore: cast_nullable_to_non_nullable
          : isShimmer as bool?,
      load == const $CopyWithPlaceholder()
          ? _value.load
          // ignore: cast_nullable_to_non_nullable
          : load as bool?,
      viewTicketResponse == const $CopyWithPlaceholder()
          ? _value.viewTicketResponse
          // ignore: cast_nullable_to_non_nullable
          : viewTicketResponse as ViewTicketResponse?,
    );
  }
}

extension $TicketDetailViewStateCopyWith on TicketDetailViewState {
  /// Returns a callable class that can be used as follows: `instanceOfTicketDetailViewState.copyWith(...)` or like so:`instanceOfTicketDetailViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$TicketDetailViewStateCWProxy get copyWith =>
      _$TicketDetailViewStateCWProxyImpl(this);
}
