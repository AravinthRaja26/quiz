// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bank_transfer.viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$BankTransferViewStateCWProxy {
  BankTransferViewState isShimmer(bool? isShimmer);

  BankTransferViewState isEnabled(bool? isEnabled);

  BankTransferViewState isLoading(bool? isLoading);

  BankTransferViewState userName(String? userName);

  BankTransferViewState bankTransferResponse(
      BankTransferResponse? bankTransferResponse);

  BankTransferViewState currentPage(int? currentPage);

  BankTransferViewState accountDetailsResponse(
      AccountDetailsResponse accountDetailsResponse);

  BankTransferViewState selectAccountDetail(AccountDetail? selectAccountDetail);

  BankTransferViewState transferAmountContions(bool? transferAmountContions);

  BankTransferViewState isKycUpdated(bool? isKycUpdated);

  BankTransferViewState emptyValidation(bool? emptyValidation);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `BankTransferViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// BankTransferViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  BankTransferViewState call({
    bool? isShimmer,
    bool? isEnabled,
    bool? isLoading,
    String? userName,
    BankTransferResponse? bankTransferResponse,
    int? currentPage,
    AccountDetailsResponse? accountDetailsResponse,
    AccountDetail? selectAccountDetail,
    bool? transferAmountContions,
    bool? isKycUpdated,
    bool? emptyValidation,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfBankTransferViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfBankTransferViewState.copyWith.fieldName(...)`
class _$BankTransferViewStateCWProxyImpl
    implements _$BankTransferViewStateCWProxy {
  const _$BankTransferViewStateCWProxyImpl(this._value);

  final BankTransferViewState _value;

  @override
  BankTransferViewState isShimmer(bool? isShimmer) =>
      this(isShimmer: isShimmer);

  @override
  BankTransferViewState isEnabled(bool? isEnabled) =>
      this(isEnabled: isEnabled);

  @override
  BankTransferViewState isLoading(bool? isLoading) =>
      this(isLoading: isLoading);

  @override
  BankTransferViewState userName(String? userName) => this(userName: userName);

  @override
  BankTransferViewState bankTransferResponse(
          BankTransferResponse? bankTransferResponse) =>
      this(bankTransferResponse: bankTransferResponse);

  @override
  BankTransferViewState currentPage(int? currentPage) =>
      this(currentPage: currentPage);

  @override
  BankTransferViewState accountDetailsResponse(
          AccountDetailsResponse accountDetailsResponse) =>
      this(accountDetailsResponse: accountDetailsResponse);

  @override
  BankTransferViewState selectAccountDetail(
          AccountDetail? selectAccountDetail) =>
      this(selectAccountDetail: selectAccountDetail);

  @override
  BankTransferViewState transferAmountContions(bool? transferAmountContions) =>
      this(transferAmountContions: transferAmountContions);

  @override
  BankTransferViewState isKycUpdated(bool? isKycUpdated) =>
      this(isKycUpdated: isKycUpdated);

  @override
  BankTransferViewState emptyValidation(bool? emptyValidation) =>
      this(emptyValidation: emptyValidation);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `BankTransferViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// BankTransferViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  BankTransferViewState call({
    Object? isShimmer = const $CopyWithPlaceholder(),
    Object? isEnabled = const $CopyWithPlaceholder(),
    Object? isLoading = const $CopyWithPlaceholder(),
    Object? userName = const $CopyWithPlaceholder(),
    Object? bankTransferResponse = const $CopyWithPlaceholder(),
    Object? currentPage = const $CopyWithPlaceholder(),
    Object? accountDetailsResponse = const $CopyWithPlaceholder(),
    Object? selectAccountDetail = const $CopyWithPlaceholder(),
    Object? transferAmountContions = const $CopyWithPlaceholder(),
    Object? isKycUpdated = const $CopyWithPlaceholder(),
    Object? emptyValidation = const $CopyWithPlaceholder(),
  }) {
    return BankTransferViewState(
      isShimmer == const $CopyWithPlaceholder()
          ? _value.isShimmer
          // ignore: cast_nullable_to_non_nullable
          : isShimmer as bool?,
      isEnabled == const $CopyWithPlaceholder()
          ? _value.isEnabled
          // ignore: cast_nullable_to_non_nullable
          : isEnabled as bool?,
      isLoading == const $CopyWithPlaceholder()
          ? _value.isLoading
          // ignore: cast_nullable_to_non_nullable
          : isLoading as bool?,
      userName == const $CopyWithPlaceholder()
          ? _value.userName
          // ignore: cast_nullable_to_non_nullable
          : userName as String?,
      bankTransferResponse == const $CopyWithPlaceholder()
          ? _value.bankTransferResponse
          // ignore: cast_nullable_to_non_nullable
          : bankTransferResponse as BankTransferResponse?,
      currentPage == const $CopyWithPlaceholder()
          ? _value.currentPage
          // ignore: cast_nullable_to_non_nullable
          : currentPage as int?,
      accountDetailsResponse == const $CopyWithPlaceholder() ||
              accountDetailsResponse == null
          ? _value.accountDetailsResponse
          // ignore: cast_nullable_to_non_nullable
          : accountDetailsResponse as AccountDetailsResponse,
      selectAccountDetail == const $CopyWithPlaceholder()
          ? _value.selectAccountDetail
          // ignore: cast_nullable_to_non_nullable
          : selectAccountDetail as AccountDetail?,
      transferAmountContions == const $CopyWithPlaceholder()
          ? _value.transferAmountContions
          // ignore: cast_nullable_to_non_nullable
          : transferAmountContions as bool?,
      isKycUpdated == const $CopyWithPlaceholder()
          ? _value.isKycUpdated
          // ignore: cast_nullable_to_non_nullable
          : isKycUpdated as bool?,
      emptyValidation == const $CopyWithPlaceholder()
          ? _value.emptyValidation
          // ignore: cast_nullable_to_non_nullable
          : emptyValidation as bool?,
    );
  }
}

extension $BankTransferViewStateCopyWith on BankTransferViewState {
  /// Returns a callable class that can be used as follows: `instanceOfBankTransferViewState.copyWith(...)` or like so:`instanceOfBankTransferViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$BankTransferViewStateCWProxy get copyWith =>
      _$BankTransferViewStateCWProxyImpl(this);
}
