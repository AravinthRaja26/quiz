import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/account/account_details_response.model.dart';
import 'package:nikitchem/data/models/bank_trnasfer/bank_transfer.response.dart';
import 'package:copy_with_extension/copy_with_extension.dart';

part 'bank_transfer.viewstate.g.dart';

///
@CopyWith()
class BankTransferViewState extends ViewState {
  ///
  final bool? isLoading;

  ///
  final bool? isShimmer;

  ///
  final bool? isEnabled;

  ///
  final bool? isKycUpdated;

  ///
  final AccountDetailsResponse accountDetailsResponse;

  ///
  final AccountDetail? selectAccountDetail;

  ///
  BankTransferResponse? bankTransferResponse;

  ///
  final String? userName;

  ///
  int? currentPage;

  ///
  bool? transferAmountContions;

  ///
  bool? emptyValidation;

  ///
  BankTransferViewState(
      this.isShimmer,
      this.isEnabled,
      this.isLoading,
      this.userName,
      this.bankTransferResponse,
      this.currentPage,
      this.accountDetailsResponse,
      this.selectAccountDetail,
      this.transferAmountContions,
      this.isKycUpdated,
      this.emptyValidation);

  ///
  /// Named Constructor for initial state
  ///
  BankTransferViewState.initial()
      : isLoading = false,
        isShimmer = false,
        isEnabled = false,
        userName = '',
        bankTransferResponse = BankTransferResponse(),
        currentPage = 0,
        accountDetailsResponse = AccountDetailsResponse(),
        selectAccountDetail = null,
        transferAmountContions = false,
        isKycUpdated = false,
        emptyValidation = false;

  ///
  /// Props
  ///
  @override
  List<Object?> get props => <Object?>[
        isLoading,
        isShimmer,
        isEnabled,
        userName,
        currentPage,
        bankTransferResponse,
        accountDetailsResponse,
        selectAccountDetail,
        transferAmountContions,
        isKycUpdated,
        emptyValidation
      ];
}
