import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/repository/account/account_details.repository.dart';
import 'package:nikitchem/data/repository/account/ifsc_repository.dart';
import 'package:nikitchem/data/repository/bank_transfer/transaction_bank_transfer.repository.dart';
import 'package:nikitchem/data/repository/user_profile/user_profile_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/bank_transfer/bank_transfer.viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class BankTransferProvider extends StatelessWidget {
  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;

  ///
  const BankTransferProvider({super.key, required this.builder, this.child});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<BankTransferViewModel>(
        builder: builder,
        lazy: false,
        child: child,
        create: (BuildContext context) {
          return BankTransferViewModel(
            injector<LocalStorage>(),
            injector<AppNavigation>(),
            injector<BankTransferRepository>(),
            injector<AccountDetailsRepository>(),
            injector<UserProfileRepository>(),
            injector<IfscRepository>()
          )..init(context);
        });
  }
}
