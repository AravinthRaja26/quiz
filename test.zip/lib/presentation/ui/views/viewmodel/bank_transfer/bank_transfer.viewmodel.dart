import 'dart:async';
import 'dart:io';
import 'package:auto_route/auto_route.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:nikitchem/application/events/enquiry_event.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/application/events/scan_coupon_event.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/account/account_details_request.model.dart';
import 'package:nikitchem/data/models/account/account_details_response.model.dart';
import 'package:nikitchem/data/models/account/ifsc_reponse.dart';
import 'package:nikitchem/data/models/bank_trnasfer/bank_transfer.response.dart';
import 'package:nikitchem/data/models/bank_trnasfer/bank_transfer_request.model.dart';
import 'package:nikitchem/data/models/bank_trnasfer/dealer_validate_reponse.dart';
import 'package:nikitchem/data/models/user_profile/version_validate.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/account/account_details.repository.dart';
import 'package:nikitchem/data/repository/account/ifsc_repository.dart';
import 'package:nikitchem/data/repository/bank_transfer/transaction_bank_transfer.repository.dart';
import 'package:nikitchem/data/repository/user_profile/user_profile_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/firebase_options.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/infrastructure/utils/app.text.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_bottom_sheet.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/utils/app_navigation.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/bank_transfer/bank_transfer.viewstate.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:event_bus_plus/event_bus_plus.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:retrofit/retrofit.dart';
import 'package:string_extensions/string_extensions.dart';

///
class BankTransferViewModel extends BaseViewModel<BankTransferViewState>
    with EventMixin<AppEvent> {
  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  final BankTransferRepository bankTransferRepository;

  ///
  final UserProfileRepository userProfileRepository;

  ///
  final AccountDetailsRepository accountDetailsRepository;

  ///
  final IfscRepository ifscRepository;

  ///
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  ///
  String selectedCategory = '';

  ///
  TextEditingController otpController = TextEditingController();

  ///
  // TextEditingController amountController = TextEditingController();
  ///
  TextEditingController mobileController = TextEditingController();

  ///
  TextEditingController pointController = TextEditingController();

  ///
  TextEditingController remarkController = TextEditingController();

  ///
  TextEditingController accountHolderController = TextEditingController();

  ///
  TextEditingController accountNoController = TextEditingController();

  ///
  TextEditingController reAccountNoController = TextEditingController();

  ///
  TextEditingController ifscController = TextEditingController();

  ///
  TextEditingController bankNameController = TextEditingController();

  ///
  TextEditingController currencyController = TextEditingController();

  ///
  TextEditingController branchController = TextEditingController();

  ///
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  ///
  GlobalKey<FormState> otpFormKey = GlobalKey<FormState>();

  ///
  FocusNode pointFocusNode = FocusNode();

  ///
  FocusNode mobileFocusNode = FocusNode();

  ///
  BankTransferViewModel(
      this.localStorage,
      this.appNavigation,
      this.bankTransferRepository,
      this.accountDetailsRepository,
      this.userProfileRepository,
      this.ifscRepository)
      : super(BankTransferViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  AppNavigation appNavigation;

  ///
  LocalStorage localStorage;

  ///
  /// enter to load initial
  ///
  void init(BuildContext context) async {
    warningDialog(context);
    // getBankAccount();
    checkAccountBalance(context);
  }

  ///
  String formNum(String s) {
    return NumberFormat.decimalPattern().format(
      int.parse(s),
    );
  }

  Future<bool> _determinePosition2(BuildContext context) async {
    bool serviceEnabled;
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      hideLoader(context);
      locationDialogWithoutImage(context, onTap: () async {
        await AutoRouter.of(context).maybePop();
        serviceEnabled = await Geolocator.openLocationSettings();
      },
          doneButtonText: localLanguage?.keyOk?.toUpperCase() ?? 'OK',
          subTitle: localLanguage?.keyToTransferTheAmount ??
              'To transfer the amount, please ensure that your location is turned on',
          barrierDismissible: false,
          cancelButtonText: 'CANCEL',
          showCancelButton: true,
          isBackButton: true);
    }
    return serviceEnabled;
  }

  Future<Position> _determinePosition(BuildContext context) async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      hideLoader(context);
      permission = await Geolocator.requestPermission();
    }

    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
    }

    if (permission == LocationPermission.deniedForever) {
      permission = await Geolocator.requestPermission();
      confirmationDialog(
        context,
        doneButtonText: localLanguage?.keyAllow ?? LocaleKeys.allow.tr(),
        subTitle: localLanguage?.keyYouHaveDisabledLocationAccessEarlier ??
            LocaleKeys.YouHaveDisabledLocationAccessEarlier.tr(),
        onTap: () {
          AutoRouter.of(context).maybePop();
          Geolocator.openAppSettings();
        },
        title: localLanguage?.keyAppPermission ?? LocaleKeys.appPermission.tr(),
        image: AssetImagePath.locationPermission,
      );
    }
    return Geolocator.getCurrentPosition();
  }

  String getCountyCode() {
    return localStorage.retrieveString(StorageKey.countryCode) ?? '+91';
  }

  ///
  void checkLocation(BuildContext context) async {
    showLoader(context);
    setState(state.copyWith(isLoading: true));
    bool result =
        await _determinePosition2(context).catchError((dynamic e) async {
      setState(state.copyWith(isLoading: false));
      hideLoader(context);
      // confirmationDialogWithoutImage(context, showCancelButton: false, onTap: () async {
      //   await AutoRouter.of(context).pop();
      // },
      //     doneButtonText: localLanguage?.keyOk?.toUpperCase() ?? 'OK',
      //     subTitle:
      //     e.toString() ?? LocaleKeys.kycWarningDialog,
      //     barrierDismissible: false,
      //     isBackButton: true);
      return e;
    });
    if (result) {
      // bankTransferOtpVerification(context);
      dealerValidateApi(context);
    }
  }

  ///
  void warningDialog(BuildContext context) {
    Future<dynamic>.delayed(const Duration(seconds: 0), () {
      confirmationDialog(context, showCancelButton: false, onTap: () async {
        await AutoRouter.of(context).maybePop();
      },
          doneButtonText: localLanguage?.keyOk?.toUpperCase() ?? 'OK',
          image: 'assets/images/group_358.png',
          subTitle:
              localLanguage?.keyKycWarningDialog ?? LocaleKeys.kycWarningDialog,
          cancelButtonText: localLanguage?.keyNo ?? 'NO',
          barrierDismissible: false,
          isBackButton: true);
    });
  }

  ///
  void checkAccountBalance(BuildContext context) async {
    ApiResult<VersionValidateResponse> result =
        await runApiInSafeZone(() => userProfileRepository.versionValidation());

    if (result.isSucceeded) {
      if (result.data?.data?.status == 'error') {
        confirmationDialog(context,
            showCancelButton: false,
            doneButtonText: LocaleKeys.ok.tr(), onTap: () {
          AutoRouter.of(context).maybePop();
        }, subTitle: result.data?.data?.message);
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              showCancelButton: false,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              subTitle: localLanguage?.keyYouAreLoggedInAnotherDevice ??
                  LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          },
              title: localLanguage?.keyYouAreLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
        }
      } else {
        if (result.data?.data?.consumer?.accBalance != null) {
          double? accountBalance = double.tryParse(
              result.data?.data?.consumer?.accBalance?.toString() ?? '');
          if (accountBalance != null) {
            localStorage.save(StorageKey.accountBalance, accountBalance);
          }
        }

        if (result.data?.data?.isKyc == null ||
            result.data?.data?.isKyc == false) {
          setState(state.copyWith(isKycUpdated: true));
        } else {
          setState(state.copyWith(isKycUpdated: true));
        }

        bool? isShowWarning =
            localStorage.retrieveBool(StorageKey.isShowKeyWarning);

        if (isShowWarning == null || isShowWarning == false) {
          if (result.data?.data?.isKyc == null) {
            localStorage.save(StorageKey.isShowKeyWarning, true);
            confirmationDialog(
              context,
              showCancelButton: false,
              doneButtonText: LocaleKeys.ok.tr(),
              subTitle: localLanguage?.keyCompleteYourKyc ??
                  LocaleKeys.completeYourKyc.tr(),
              onTap: () {
                AutoRouter.of(context).maybePop();
                AutoRouter.of(context).push(const ProfileScreen());
              },
              title: 'App Permission',
              image: 'assets/images/location_address_cuate.png',
            );
          }
        }

        fireEvent(const ScanCouponEvent());
        notifyListeners();
      }
    } else {
      ApiResult.catchError(result, context);
    }
  }

  ///
  void getBankAccount(BuildContext context) async {
    ApiResult<AccountDetailsResponse?> result = await runApiInSafeZone(
        () => accountDetailsRepository.accountDetailConsumer());
    showLoader(context);
    if (result.isSucceeded) {
      showLoader(context);
      if (result.data?.status == 'error') {
        hideLoader(context);
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: false,
              doneButtonText:
                  localLanguage?.keyOk ?? LocaleKeys.ok.tr().toUpperCase(),
              subTitle: localLanguage?.keyYouAreLoggedInAnotherDevice ??
                  LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          },
              title: localLanguage?.keyYouAreLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      } else {
        hideLoader(context);
        setState(state.copyWith(accountDetailsResponse: result.data));
        if (state.accountDetailsResponse.data?.accountDetails?.isEmpty ==
            true) {
          confirmationDialog(context, cancelOnTap: () {
            navigateToHomeScreen(context);
          }, onTap: () async {
            await AutoRouter.of(context).maybePop();
            showModelBottomSheet(
              context,
              accountHolderController,
              accountNoController,
              reAccountNoController,
              ifscController,
              bankNameController,
              branchController,
              ifscOnChanged: (String value) {
                getBranchName();
              },
              onTap: () {
                if (formKey.currentState!.validate()) {
                  checkValidate(context: context);
                }
              },
              cancelOnTap: () {
                navigateToHomeScreen(context);
              },
              key: formKey,
            );
          },
              doneButtonText: localLanguage?.keyOk?.toUpperCase() ?? 'OK',
              image: 'assets/images/group_358.png',
              subTitle: localLanguage
                      ?.keyLooksLikeYouDontHaveAnyBankAccountAdded ??
                  'Looks like you don`t have any bank account added. Please add it to redeem rewards',
              cancelButtonText: localLanguage?.keyNo ?? 'NO',
              barrierDismissible: false,
              isBackButton: true);
        }
      }
    } else {
      hideLoader(context);
      ApiResult.catchError(result, context);
    }
  }

  ///
  void navigateToHomeScreen(BuildContext context) async {
    await AutoRouter.of(context)
        .pushAndPopUntil(MainScreen(), predicate: (_) => false);
  }

  ///
  Future<void> navigateToManageAddress(BuildContext context) async {
    await AutoRouter.of(context).maybePop();
    await AutoRouter.of(context).push(const ManageBankAccountScreen());
    getBankAccount(context);
  }

  ///
  /// change dropdown value
  ///
  void selectDataChanging(String value) {
    selectedCategory = value;
    notifyListeners();
  }

  ///
  Future<void> dealerValidateApi(BuildContext context) async {
    setState(state.copyWith(isLoading: true));
    showLoader(context);
    ApiResult<DealerResponse> result = await runApiInSafeZone(() =>
        bankTransferRepository.dealerValidation(
            points: pointController.text.replaceAll(',', '').toInt(),
            dealerMobile: mobileController.text));
    if (result.isSucceeded) {
      hideLoader(context);
      setState(state.copyWith(isLoading: false));
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          setState(state.copyWith(isLoading: false));
          confirmationDialog(context,
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: false,
              doneButtonText: localLanguage?.keyOk ?? LocaleKeys.ok.tr(),
              subTitle: localLanguage?.keyYouAreLoggedInAnotherDevice ??
                  LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          },
              title: localLanguage?.keyYourLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
        } else if (result.data?.data?.errorCode == '463') {
          setState(state.copyWith(isLoading: false));

          confirmationDialogWithoutImage(context,
              showCancelButton: false,
              barrierDismissible: true,
              isBackButton: true, onTap: () {
            AutoRouter.of(context).maybePop();
          },
              doneButtonText: localLanguage?.keyOk ?? LocaleKeys.ok.tr(),
              subTitle: result.data?.data?.errorMessage,
              title: localLanguage?.keyYourLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
          // AppSnackBar.warningSnackBar(context,
          //     contentMessage: result.data?.data?.errorMessage);
        } else if (result.data?.data?.errorMessage ==
            'Your account is inactive!') {
          confirmationDialog(
            context,
            subTitle: localLanguage?.keyUserInactiveReActive ??
                'Your Account is inactive, Please contact manufacturer.',
            onTap: () {
              AutoRouter.of(context).maybePop();
            },
            showCancelButton: false,
            doneButtonText: localLanguage?.keyOk ?? 'OK',
          );
        } else {
          hideLoader(context);
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      } else {
        hideLoader(context);

        /*if(localStorage.retrieveString(StorageKey.countryCode) == '+91'){
          bankTransferDetail(context);
        }else{*/

        bankTransferOtpVerification(context);
      // }
      }
    } else {
      hideLoader(context);
      setState(state.copyWith(isLoading: false));
      ApiResult.catchError(result, context);
    }
  }

  ///
  /// bank TransferOtp Verification
  ///
  void bankTransferOtpVerification(BuildContext context) async {
    setState(state.copyWith(isLoading: true));
    showLoader(context);

    ApiResult<HttpResponse<dynamic>?> result = await runApiInSafeZone(
        () => bankTransferRepository.bankTransferOtpVerification());
    if (result.isSucceeded) {
      setState(state.copyWith(isLoading: false));
      // bankTransferDetail(context);
      if (result.data?.response.statusMessage == 'error') {
        hideLoader(context);
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          hideLoader(context);
          confirmationDialog(context,
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: false,
              doneButtonText: localLanguage?.keyOk ?? LocaleKeys.ok.tr(),
              subTitle: localLanguage?.keyYouAreLoggedInAnotherDevice ??
                  LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          },
              title: localLanguage?.keyYourLoggedOut ??
                  LocaleKeys.YourAreLoggedOut.tr());
        } else {
          hideLoader(context);
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      } else {
        hideLoader(context);
        otpController.clear();
          otpAlertDialog(context,
            title: localStorage.retrieveString(StorageKey.countryCode) == '+977'
                ? 'Please enter your MPin'
                : localLanguage?.keyEnterVerificationOtp,
            cancelText: localLanguage?.keyCancel,
            confirmText: localLanguage?.keyConfirm,
            onChanged: (String value) {
              if (value.length > 3) {
                setState(state.copyWith(emptyValidation: true));
              } else {
                setState(state.copyWith(emptyValidation: false));
              }
            },
            goSubmit: (bool value) {
              bankTransferDetail(context);
            },
            enable: state.emptyValidation,
            otpController: otpController,
            onTap: () {
              // if(otpFormKey.currentState!.validate()){

              // print('object');
              // setState(state.copyWith(emptyValidation: false));
              // }else{
              //   setState(state.copyWith(emptyValidation: true));
              // }
            });
      }
    } else {
      setState(state.copyWith(isLoading: false));
      ApiResult.catchError(result, context);
    }
  }

  ///
  void clearData() {
    setState(state.copyWith(selectAccountDetail: null));
    pointController.clear();
    remarkController.clear();
  }

  ///
  void enableLoad(String value) {
    if (pointController.text != '' &&
        mobileController.text != '' &&
        value.length == 10 &&
        double.parse(localStorage
                .retrieveDouble(StorageKey.accountBalance)
                .toString()) >=
            double.parse(pointController.text.replaceAll(',', '')) &&
        !pointController.text.startsWith('0')) {
      setState(state.copyWith(isShimmer: true));
    } else {
      setState(state.copyWith(isShimmer: false));
    }

    /* if (int.parse(amountController.text) > 500) {
      setState(state.copyWith(transferAmountContions: true));
    } else {
      setState(state.copyWith(transferAmountContions: false));
    }*/
  }

  ///
  void amountValidate(String value, BuildContext context) {
    print(int.parse(pointController.text.replaceAll(',', '')));
    if (mobileController.text != '' &&
        mobileController.text.length == 10 &&
        pointController.text != '' &&
        double.parse(localStorage
                .retrieveDouble(StorageKey.accountBalance)
                .toString()) >=
            double.parse(pointController.text.replaceAll(',', '')) &&
        !pointController.text.startsWith('0')) {
      setState(state.copyWith(isShimmer: true));
    } else if (mobileController.text.length == 10 &&
        double.parse(localStorage
                .retrieveDouble(StorageKey.accountBalance)
                .toString()) <
            double.parse(pointController.text.replaceAll(',', '')) &&
        !pointController.text.startsWith('0')) {
      confirmationDialogWithoutImage(context, showCancelButton: false,
          onTap: () async {
        await AutoRouter.of(context).maybePop();
      },
          doneButtonText: localLanguage?.keyOk?.toUpperCase() ?? 'OK',
          subTitle: localLanguage?.keyYourRedemptionExceeds ??
              'Your redemption exceeds your wallet balance',
          barrierDismissible: false,
          isBackButton: true);
    } else {
      setState(state.copyWith(isShimmer: false));
    }

    double minimumAmount =
        localStorage.retrieveDouble(StorageKey.accountBalance) ?? 0;
    /* String temp = pointController.text.replaceAll(',', '').toString();
    print('===>$temp');
    if (double.parse(temp) > AppText.minimumBalance) {
      confirmationDialog(context,
          title: 'Warning',
          showCancelButton: false,
          isBackButton: true, onTap: () {
        AutoRouter.of(context).pop();
      },
          doneButtonText: localLanguage?.keyOk?.toUpperCase() ?? 'OK',
          subTitle: localLanguage?.keyTransactionValueMinimum ??
              'Transaction value of more than 1000 is not allowed');
      // AppSnackBar.failureSnackBar(context!,
      //     contentMessage: localLanguage?.keyTransactionValueMinimum ??
      //         'Transaction value of more than 1000 is not allowed');
    }*/
    /*else if (double.parse(temp) > minimumAmount) {
      confirmationDialog(
        context,
        title: 'Warning',
        showCancelButton: false,
        isBackButton: true,
        onTap: () {
          AutoRouter.of(context).pop();
        },
        doneButtonText: localLanguage?.keyOk?.toUpperCase() ?? 'Ok',
        subTitle: localLanguage?.keyTransactionValueMinimum?.replaceAll(
                '500',
                localStorage
                    .retrieveDouble(StorageKey.accountBalance)
                    .toString()) ??
            'Transaction value of more than ${localStorage.retrieveDouble(StorageKey.accountBalance)} is not allowed',
      );
      */ /*AppSnackBar.failureSnackBar(onPressed: () {
        FocusScope.of(context!)
            .requestFocus(amountFocusNode);
      }, context!,
          contentMessage: localLanguage?.keyTransferAmountWalletMessage ??
              'Transfer amount is greater than wallet amount, Please try smaller amount or the exact wallet amount');*/ /*
    }*/
    /*else {
      // setState(state.copyWith(isShimmer: true));
    }*/
  }

  ///
  /// bank TransferDetail
  ///
  void bankTransferDetail(BuildContext context) async {
    IosDeviceInfo? iosDeviceInfo;
    AndroidDeviceInfo? androidDeviceInfo;
    double? latitudeData = localStorage.retrieveDouble(StorageKey.latitude);
    double? longitudeData = localStorage.retrieveDouble(StorageKey.longitude);
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      androidDeviceInfo = await deviceInfo.androidInfo;
    } else {
      iosDeviceInfo = await deviceInfo.iosInfo;
    }

    /// no remove for testing
    iosDeviceInfo?.model;
    iosDeviceInfo?.isPhysicalDevice;
    iosDeviceInfo?.data;
    iosDeviceInfo?.systemVersion;
    iosDeviceInfo?.name;
    iosDeviceInfo?.systemName;

    showLoader(context);
    //  int.parse(pointController.text);

    ApiResult<BankTransferResponse?> result =
        await runApiInSafeZone(() => bankTransferRepository.bankTransferDetail({
              'keykjm': localStorage.retrieveString(StorageKey.keykjm),
              'points': pointController.text.replaceAll(',', '').toInt(),
              'otp': otpController.text,
              'dealerMobile': mobileController.text,
              'countryCode':
                  localStorage.retrieveString(StorageKey.countryCode) ?? '+91',
              'platForm': Platform.isAndroid ? 'Android' : 'Ios'
            }));

    if (result.isSucceeded) {
      hideLoader(context);
      if (result.data?.status == 'error') {
        AutoRouter.of(context).maybePop();
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: false,
              doneButtonText: localLanguage?.keyOk ?? LocaleKeys.ok.tr(),
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else if (result.data?.data?.errorMessage ==
            AppText.approvalSubmittedContent) {
          AutoRouter.of(context).push(TransactionErrorScreen(
            onTap: () {
              AutoRouter.of(context).maybePop();
            },
            image: 'assets/images/approval_submitted.png',
            title: 'Approval Submitted' /*localLanguage?.keyTryAgain*/,
            enteredValue:
                pointController.text /*localLanguage?.keyUnableToProcess*/,
          ));
        }

        else if (result.data?.data?.nepalErrorMessage?.contains('M-Pin is wrong') == true){
          AutoRouter.of(context).push(ApiSuccessScreen(
            onTap: () {
              AutoRouter.of(context).maybePop();
            },
            image: 'assets/images/group_338.png',
            title: 'M-Pin is wrong' /*localLanguage?.keyTryAgain*/,
            subTitle: 'M-Pin is wrong. Please request for new one',
            /*enteredValue:
            pointController.text*/ /*localLanguage?.keyUnableToProcess*/
          ));
          // AppSnackBar.warningSnackBar(context,contentMessage: 'M-Pin is wrong. Please request for new one',);
          // print('--->M-Pin is wrong. Please request for new one');
        }
        else {
          if (localStorage.retrieveString(StorageKey.countryCode) == '+977') {
          } else {
            await AutoRouter.of(context).push(ApiSuccessScreen(
              onTap: () {
                AutoRouter.of(context).maybePop();
              },
              image: 'assets/images/group_338.png',
              title: localLanguage?.keyTryAgain,
              subTitle: localLanguage?.keyUnableToProcess,
            ));
          }
        }
      }
      else {
        otpController.clear();
        clearData();
        AutoRouter.of(context).maybePop();
        final TabsRouter router =
            context.router.root.innerRouterOf(MainScreen.name) as TabsRouter;
        router.setActiveIndex(
            localStorage.retrieveInt(StorageKey.currentPageIndex) ?? 0,
            notify: true);
        fireEvent(const EnquiryEvent());
        AutoRouter.of(context).push(ApiSuccessScreen(
            onTap: () {
              AutoRouter.of(context).maybePop();
            },
            image: 'assets/images/group_337.png',
            title: 'Point transfer successfully',
            subTitle:
                'Sender Name : ${result.data?.data?.senderName}\nReceiver Name : ${result.data?.data?.receiverName}\nPoints : ${result.data?.data?.points}'));

        /*if (result.data?.data?.message == '') {
          AutoRouter.of(context).push(ApiSuccessScreen(
              onTap: () {
                AutoRouter.of(context).pop();
              },
              image: 'assets/images/transfer_success.png',
              title: 'Bank Transfer Submitted',
              subTitle:
                  'Transaction Number: ${result.data?.data?.refNum}\n${result.data?.data?.message}\n\nThe wallet Points transfer to your bank account was initiated successfully. It may take sometime to reflect into your account.'));
        } else if (result.data?.data?.message == '') {
          confirmationDialog(context, doneButtonText: localLanguage?.keyOk,subTitle: 'Wallet transfer equal to Rupees 500 or above the value requires approval from the manufacturer and approval request has been submitted successfully.\n\nOn approval you will be credited with the claimed value of<dynamic value>, if declined please contact manufacturer via WhatsApp help.');
        }*/
        setState(state.copyWith(
            bankTransferResponse: result.data, isShimmer: false));
      }
    } else {
      hideLoader(context);
      ApiResult.catchError(result, context);
    }
  }

  ///
  void checkWalletBalance(BuildContext context) async {
    ApiResult<VersionValidateResponse> result =
        await runApiInSafeZone(() => userProfileRepository.versionValidation());

    if (result.isSucceeded) {
      if (result.data?.data?.status == 'error') {
        confirmationDialog(context,
            showCancelButton: false,
            doneButtonText: LocaleKeys.ok.tr(), onTap: () {
          AutoRouter.of(context).maybePop();
        }, subTitle: result.data?.data?.message);
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              showCancelButton: false,
              doneButtonText: LocaleKeys.ok.tr(),
              barrierDismissible: false,
              isBackButton: false,
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        }
      } else {
        fireEvent(const ScanCouponEvent());
        dynamic accountBalance = result.data?.data?.consumer?.accBalance;
        if (accountBalance != null) {
          if (accountBalance is String) {
            localStorage.save(
                StorageKey.accountBalance, double.parse(accountBalance));
          } else if (accountBalance is int) {
            localStorage.save(StorageKey.accountBalance,
                double.parse(accountBalance.toString()));
          }
        }
      }
    } else {
      ApiResult.catchError(result, context);
    }
  }

  ///
  void checkValidate({required BuildContext context}) {
    accountDetailsSave(context);
  }

  ///
  void getBranchName() async {
    if (ifscController.text.length == 11) {
      ApiResult<IfscResponse> result = await runApiInSafeZone(
          () => ifscRepository.fetchIfsc(ifscController.text));

      if (result.isSucceeded) {
        bankNameController.text = result.data?.bank ?? '';
        branchController.text = result.data?.branch ?? '';
      }
    }
  }

  ///
  ///accountDetailSave
  ///
  void accountDetailsSave(BuildContext context) async {
    showLoader(context);
    ApiResult<AccountDetailsResponse> result = await runApiInSafeZone(() =>
        accountDetailsRepository.accountDetailSave(AccountDetailsRequest(
                keykjm: localStorage.retrieveString(StorageKey.keykjm),
                ifscCode: ifscController.text.trim(),
                accId: 0,
                accHolderName: accountHolderController.text.trim(),
                accNo: accountNoController.text.trim(),
                branchName: branchController.text.trim(),
                bankName: bankNameController.text.trim())
            .toJson()));
    if (result.isSucceeded) {
      hideLoader(context);
      AutoRouter.of(context).maybePop();
      if (result.data?.status == 'error') {
        if (result.data?.data?.errorMessage == 'Unauthorized Login') {
          confirmationDialog(context,
              showCancelButton: false,
              barrierDismissible: false,
              isBackButton: false,
              doneButtonText: LocaleKeys.ok.tr().toUpperCase(),
              subTitle: LocaleKeys.youAreLoggedInAnotherDevice.tr(), onTap: () {
            AutoRouter.of(context)
                .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
          }, title: LocaleKeys.YourAreLoggedOut.tr());
        } else {
          AppSnackBar.failureSnackBar(context,
              contentMessage: result.data?.data?.errorMessage);
        }
      }
      if (result.data?.data?.message == 'Account Number is Already Exist') {
        AppSnackBar.warningSnackBar(context,
            contentMessage: localLanguage?.keyAccountNumberAlreadyExist ??
                LocaleKeys.accountNumberAlreadyExist.tr());
      } else {
        await navigateToManageAddress(context);
        clearTextField();
      }
      getBankAccount(context);
    } else {
      hideLoader(context);
      ApiResult.catchError(result, context);
    }
  }

  ///
  void clearTextField() {
    accountHolderController.clear();
    accountNoController.clear();
    reAccountNoController.clear();
    ifscController.clear();
    bankNameController.clear();
    branchController.clear();
  }

  ///
  void selectName(AccountDetail? accountDetail) {
    setState(state.copyWith(selectAccountDetail: accountDetail));
  }
}
