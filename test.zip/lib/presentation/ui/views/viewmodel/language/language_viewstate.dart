import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/models/language_model/language_list_model.dart';
import 'package:copy_with_extension/copy_with_extension.dart';
part 'language_viewstate.g.dart';

///
@CopyWith()
class LanguageViewState extends ViewState {
  ///
  final String selectedLanguage;

  ///
  final LanguageListResponse languages;

  ///
  final bool buttonLoad;

  ///
  final bool screenLoad;

  ///
  final bool buttonEnable;

  ///
  const LanguageViewState(
      {required this.selectedLanguage,
      required this.languages,
      required this.buttonLoad,
      required this.buttonEnable,
      required this.screenLoad});

  ///
  LanguageViewState.initial()
      : selectedLanguage = '',
        buttonLoad = false,
        buttonEnable = false,
        screenLoad = false,
        languages = LanguageListResponse();

  @override
  List<Object?> get props => <Object>[
        selectedLanguage,
        languages,
        buttonLoad,
        buttonEnable,
        screenLoad
      ];
}
