import 'dart:async';
import 'dart:io';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/language_model/language_list_model.dart';
import 'package:nikitchem/data/models/language_model/local_language.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/language/language_repository.dart';
import 'package:nikitchem/data/repository/push_notification/push_notification_repository.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/language/language_viewstate.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/material.dart';

///
class LanguageViewModel extends BaseViewModel<LanguageViewState>
    with EventMixin<AppEvent> {
  ///
  GlobalKey<ScaffoldState> key = GlobalKey<ScaffoldState>();

  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  LanguageRepository languageRepository = injector<LanguageRepository>();

  ///
  PushNotificationRepository pushNotificationRepository =
      injector<PushNotificationRepository>();

  ///
  LocalStorage localStorage = injector<LocalStorage>();


  ///
  LanguageViewModel() : super(LanguageViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        setState(state.copyWith());
        notifyListeners();
      }
    });
  }

  ///
  void selectLanguage({String? language}) {
    setState(state.copyWith(selectedLanguage: language, buttonEnable: true));
  }

  ///
  init(BuildContext context) {
    setState(state.copyWith(
        selectedLanguage:
            localStorage.retrieveString(StorageKey.selectLanguage) ?? 'en'));
    getLanguageList(context);
  }

  ///
  getLanguageList(BuildContext context) async {
    setState(state.copyWith(screenLoad: true));
    ApiResult<LanguageListResponse> result =
        await runApiInSafeZone(() => languageRepository.getLanguageList());
    if (result.isSucceeded) {
      setState(state.copyWith(languages: result.data, screenLoad: false));
    } else {
      setState(state.copyWith(screenLoad: false));
      ApiResult.catchError(result, context);
    }
  }

  ///
  setLanguage(BuildContext context) async {
    await localStorage.save(StorageKey.selectLanguage, state.selectedLanguage);
    if (localStorage.retrieveString(StorageKey.userPhoneNumber) != null) {
      await sendNotification(
          localStorage.retrieveString(StorageKey.fcmToken).toString());
    }
    await getLanguage(context);
    AutoRouter.of(context).maybePop();
  }

  ///
  /// sendNotification
  ///
  Future<void> sendNotification(String fcmToken) async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    IosDeviceInfo? iosDeviceInfo;
    AndroidDeviceInfo? androidDeviceInfo;
    if (Platform.isAndroid) {
      androidDeviceInfo = await deviceInfo.androidInfo;
    } else {
      iosDeviceInfo = await deviceInfo.iosInfo;
    }

    String? id = Platform.isAndroid
        ? androidDeviceInfo?.id
        : iosDeviceInfo?.identifierForVendor;

    await runApiInSafeZone(() =>
        pushNotificationRepository.sendPushNotification(id ?? '', fcmToken));
  }

  ///
  Future<void> getLanguage(BuildContext context) async {
    showLoader(context);

    ApiResult<LanguageResponse> result = await runApiInSafeZone(() =>
        languageRepository.getLanguage(
            language: localStorage.retrieveString(StorageKey.selectLanguage) ??
                'en'));
    if (result.isSucceeded) {
      localLanguage = result.data?.language;
      hideLoader(context);
      fireEvent(const LanguageEvent());
    } else {
      hideLoader(context);
      ApiResult.catchError(result, context);
    }
  }
}
