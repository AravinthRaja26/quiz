// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'language_viewstate.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$LanguageViewStateCWProxy {
  LanguageViewState selectedLanguage(String selectedLanguage);

  LanguageViewState languages(LanguageListResponse languages);

  LanguageViewState buttonLoad(bool buttonLoad);

  LanguageViewState buttonEnable(bool buttonEnable);

  LanguageViewState screenLoad(bool screenLoad);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `LanguageViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// LanguageViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  LanguageViewState call({
    String? selectedLanguage,
    LanguageListResponse? languages,
    bool? buttonLoad,
    bool? buttonEnable,
    bool? screenLoad,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfLanguageViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfLanguageViewState.copyWith.fieldName(...)`
class _$LanguageViewStateCWProxyImpl implements _$LanguageViewStateCWProxy {
  const _$LanguageViewStateCWProxyImpl(this._value);

  final LanguageViewState _value;

  @override
  LanguageViewState selectedLanguage(String selectedLanguage) =>
      this(selectedLanguage: selectedLanguage);

  @override
  LanguageViewState languages(LanguageListResponse languages) =>
      this(languages: languages);

  @override
  LanguageViewState buttonLoad(bool buttonLoad) => this(buttonLoad: buttonLoad);

  @override
  LanguageViewState buttonEnable(bool buttonEnable) =>
      this(buttonEnable: buttonEnable);

  @override
  LanguageViewState screenLoad(bool screenLoad) => this(screenLoad: screenLoad);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `LanguageViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// LanguageViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  LanguageViewState call({
    Object? selectedLanguage = const $CopyWithPlaceholder(),
    Object? languages = const $CopyWithPlaceholder(),
    Object? buttonLoad = const $CopyWithPlaceholder(),
    Object? buttonEnable = const $CopyWithPlaceholder(),
    Object? screenLoad = const $CopyWithPlaceholder(),
  }) {
    return LanguageViewState(
      selectedLanguage: selectedLanguage == const $CopyWithPlaceholder() ||
              selectedLanguage == null
          ? _value.selectedLanguage
          // ignore: cast_nullable_to_non_nullable
          : selectedLanguage as String,
      languages: languages == const $CopyWithPlaceholder() || languages == null
          ? _value.languages
          // ignore: cast_nullable_to_non_nullable
          : languages as LanguageListResponse,
      buttonLoad:
          buttonLoad == const $CopyWithPlaceholder() || buttonLoad == null
              ? _value.buttonLoad
              // ignore: cast_nullable_to_non_nullable
              : buttonLoad as bool,
      buttonEnable:
          buttonEnable == const $CopyWithPlaceholder() || buttonEnable == null
              ? _value.buttonEnable
              // ignore: cast_nullable_to_non_nullable
              : buttonEnable as bool,
      screenLoad:
          screenLoad == const $CopyWithPlaceholder() || screenLoad == null
              ? _value.screenLoad
              // ignore: cast_nullable_to_non_nullable
              : screenLoad as bool,
    );
  }
}

extension $LanguageViewStateCopyWith on LanguageViewState {
  /// Returns a callable class that can be used as follows: `instanceOfLanguageViewState.copyWith(...)` or like so:`instanceOfLanguageViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$LanguageViewStateCWProxy get copyWith =>
      _$LanguageViewStateCWProxyImpl(this);
}
