

import 'package:nikitchem/presentation/ui/views/viewmodel/language/language_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

///
class LanguageViewModelProvider extends StatelessWidget {

  ///
  /// provider view builder
  ///
  final Widget Function(BuildContext context, Widget? child) builder;

  ///
  final Widget? child;
  ///
  const LanguageViewModelProvider({super.key, required this.builder, this.child});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<LanguageViewModel>(
        builder: builder,
        lazy: false,
        create: (BuildContext context){
          return LanguageViewModel()..init(context);
        });
  }
}
