import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:copy_with_extension/copy_with_extension.dart';

part 'splash_view_state.g.dart';

///
@CopyWith()
class SplashViewState extends ViewState {
  ///
  final bool? load;
  final String? appLink;

  ///
  const SplashViewState(
    this.load,
    this.appLink,
  );

  ///
  SplashViewState.initial()
      : load = false,
        appLink = null;

  ///
  @override
  List<Object?> get props => <Object?>[load, appLink];
}
