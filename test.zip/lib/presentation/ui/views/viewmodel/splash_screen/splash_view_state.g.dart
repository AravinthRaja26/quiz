// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'splash_view_state.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$SplashViewStateCWProxy {
  SplashViewState load(bool? load);

  SplashViewState appLink(String? appLink);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `SplashViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// SplashViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  SplashViewState call({
    bool? load,
    String? appLink,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfSplashViewState.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfSplashViewState.copyWith.fieldName(...)`
class _$SplashViewStateCWProxyImpl implements _$SplashViewStateCWProxy {
  const _$SplashViewStateCWProxyImpl(this._value);

  final SplashViewState _value;

  @override
  SplashViewState load(bool? load) => this(load: load);

  @override
  SplashViewState appLink(String? appLink) => this(appLink: appLink);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `SplashViewState(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// SplashViewState(...).copyWith(id: 12, name: "My name")
  /// ````
  SplashViewState call({
    Object? load = const $CopyWithPlaceholder(),
    Object? appLink = const $CopyWithPlaceholder(),
  }) {
    return SplashViewState(
      load == const $CopyWithPlaceholder()
          ? _value.load
          // ignore: cast_nullable_to_non_nullable
          : load as bool?,
      appLink == const $CopyWithPlaceholder()
          ? _value.appLink
          // ignore: cast_nullable_to_non_nullable
          : appLink as String?,
    );
  }
}

extension $SplashViewStateCopyWith on SplashViewState {
  /// Returns a callable class that can be used as follows: `instanceOfSplashViewState.copyWith(...)` or like so:`instanceOfSplashViewState.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$SplashViewStateCWProxy get copyWith => _$SplashViewStateCWProxyImpl(this);
}
