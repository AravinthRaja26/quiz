import 'dart:async';
import 'dart:io';

import 'package:auto_route/auto_route.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:nikitchem/application/events/language_event.dart';
import 'package:nikitchem/data/abstract/abstract.viewmodel.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/mixin/event_mixin.dart';
import 'package:nikitchem/data/models/auto_update/auto_update_model.dart';
import 'package:nikitchem/data/models/language_model/local_language.dart';
import 'package:nikitchem/data/network/run_api_safe_zone.dart';
import 'package:nikitchem/data/repository/auto_update/auto_update_repository.dart';
import 'package:nikitchem/data/repository/language/language_repository.dart';
import 'package:nikitchem/data/repository/push_notification/push_notification_repository.dart';
import 'package:nikitchem/data/services/notification_service.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:nikitchem/presentation/ui/views/viewmodel/splash_screen/splash_view_state.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:event_bus_plus/res/app_event.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:string_extensions/string_extensions.dart';

///
class SplashViewModel extends BaseViewModel<SplashViewState>
    with EventMixin<AppEvent> {
  ///
  LanguageRepository languageRepository = injector<LanguageRepository>();

  ///
  StreamSubscription<AppEvent>? streamSubscription;

  ///
  AutoUpdateRepository autoUpdateRepository = injector<AutoUpdateRepository>();

  ///
  PushNotificationRepository pushNotificationRepository =
      injector<PushNotificationRepository>();



  ///
  LocalStorage localStorage = injector<LocalStorage>();

  ///
  SplashViewModel() : super(SplashViewState.initial()) {
    streamSubscription = listenEvents((AppEvent event) {
      if (event is LanguageEvent) {
        notifyListeners();
      }
    });
  }

  ///
  GlobalKey<ScaffoldState> key = GlobalKey<ScaffoldState>();

  ///
  void init(BuildContext context) async {
    await getLanguage();
    await checkUpdate();
    Future<dynamic>.delayed(const Duration(seconds: 4), () {

        AutoRouter.of(context)
            .pushAndPopUntil(const TutorialScreen(), predicate: (_) => false);

    });
    await NotificationService.injected()
        .initialize()
        .onError((Object? error, StackTrace stackTrace) async {
      String? fcmToken = await FirebaseMessaging.instance.getToken();
      localStorage.save(StorageKey.fcmToken, fcmToken);
      if (fcmToken != null && fcmToken.isNotEmpty) {
        await sendNotification(fcmToken);
      }
    });
  }

  ///
  Future<void> getLanguage() async {
    // if (context != null) {
    ApiResult<LanguageResponse> result = await runApiInSafeZone(() =>
        languageRepository.getLanguage(
            language: localStorage.retrieveString(StorageKey.selectLanguage) ??
                '${Platform.localeName[0]}${Platform.localeName[1]}'));
    print('----->${Platform.localeName[0]}${Platform.localeName[1]}');
    if (result.isSucceeded) {
      localLanguage = result.data?.language;
      notifyListeners();
    } else {
      // ApiResult.catchError(result, context!);
      // }
    }
  }

  ///
  /// sendNotification
  ///
  Future<void> sendNotification(String fcmToken) async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    IosDeviceInfo? iosDeviceInfo;
    AndroidDeviceInfo? androidDeviceInfo;
    if (Platform.isAndroid) {
      androidDeviceInfo = await deviceInfo.androidInfo;
    } else {
      iosDeviceInfo = await deviceInfo.iosInfo;
    }

    String? id = Platform.isAndroid
        ? androidDeviceInfo?.id
        : iosDeviceInfo?.identifierForVendor;

    await runApiInSafeZone(() =>
        pushNotificationRepository.sendPushNotification(id ?? '', fcmToken));
  }

  ///
  Future<void> checkUpdate() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String buildNumber = packageInfo.buildNumber;
    ApiResult<AutoUpdateModel> result = await runApiInSafeZone(
        () => autoUpdateRepository.checkUpdate(int.parse(buildNumber)));
    //TODO don`t removed for future
    if (result.isSucceeded) {
      int temp = result.data?.version?.versionCode?.toInt() ?? 0;
      if (temp > int.parse(buildNumber)) {
        localStorage.save(StorageKey.isForceUpdate, true);
        if (result.data?.version?.appLink != null) {
          localStorage.save(StorageKey.appLink, result.data?.version?.appLink);
          localStorage.save(
              StorageKey.messageVersion, result.data?.version?.messageVersion);
          localStorage.save(
              StorageKey.messageInstall, result.data?.version?.messageInstall);
          localStorage.save(StorageKey.messageDownload,
              result.data?.version?.messageDownload);
        } else {
          localStorage.save(StorageKey.appLink, '');
        }
      } else {
        localStorage.save(StorageKey.isForceUpdate, false);
      }
    } else {}
  }
}
