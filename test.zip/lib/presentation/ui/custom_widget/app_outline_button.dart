import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:flutter/material.dart';

///
class AppOutlineButton extends StatelessWidget {
  ///
  final String? text;

  ///
  final String? leadingPath;

  ///
  final String? trailingPath;

  ///
  final GestureTapCallback? onTap;

  ///
  const AppOutlineButton(
      {super.key, this.text, this.leadingPath, this.trailingPath, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(21),
      child: InkWell(
        splashColor: CustomColors.grey900,
        onTap: onTap ?? () {},
        borderRadius: BorderRadius.circular(21),
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(color: CustomColors.midBlue),
              borderRadius: BorderRadius.circular(21)),
          child: Row(
            children: <Widget>[
              if (leadingPath != null)
                Padding(
                  padding: const EdgeInsets.only(right: 10.0, left: 18.0),
                  child: Image.asset(AssetImagePath.downArrow),
                ),
              Padding(
                padding: EdgeInsets.only(
                    top: 12.0,
                    bottom: 12.0,
                    left: leadingPath != null ? 0 : 18.0,
                    right: trailingPath != null ? 0 : 18.0),
                child: TextVariant(
                  data: text ?? 'Text Here',
                  textAlign: TextAlign.center,
                  variantType: TextVariantType.bodySmall,
                  color: CustomColors.midBlue,
                ),
              ),
              if (trailingPath != null)
                Padding(
                  padding: EdgeInsets.only(
                      left: trailingPath != null ? 10 : 0.0, right: 18.0),
                  child: Image.asset(
                    AssetImagePath.downArrow,
                    color: CustomColors.midBlue,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

///
class CustomOutlineButton extends StatelessWidget {
  ///
  final String? text;

  ///
  final String? leadingPath;

  ///
  final String? trailingPath;

  ///
  final double? width;

  ///
  final GestureTapCallback? onTap;

  ///
  const CustomOutlineButton(
      {super.key,
      this.text,
      this.leadingPath,
      this.trailingPath,
      this.onTap,
      this.width});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(21),
      child: InkWell(
        splashColor: CustomColors.grey900,
        onTap: onTap ?? () {},
        borderRadius: BorderRadius.circular(21),
        child: Padding(
          padding: const EdgeInsets.all(4.0),
          child: Container(
            width: width,
            height: 53.0,
            padding: const EdgeInsets.symmetric(vertical: 4.0, horizontal: 28),
            decoration: BoxDecoration(
                border: Border.all(color: CustomColors.midBlue),
                borderRadius: BorderRadius.circular(30)),
            child: Center(
              child: TextVariant(
                data: text?.toUpperCase() ?? 'Text Here',
                textAlign: TextAlign.center,
                fontFamily: FontFamily.quattrocentoSans,
                fontWeight: FontWeight.w700,
                color: CustomColors.midBlue,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
