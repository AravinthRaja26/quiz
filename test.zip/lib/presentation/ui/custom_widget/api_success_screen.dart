import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
@RoutePage(name: 'apiSuccessScreen')
class ApiSuccessScreen extends StatelessWidget {
  ///
  final String? image;

  ///
  final String? title;

  ///
  final String? subTitle;

  ///
  final bool? isScanScreen;

  ///
  final String? buttonName;

  ///
  GestureTapCallback? onTap;

  ///
  ApiSuccessScreen(
      {Key? key,
      this.image,
      this.title,
      this.subTitle,
      this.buttonName,
      this.onTap,
      this.isScanScreen})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      persistentFooterAlignment: AlignmentDirectional.center,
      persistentFooterButtons: [
        Visibility(
          visible: isScanScreen??false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
            child: BackGroundColorButton(
              isEnable: true,
              load: false,
              width: MediaQuery.of(context).size.width/2.5,
              btnName: localLanguage?.keyScanNew?.toUpperCase() ?? 'Scan New'.toUpperCase(),
              center: true,
              onTap: (){
                    AutoRouter.of(context).maybePop();
                  },
              variantType: TextVariantType.titleMedium,
              fontFamily: FontFamily.quattrocentoSans,
            ),
          ),),

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0.0),
          child: BackGroundColorButton(
            isEnable: true,
            load: false,
            width: MediaQuery.of(context).size.width/2.5,
            btnName: buttonName ?? LocaleKeys.goBack.tr().toUpperCase(),
            center: true,
            onTap: onTap ??
                () {
                  AutoRouter.of(context).maybePop();
                },
            variantType: TextVariantType.titleMedium,
            fontFamily: FontFamily.quattrocentoSans,
          ),
        ),
      ],
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding:
                  EdgeInsets.only(top: MediaQuery.of(context).size.height / 6),
              child: Center(
                child: Image.asset(
                  image ?? AssetImagePath.notificationImage,
                  /*height: 155,
                  width: 155,*/
                  fit: BoxFit.contain,
                ),
              ),
            ),
            const SizedBox(
              height: 31,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: TextVariant(
                data: title ?? 'Your Details is Empty',
                color: CustomColors.midBlue,
                fontFamily: FontFamily.playfairDisplay,
                fontSize: 38.0,
                textAlign: TextAlign.center,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(
              height: 23,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: TextVariant(
                data: subTitle ?? 'Your Details is Empty',
                color: CustomColors.purpleBrown,
                fontFamily: FontFamily.quattrocentoSans,
                variantType: TextVariantType.bodyMedium,
                textAlign: TextAlign.center,
              ),
            ),
            const Spacer(),
            /* isScanScreen == true
                ? Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 0.0),
                    child: AppButton(
                      isEnable: true,
                      load: false,
                      width: MediaQuery.of(context).size.width,
                      btnName: localLanguage?.keyEnterCodeManually ??
                          LocaleKeys.enterCodeManually.tr().toUpperCase(),
                      center: true,
                      onTap: onTap ??
                          () {
                           // AutoRouter.of(context).pop();
                          },
                      variantType: TextVariantType.titleMedium,
                      fontFamily: FontFamily.quattrocentoSans,
                    ),
                  )
                : const SizedBox(),*/
          ],
        ),
      ),
    );
  }
}

///
@RoutePage(name: 'transactionErrorScreen')
class TransactionErrorScreen extends StatelessWidget {
  ///
  final String? image;

  ///
  final String? title;

  ///
  final String? subTitle;

  ///
  final bool? isScanScreen;

  ///
  final String? buttonName;

  ///
  GestureTapCallback? onTap;

  ///
  final String? enteredValue;
  final bool? isScanNewButton;

  ///
  TransactionErrorScreen(
      {Key? key,
      this.image,
      this.title,
      this.isScanNewButton,
      this.subTitle,
      this.buttonName,
      this.onTap,
      this.isScanScreen,
      this.enteredValue})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      persistentFooterButtons: [

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 10.0),
          child: BackGroundColorButton(
            isEnable: true,
            load: false,
            width: MediaQuery.of(context).size.width,
            btnName: buttonName ?? LocaleKeys.goBack.tr().toUpperCase(),
            center: true,
            onTap: onTap ??
                () {
                  AutoRouter.of(context).maybePop();
                },
            variantType: TextVariantType.titleMedium,
            fontFamily: FontFamily.quattrocentoSans,
          ),
        ),

      ],
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding:
                  EdgeInsets.only(top: MediaQuery.of(context).size.height / 6),
              child: Center(
                child: Image.asset(
                  image ?? AssetImagePath.notificationImage,
                  height: 155,
                  width: 155,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            const SizedBox(
              height: 31,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: TextVariant(
                data: title ?? 'Your Details is Empty',
                color: CustomColors.midBlue,
                fontFamily: FontFamily.playfairDisplay,
                fontSize: 38.0,
                textAlign: TextAlign.center,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(
              height: 23,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  // Note: Styles for TextSpans must be explicitly defined.
                  // Child text spans will inherit styles from parent
                  style: const TextStyle(
                    fontSize: 14.0,

                    color: Colors.black,
                  ),
                  children: <TextSpan>[
                    const TextSpan(
                        text:
                            'Wallet transfer equal to Rupees 500 or above requires approval from the manufacturer and your approval request to transfer ',
                        style: TextStyle(

                            fontFamily: FontFamily.quattrocentoSans,
                            color: CustomColors.purpleBrown,
                            fontSize: 16,

                            fontWeight: FontWeight.w400)),
                    TextSpan(
                        text: enteredValue,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            fontFamily: FontFamily.quattrocentoSans,
                            color: CustomColors.midBlue)),
                    const TextSpan(
                        text:
                            ' has been submitted successfully.\n\nOn approval you will be credited with the claimed value , if declined please contact manufacturer via WhatsApp help.',
                        style: TextStyle(
                            fontFamily: FontFamily.quattrocentoSans,
                            color: CustomColors.purpleBrown,
                            fontSize: 16,
                            fontWeight: FontWeight.w400)),
                  ],
                ),
              ),
              /*  TextVariant(
                data: subTitle ?? 'Your Details is Empty',
                color: CustomColors.purpleBrown,
                fontFamily: FontFamily.quattrocentoSans,
                variantType: TextVariantType.bodyMedium,
                textAlign: TextAlign.center,
              ),*/
            ),
            const Spacer(),
            /* isScanScreen == true
                ? Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 0.0),
                    child: AppButton(
                      isEnable: true,
                      load: false,
                      width: MediaQuery.of(context).size.width,
                      btnName: localLanguage?.keyEnterCodeManually ??
                          LocaleKeys.enterCodeManually.tr().toUpperCase(),
                      center: true,
                      onTap: onTap ??
                          () {
                           // AutoRouter.of(context).pop();
                          },
                      variantType: TextVariantType.titleMedium,
                      fontFamily: FontFamily.quattrocentoSans,
                    ),
                  )
                : const SizedBox(),*/
          ],
        ),
      ),
    );
  }
}
