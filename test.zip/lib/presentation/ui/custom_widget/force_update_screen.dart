import 'dart:io';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/infrastructure/utils/app.text.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

///
@RoutePage(name: 'forceUpdateScreen')
class ForceUpdateScreen extends StatefulWidget {
  ///
  final String? image;

  ///
  final String? title;

  ///
  final String? subTitle;

  ///
  final bool? isScanScreen;

  ///
  final String? buttonName;

  ///
  GestureTapCallback? onTap;

  ///
  ForceUpdateScreen(
      {Key? key,
      this.image,
      this.title,
      this.subTitle,
      this.buttonName,
      this.onTap,
      this.isScanScreen})
      : super(key: key);

  @override
  State<ForceUpdateScreen> createState() => _ForceUpdateScreenState();
}

class _ForceUpdateScreenState extends State<ForceUpdateScreen> {
  ///
  LocalStorage localStorage = injector<LocalStorage>();

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData().copyWith(
        dividerColor: Colors.transparent,
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        persistentFooterButtons: <Widget>[
          AppButton(
            isEnable: true,
            load: false,
            width: MediaQuery.of(context).size.width,
            btnName: localLanguage?.keyUpdate ?? 'Update',
            center: true,
            onTap: () {
              if (localStorage.retrieveString(StorageKey.appLink) != null &&
                  localStorage.retrieveString(StorageKey.appLink) != '') {
                launchUrl(
                    Uri.parse(
                        '${localStorage.retrieveString(StorageKey.appLink)}'),
                    mode: LaunchMode.externalApplication);
                localStorage.save(StorageKey.isForceUpdate, false);
              } else {
                if (Platform.isAndroid) {
                  launchUrl(Uri.parse(AppText.playStoreUrl),
                      mode: LaunchMode.externalApplication);
                } else {
                  launchUrl(Uri.parse(AppText.appStoreUrl),
                      mode: LaunchMode.externalApplication);
                }
              }
            },
            variantType: TextVariantType.titleMedium,
            fontFamily: FontFamily.quattrocentoSans,
          ),
        ],
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Image.asset(
                widget.image ?? AssetImagePath.asLogo,
                height: 95,
                width: 155,
                fit: BoxFit.contain,
              ),
              Image.asset(
                widget.image ?? AssetImagePath.appUpdate,
                height: 155,
                width: 155,
                fit: BoxFit.contain,
              ),
              const SizedBox(
                height: 31,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: TextVariant(
                  data: LocaleKeys.appUpdate.tr() ?? 'App Update!',
                  color: CustomColors.midBlue,
                  fontFamily: FontFamily.playfairDisplay,
                  fontSize: 38.0,
                  textAlign: TextAlign.center,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(
                height: 23,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: TextVariant(
                  data: widget.subTitle
                          ?.replaceAll('key_check_platform',
                              Platform.isAndroid ? 'Play Store' : 'App Store')
                          .replaceAll('<Brand>', 'Litaski') ??
                      LocaleKeys.updateTheApp.tr(),
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.bodyMedium,
                  textAlign: TextAlign.center,
                ),
              ),
              // const Spacer(),
              widget.isScanScreen == true
                  ? Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16.0, vertical: 0.0),
                      child: AppButton(
                        isEnable: true,
                        load: false,
                        width: MediaQuery.of(context).size.width,
                        btnName: localLanguage?.keyEnterCodeManually ??
                            LocaleKeys.enterCodeManually.tr().toUpperCase(),
                        center: true,
                        onTap: widget.onTap ??
                            () {
                              AutoRouter.of(context).maybePop();
                            },
                        variantType: TextVariantType.titleMedium,
                        fontFamily: FontFamily.quattrocentoSans,
                      ),
                    )
                  : const SizedBox(),
              // Padding(
              //   padding:
              //       const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
              //   child: AppButton(
              //     isEnable: true,
              //     load: false,
              //     width: MediaQuery.of(context).size.width,
              //     btnName: localLanguage?.keyUpdate ?? 'Update',
              //     center: true,
              //     onTap: () {
              //       if (localStorage.retrieveString(StorageKey.appLink) != null &&
              //           localStorage.retrieveString(StorageKey.appLink) != '') {
              //         launchUrl(
              //             Uri.parse(
              //                 '${localStorage.retrieveString(StorageKey.appLink)}'),
              //             mode: LaunchMode.externalApplication);
              //         localStorage.save(StorageKey.isForceUpdate, false);
              //       } else {
              //         if (Platform.isAndroid) {
              //           launchUrl(Uri.parse(AppText.playStoreUrl),
              //               mode: LaunchMode.externalApplication);
              //         } else {
              //           launchUrl(Uri.parse(AppText.appStoreUrl),
              //               mode: LaunchMode.externalApplication);
              //         }
              //       }
              //     },
              //     variantType: TextVariantType.titleMedium,
              //     fontFamily: FontFamily.quattrocentoSans,
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}

