import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/gen/assets.gen.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/infrastructure/utils/app.text.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import 'package:flutter/services.dart';
import 'package:pinput/pinput.dart';

///
/// Api Alert Dialog
///
Future<bool?> apiAlertDialog(
  BuildContext context, {
  String? contentMessage,
  VoidCallback? callBack,
  String? buttonName,
  String? title,
}) async {
  return showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return Theme(
          data: ThemeData(dialogBackgroundColor: CustomColors.white),
          child: AlertDialog(
            actionsAlignment: MainAxisAlignment.center,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            title: TextVariant(
              data: title ?? '',
              variantType: TextVariantType.titleLarge,
            ),
            content: TextVariant(
              data: contentMessage ?? '',
              color: Theme.of(context).colorScheme.onBackground,
            ),
            actions: <Widget>[
              InkWell(
                  onTap: callBack ??
                      () {
                        AutoRouter.of(context).maybePop();
                      },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8.0, vertical: 4.0),
                    child: TextVariant(
                      data: buttonName ?? AppText.ok.toUpperCase(),
                      fontWeight: FontWeight.normal,
                      color: Theme.of(context).colorScheme.error,
                    ),
                  )),
            ],
          ),
        );
      });
}

///
Future<bool?> permissionAlertDialog(
  BuildContext context, {
  String? contentMessage,
  VoidCallback? callBack,
  String? yesButtonName,
  String? noButtonName,
}) async {
  return showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(localLanguage?.keyAppPermission ?? 'App Permission'),
          actionsAlignment: MainAxisAlignment.center,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          content: TextVariant(
            data: contentMessage ?? '',
            color: Theme.of(context).colorScheme.onBackground,
          ),
          actions: <Widget>[
            InkWell(
                onTap: () {
                  AutoRouter.of(context).maybePop();
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 28.0, vertical: 9.0),
                  child: TextVariant(
                    data: noButtonName?.toUpperCase() ??
                        AppText.cancel.toUpperCase(),
                    fontWeight: FontWeight.w700,
                    fontFamily: FontFamily.quattrocentoSans,
                    color: Theme.of(context).colorScheme.error,
                  ),
                )),
            InkWell(
                onTap: callBack ??
                    () {
                      AutoRouter.of(context).maybePop();
                    },
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 28.0, vertical: 10.0),
                  child: TextVariant(
                    data: yesButtonName?.toUpperCase() ??
                        AppText.ok.toUpperCase(),
                    fontWeight: FontWeight.w700,
                    fontFamily: FontFamily.quattrocentoSans,
                    color: Theme.of(context).colorScheme.error,
                  ),
                )),
          ],
        );
      });
}

///
Future<bool?> successDialog(
  BuildContext context, {
  String? title,
  String? subTitle,
  String? btnText,
  GestureTapCallback? onTap,
  GestureTapCallback? goTap,
  String? image,
}) async {
  return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: CustomColors.white,
          actionsAlignment: MainAxisAlignment.center,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          title: Image.asset(
            width: 80,
            height: 160,
            image ?? AssetImagePath.notificationImage,
            fit: BoxFit.contain,
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextVariant(
                data: title ?? LocaleKeys.login.tr(),
                color: CustomColors.black,
                fontFamily: FontFamily.playfairDisplay,
                variantType: TextVariantType.displaySmall,
                fontWeight: FontWeight.w600,
              ),
              TextVariant(
                data: subTitle ?? LocaleKeys.successful.tr(),
                color: CustomColors.black,
                fontFamily: FontFamily.playfairDisplay,
                variantType: TextVariantType.displaySmall,
                fontWeight: FontWeight.w600,
              ),
            ],
          ),
          actions: <Widget>[
            Center(
              child: AlertButton(
                onTap: goTap ?? () {},
                okText: btnText ?? LocaleKeys.goToHome.tr(),
              ),
            )
          ],
        );
      });
}

///
Future<bool?> otpAlertDialog(
  BuildContext context, {
  String? title,
  String? subTitle,
  GestureTapCallback? onTap,
  String? image,
  String? buttonName,
  VoidCallback? callBack,
  String? cancelText,
  String? confirmText,
  TextEditingController? otpController,
  final ValueChanged<String>? onChanged,
  bool? enable,
  Function(bool val)? goSubmit,
}) async {
  return showDialog<bool>(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return OtpDialog(
          title: title,
          subTitle: subTitle,
          onTap: onTap,
          image: image,
          buttonName: buttonName,
          callBack: callBack,
          cancelText: cancelText,
          confirmText: confirmText,
          otpController: otpController,
          onChanged: onChanged,
          enable: enable,
          goSubmit: goSubmit,
        );
      });
}

class OtpDialog extends StatefulWidget {
  ///
  String? title;

  ///
  String? subTitle;

  ///
  GestureTapCallback? onTap;

  ///
  String? image;

  ///
  String? buttonName;

  ///
  VoidCallback? callBack;

  ///
  FormFieldValidator<String>? validator;

  ///
  String? cancelText;

  ///
  String? confirmText;

  ///
  TextEditingController? otpController;

  ///
  final ValueChanged<String>? onChanged;

  ///
  Function(bool value)? goSubmit;

  ///
  bool? enable;

  ///
  OtpDialog({
    super.key,
    this.title,
    this.onChanged,
    this.subTitle,
    this.onTap,
    this.image,
    this.buttonName,
    this.callBack,
    this.validator,
    this.cancelText,
    this.confirmText,
    this.otpController,
    this.enable,
    this.goSubmit,
  });

  @override
  State<OtpDialog> createState() => _OtpDialogState();
}

class _OtpDialogState extends State<OtpDialog> {
  GlobalKey<FormState> fromKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: CustomColors.white,
      actionsAlignment: MainAxisAlignment.center,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      title: TextVariant(
        data: widget.title ?? LocaleKeys.enterTheVerificationOTP.tr(),
        color: CustomColors.black,
        fontFamily: FontFamily.playfairDisplay,
        variantType: TextVariantType.titleMedium,
        fontWeight: FontWeight.w600,
        textAlign: TextAlign.center,
      ),
      content: SingleChildScrollView(
        child: Form(
          key: fromKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Padding(
                  padding:
                      const EdgeInsets.only(top: 12.0, right: 16.0, left: 16.0),
                  child: Pinput(
                    autofocus: true,
                    controller: widget.otpController,
                    keyboardType: const TextInputType.numberWithOptions(
                        decimal: true, signed: false),
                    inputFormatters: <TextInputFormatter>[
                      FilteringTextInputFormatter.digitsOnly
                    ],
                    validator: (String? value) {
                      return value == ''
                          ? 'Please enter valid OTP!'
                          : value?.length != 4
                              ? 'Please enter valid OTP!'
                              : null;
                    },
                    onChanged: widget.onChanged ?? (String value) {},
                    pinputAutovalidateMode: PinputAutovalidateMode.onSubmit,
                    forceErrorState: true,
                    defaultPinTheme: PinTheme(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 3,
                                blurRadius: 7,
                                offset: const Offset(0, 2),
                              ),
                            ],
                            borderRadius: BorderRadius.circular(6.0)),
                        height: 50.0,
                        width: MediaQuery.of(context).size.width,
                        textStyle: const TextStyle(
                            color: CustomColors.midBlue,
                            fontFamily: FontFamily.quattrocentoSans,
                            fontWeight: FontWeight.w700,
                            fontSize: 20.0)),
                  )),
            ],
          ),
        ),
      ),
      actions: <Widget>[
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Flexible(
              child: Material(
                borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                color: CustomColors.white,
                child: InkWell(
                  onTap: () {
                    AutoRouter.of(context).maybePop();
                  },
                  child: Shimmer.fromColors(
                    enabled: widget.enable ?? false,
                    period: const Duration(milliseconds: 3000),
                    baseColor: CustomColors.midBlue,
                    highlightColor: CustomColors.black,
                    child: AnimatedContainer(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 28, vertical: 9),
                      decoration: BoxDecoration(
                          border: Border.all(color: CustomColors.red),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(21.0))),
                      duration: const Duration(seconds: 1),
                      child: TextVariant(
                        data: widget.cancelText ??
                            LocaleKeys.cancel.tr().toUpperCase(),
                        variantType: TextVariantType.labelMedium,
                        fontFamily: FontFamily.poppins,
                        fontSize: 16,
                        color: CustomColors.white,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              width: 4.0,
            ),
            Flexible(
              child: Material(
                borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                color: CustomColors.midBlue,
                child: InkWell(
                  onTap: /*widget.enable == true ? widget.onTap :*/ () {
                    if (fromKey.currentState!.validate()) {
                      widget.goSubmit?.call(true);
                    }
                  },
                  borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                  splashColor: CustomColors.grey900,
                  child: Shimmer.fromColors(
                    enabled: true,
                    period: const Duration(milliseconds: 3000),
                    baseColor: CustomColors.white,
                    highlightColor: CustomColors.greyish,
                    child: AnimatedContainer(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 28, vertical: 10),
                      decoration: const BoxDecoration(
                          borderRadius:
                              BorderRadius.all(Radius.circular(21.0))),
                      duration: const Duration(seconds: 1),
                      child: TextVariant(
                        data: widget.confirmText ??
                            LocaleKeys.confirm.tr().toUpperCase(),
                        variantType: TextVariantType.labelMedium,
                        fontFamily: FontFamily.poppins,
                        fontSize: 16,
                        overflow: TextOverflow.ellipsis,
                        color: CustomColors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

///
Future<bool?> confirmationDialog(
  BuildContext context, {
  String? title,
  String? subTitle,
  String? subTitle2,
  String? doneButtonText,
  String? cancelButtonText,
  bool? showCancelButton,
  bool? isBackButton,
  bool? barrierDismissible,
  GestureTapCallback? onTap,
  GestureTapCallback? cancelOnTap,
  String? image,
}) async {
  return showDialog<bool>(
      context: context,
      barrierDismissible: barrierDismissible ?? true,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async {
            return isBackButton ?? true;
          },
          child: Theme(
            data: ThemeData(dialogBackgroundColor: CustomColors.white),
            child: AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(34)),
              actionsAlignment: MainAxisAlignment.center,
              title: Image.asset(
                width: 50,
                height: 160,
                image ?? 'assets/images/group_3117.png',
                fit: BoxFit.contain,
              ),
              actionsPadding: const EdgeInsets.only(bottom: 22),
              content: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: TextVariant(
                  textAlign: TextAlign.center,
                  data: subTitle ?? 'Try after sometime',
                  color: CustomColors.black,
                  fontFamily: FontFamily.playfairDisplay,
                  variantType: TextVariantType.displaySmall,
                  fontWeight: FontWeight.w600,
                  fontSize: 20,
                ),
              ),
              actions: <Widget>[
                showCancelButton == null || showCancelButton == true
                    ? Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        child: InkWell(
                          onTap: cancelOnTap ??
                              () {
                                AutoRouter.of(context).maybePop();
                              },
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.midBlue,
                            highlightColor: CustomColors.black,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 28, vertical: 9),
                              decoration: BoxDecoration(
                                  border: Border.all(color: CustomColors.red),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: cancelButtonText?.toUpperCase() ??
                                    LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      ) /*Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        color: CustomColors.white,
                        child: InkWell(
                          onTap:cancelOnTap?? () {
                            AutoRouter.of(context).pop();
                          },
                          borderRadius:
                              const BorderRadius.all(Radius.circular(21.0)),
                          splashColor: CustomColors.grey900,
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.white,
                            highlightColor: CustomColors.greyish,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 6),
                              decoration: const BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: calcelButtonText ?? LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      )*/
                    : const SizedBox(),
                Material(
                  borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                  color: CustomColors.midBlue,
                  child: InkWell(
                    onTap: onTap ?? () {},
                    borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                    splashColor: CustomColors.grey900,
                    child: Shimmer.fromColors(
                      enabled: true,
                      period: const Duration(milliseconds: 3000),
                      baseColor: CustomColors.white,
                      highlightColor: CustomColors.greyish,
                      child: AnimatedContainer(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 28, vertical: 10),
                        decoration: const BoxDecoration(
                            borderRadius:
                                BorderRadius.all(Radius.circular(21.0))),
                        duration: const Duration(seconds: 1),
                        child: TextVariant(
                          data: doneButtonText?.toUpperCase() ??
                              LocaleKeys.yes.tr().toUpperCase(),
                          variantType: TextVariantType.labelMedium,
                          fontFamily: FontFamily.poppins,
                          fontSize: 16,
                          color: CustomColors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      });
}

///
Future<bool?> confirmationDialogWithoutImage(
  BuildContext context, {
  String? title,
  String? subTitle,
  String? subTitle2,
  String? doneButtonText,
  String? cancelButtonText,
  bool? showCancelButton,
  bool? isBackButton,
  bool? barrierDismissible,
  GestureTapCallback? onTap,
  GestureTapCallback? cancelOnTap,
  String? image,
}) async {
  return showDialog<bool>(
      context: context,
      barrierDismissible: barrierDismissible ?? true,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async {
            return isBackButton ?? true;
          },
          child: Theme(
            data: ThemeData(dialogBackgroundColor: CustomColors.white),
            child: AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(34)),
              actionsAlignment: MainAxisAlignment.center,
              // title: SizedBox(width: 50, height: 6),
              actionsPadding: const EdgeInsets.only(bottom: 22),
              content: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: TextVariant(
                  textAlign: TextAlign.center,
                  data: subTitle ?? 'Try after sometime',
                  color: CustomColors.black,
                  fontFamily: FontFamily.playfairDisplay,
                  variantType: TextVariantType.displaySmall,
                  fontWeight: FontWeight.w600,
                  fontSize: 20,
                ),
              ),
              actions: <Widget>[
                showCancelButton == null || showCancelButton == true
                    ? Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        child: InkWell(
                          onTap: cancelOnTap ??
                              () {
                                AutoRouter.of(context).maybePop();
                              },
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.midBlue,
                            highlightColor: CustomColors.black,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 28, vertical: 9),
                              decoration: BoxDecoration(
                                  border: Border.all(color: CustomColors.red),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: cancelButtonText?.toUpperCase() ??
                                    LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      ) /*Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        color: CustomColors.white,
                        child: InkWell(
                          onTap:cancelOnTap?? () {
                            AutoRouter.of(context).pop();
                          },
                          borderRadius:
                              const BorderRadius.all(Radius.circular(21.0)),
                          splashColor: CustomColors.grey900,
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.white,
                            highlightColor: CustomColors.greyish,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 6),
                              decoration: const BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: calcelButtonText ?? LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      )*/
                    : const SizedBox(),
                Material(
                  borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                  color: CustomColors.midBlue,
                  child: InkWell(
                    onTap: onTap ?? () {},
                    borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                    splashColor: CustomColors.grey900,
                    child: Shimmer.fromColors(
                      enabled: true,
                      period: const Duration(milliseconds: 3000),
                      baseColor: CustomColors.white,
                      highlightColor: CustomColors.greyish,
                      child: AnimatedContainer(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 28, vertical: 10),
                        decoration: const BoxDecoration(
                            borderRadius:
                                BorderRadius.all(Radius.circular(21.0))),
                        duration: const Duration(seconds: 1),
                        child: TextVariant(
                          data: doneButtonText?.toUpperCase() ??
                              LocaleKeys.yes.tr().toUpperCase(),
                          variantType: TextVariantType.labelMedium,
                          fontFamily: FontFamily.poppins,
                          fontSize: 16,
                          color: CustomColors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      });
}
///
Future<bool?> locationDialogWithoutImage(
  BuildContext context, {
  String? title,
  String? subTitle,
  String? subTitle2,
  String? doneButtonText,
  String? cancelButtonText,
  bool? showCancelButton,
  bool? isBackButton,
  bool? barrierDismissible,
  GestureTapCallback? onTap,
  GestureTapCallback? cancelOnTap,
  String? image,
}) async {
  return showDialog<bool>(
      context: context,
      barrierDismissible: barrierDismissible ?? true,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async {
            return isBackButton ?? true;
          },
          child: Theme(
            data: ThemeData(dialogBackgroundColor: CustomColors.white),
            child: AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(34)),
              actionsAlignment: MainAxisAlignment.center,
              // title: SizedBox(width: 50, height: 6),
              actionsPadding: const EdgeInsets.only(bottom: 22),
              content: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: TextVariant(
                  textAlign: TextAlign.center,
                  data: subTitle ?? 'Try after sometime',
                  color: CustomColors.black,
                  fontFamily: FontFamily.playfairDisplay,
                  variantType: TextVariantType.displaySmall,
                  fontWeight: FontWeight.w600,
                  fontSize: 20,
                ),
              ),
              actions: <Widget>[
                showCancelButton == null || showCancelButton == true
                    ? Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        child: InkWell(
                          onTap: cancelOnTap ??
                              () {
                                AutoRouter.of(context).maybePop();
                              },
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.midBlue,
                            highlightColor: CustomColors.black,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 28, vertical: 9),
                              decoration: BoxDecoration(
                                  border: Border.all(color: CustomColors.red),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: cancelButtonText?.toUpperCase() ??
                                    LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      ) /*Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        color: CustomColors.white,
                        child: InkWell(
                          onTap:cancelOnTap?? () {
                            AutoRouter.of(context).pop();
                          },
                          borderRadius:
                              const BorderRadius.all(Radius.circular(21.0)),
                          splashColor: CustomColors.grey900,
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.white,
                            highlightColor: CustomColors.greyish,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 6),
                              decoration: const BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: calcelButtonText ?? LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      )*/
                    : const SizedBox(),
                Material(
                  borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                  color: CustomColors.midBlue,
                  child: InkWell(
                    onTap: onTap ?? () {},
                    borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                    splashColor: CustomColors.grey900,
                    child: Shimmer.fromColors(
                      enabled: true,
                      period: const Duration(milliseconds: 3000),
                      baseColor: CustomColors.white,
                      highlightColor: CustomColors.greyish,
                      child: AnimatedContainer(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 46, vertical: 10),
                        decoration: const BoxDecoration(
                            borderRadius:
                                BorderRadius.all(Radius.circular(21.0))),
                        duration: const Duration(seconds: 1),
                        child: TextVariant(
                          data: doneButtonText?.toUpperCase() ??
                              LocaleKeys.yes.tr().toUpperCase(),
                          variantType: TextVariantType.labelMedium,
                          fontFamily: FontFamily.poppins,
                          fontSize: 16,
                          color: CustomColors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      });
}

///
Future<bool?> updateAlert(
  BuildContext context, {
  String? title,
  String? subTitle,
  String? subTitle2,
  String? doneButtonText,
  String? cancelButtonText,
  bool? showCancelButton,
  bool? isBackButton,
  bool? barrierDismissible,
  GestureTapCallback? onTap,
  GestureTapCallback? cancelOnTap,
  String? image,
}) async {
  return showDialog<bool>(
      context: context,
      barrierDismissible: barrierDismissible ?? true,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async {
            return isBackButton ?? true;
          },
          child: Theme(
            data: ThemeData(dialogBackgroundColor: CustomColors.white),
            child: AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(34)),
              actionsAlignment: MainAxisAlignment.center,
              // title:
              actionsPadding: const EdgeInsets.only(bottom: 22),
              content: Wrap(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Image.asset(
                        image ?? 'assets/images/login_another_device.png',
                        fit: BoxFit.contain,
                        height: 70,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: Image.asset(
                          AssetImagePath.appUpdate,
                          height: 100,
                          fit: BoxFit.contain,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: TextVariant(
                          textAlign: TextAlign.center,
                          data: subTitle ?? 'Try after sometime',
                          color: CustomColors.black,
                          fontFamily: FontFamily.playfairDisplay,
                          variantType: TextVariantType.displaySmall,
                          fontWeight: FontWeight.w600,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              actions: <Widget>[
                showCancelButton == null || showCancelButton == true
                    ? Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        child: InkWell(
                          onTap: cancelOnTap ??
                              () {
                                AutoRouter.of(context).maybePop();
                              },
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.midBlue,
                            highlightColor: CustomColors.black,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 28, vertical: 9),
                              decoration: BoxDecoration(
                                  border: Border.all(color: CustomColors.red),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: cancelButtonText?.toUpperCase() ??
                                    LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      ) /*Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        color: CustomColors.white,
                        child: InkWell(
                          onTap:cancelOnTap?? () {
                            AutoRouter.of(context).pop();
                          },
                          borderRadius:
                              const BorderRadius.all(Radius.circular(21.0)),
                          splashColor: CustomColors.grey900,
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.white,
                            highlightColor: CustomColors.greyish,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 6),
                              decoration: const BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: calcelButtonText ?? LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      )*/
                    : const SizedBox(),
                Material(
                  borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                  color: CustomColors.midBlue,
                  child: InkWell(
                    onTap: onTap ?? () {},
                    borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                    splashColor: CustomColors.grey900,
                    child: Shimmer.fromColors(
                      enabled: true,
                      period: const Duration(milliseconds: 3000),
                      baseColor: CustomColors.white,
                      highlightColor: CustomColors.greyish,
                      child: AnimatedContainer(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 28, vertical: 10),
                        decoration: const BoxDecoration(
                            borderRadius:
                                BorderRadius.all(Radius.circular(21.0))),
                        duration: const Duration(seconds: 1),
                        child: TextVariant(
                          data: doneButtonText?.toUpperCase() ??
                              LocaleKeys.yes.tr().toUpperCase(),
                          variantType: TextVariantType.labelMedium,
                          fontFamily: FontFamily.poppins,
                          fontSize: 16,
                          color: CustomColors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      });
}

///
Future<bool?> timeOutAlert(
  BuildContext context, {
  String? title,
  String? subTitle,
  String? subTitle2,
  String? doneButtonText,
  String? cancelButtonText,
  bool? showCancelButton,
  bool? isBackButton,
  bool? barrierDismissible,
  GestureTapCallback? onTap,
  GestureTapCallback? cancelOnTap,
  String? image,
}) async {
  return showDialog<bool>(
      context: context,
      barrierDismissible: barrierDismissible ?? true,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async {
            return isBackButton ?? true;
          },
          child: AlertDialog(
            backgroundColor: CustomColors.white,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            title: Image.asset(
              width: 50,
              height: 110,
              image ?? Assets.images.logOut.path,
              fit: BoxFit.contain,
            ),
            content: Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: TextVariant(
                textAlign: TextAlign.center,
                data: subTitle ?? 'Try after sometime',
                color: CustomColors.black,
                fontFamily: FontFamily.playfairDisplay,
                variantType: TextVariantType.displaySmall,
                fontWeight: FontWeight.w600,
                fontSize: 20,
              ),
            ),
            actions: <Widget>[
              showCancelButton == null || showCancelButton == true
                  ? Material(
                      borderRadius:
                          const BorderRadius.all(Radius.circular(21.0)),
                      child: InkWell(
                        onTap: cancelOnTap ??
                            () {
                              AutoRouter.of(context).maybePop();
                            },
                        child: Shimmer.fromColors(
                          enabled: true,
                          period: const Duration(milliseconds: 3000),
                          baseColor: CustomColors.midBlue,
                          highlightColor: CustomColors.black,
                          child: AnimatedContainer(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 18, vertical: 5),
                            decoration: BoxDecoration(
                                border: Border.all(color: CustomColors.red),
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(21.0))),
                            duration: const Duration(seconds: 1),
                            child: TextVariant(
                              data: cancelButtonText?.toUpperCase() ??
                                  LocaleKeys.no.tr().toUpperCase(),
                              variantType: TextVariantType.labelMedium,
                              fontFamily: FontFamily.poppins,
                              fontSize: 16,
                              color: CustomColors.white,
                            ),
                          ),
                        ),
                      ),
                    ) /*Material(
                      borderRadius:
                          const BorderRadius.all(Radius.circular(21.0)),
                      color: CustomColors.white,
                      child: InkWell(
                        onTap:cancelOnTap?? () {
                          AutoRouter.of(context).pop();
                        },
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        splashColor: CustomColors.grey900,
                        child: Shimmer.fromColors(
                          enabled: true,
                          period: const Duration(milliseconds: 3000),
                          baseColor: CustomColors.white,
                          highlightColor: CustomColors.greyish,
                          child: AnimatedContainer(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 18, vertical: 6),
                            decoration: const BoxDecoration(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(21.0))),
                            duration: const Duration(seconds: 1),
                            child: TextVariant(
                              data: calcelButtonText ?? LocaleKeys.no.tr().toUpperCase(),
                              variantType: TextVariantType.labelMedium,
                              fontFamily: FontFamily.poppins,
                              fontSize: 16,
                              color: CustomColors.white,
                            ),
                          ),
                        ),
                      ),
                    )*/
                  : const SizedBox(),
              const SizedBox(
                width: 4,
              ),
              Material(
                borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                color: CustomColors.red,
                child: InkWell(
                  onTap: onTap ?? () {},
                  borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                  splashColor: CustomColors.grey900,
                  child: Shimmer.fromColors(
                    enabled: true,
                    period: const Duration(milliseconds: 3000),
                    baseColor: CustomColors.white,
                    highlightColor: CustomColors.greyish,
                    child: AnimatedContainer(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 18, vertical: 6),
                      decoration: const BoxDecoration(
                          borderRadius:
                              BorderRadius.all(Radius.circular(21.0))),
                      duration: const Duration(seconds: 1),
                      child: TextVariant(
                        data: doneButtonText?.toUpperCase() ??
                            LocaleKeys.yes.tr().toUpperCase(),
                        variantType: TextVariantType.labelMedium,
                        fontFamily: FontFamily.poppins,
                        fontSize: 16,
                        color: CustomColors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      });
}

///
Future<bool?> couponAlert(
  BuildContext context, {
  String? title,
  String? subTitle,
  String? subTitle2,
  String? doneButtonText,
  String? cancelButtonText,
  bool? showCancelButton,
  bool? isBackButton,
  bool? barrierDismissible,
  GestureTapCallback? onTap,
  GestureTapCallback? cancelOnTap,
  GestureTapCallback? OnTap,
  String? image,
}) async {
  return showDialog<bool>(
      context: context,
      barrierDismissible: barrierDismissible ?? true,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async {
            return isBackButton ?? true;
          },
          child: Theme(
            data: ThemeData(dialogBackgroundColor: CustomColors.white),
            child: AlertDialog(
              actionsAlignment: MainAxisAlignment.center,
              backgroundColor: CustomColors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              title: Image.asset(
                width: 50,
                height: 160,
                image ?? 'assets/images/ic_logout.png',
                fit: BoxFit.contain,
              ),
              content: Wrap(
                alignment: WrapAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: TextVariant(
                      textAlign: TextAlign.center,
                      data: subTitle ?? 'Try after sometime',
                      color: CustomColors.midBlue,
                      fontFamily: FontFamily.playfairDisplay,
                      variantType: TextVariantType.displaySmall,
                      fontWeight: FontWeight.w600,
                      fontSize: 20,
                    ),
                  ),
                  subTitle2 != null
                      ? Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: TextVariant(
                            textAlign: TextAlign.center,
                            data: subTitle2 ?? 'Try after sometime',
                            color: CustomColors.black,
                            fontFamily: FontFamily.playfairDisplay,
                            variantType: TextVariantType.displaySmall,
                            fontWeight: FontWeight.w400,
                            fontSize: 18,
                          ),
                        )
                      : const SizedBox(),
                ],
              ),
              actions: <Widget>[
                showCancelButton == null || showCancelButton == true
                    ? Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        child: InkWell(
                          onTap: cancelOnTap ??
                              () {
                                AutoRouter.of(context).maybePop();
                              },
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.midBlue,
                            highlightColor: CustomColors.black,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 5),
                              decoration: BoxDecoration(
                                  border: Border.all(color: CustomColors.red),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: cancelButtonText?.toUpperCase() ??
                                    LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      ) /*Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        color: CustomColors.white,
                        child: InkWell(
                          onTap:cancelOnTap?? () {
                            AutoRouter.of(context).pop();
                          },
                          borderRadius:
                              const BorderRadius.all(Radius.circular(21.0)),
                          splashColor: CustomColors.grey900,
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.white,
                            highlightColor: CustomColors.greyish,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 6),
                              decoration: const BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: calcelButtonText ?? LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      )*/
                    : const SizedBox(),
                const SizedBox(
                  width: 4,
                ),
                Material(
                  borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                  color: CustomColors.midBlue,
                  child: InkWell(
                    onTap: onTap ?? () {},
                    borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                    splashColor: CustomColors.grey900,
                    child: Shimmer.fromColors(
                      enabled: true,
                      period: const Duration(milliseconds: 3000),
                      baseColor: CustomColors.white,
                      highlightColor: CustomColors.greyish,
                      child: AnimatedContainer(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 18, vertical: 6),
                        decoration: const BoxDecoration(
                            borderRadius:
                                BorderRadius.all(Radius.circular(21.0))),
                        duration: const Duration(seconds: 1),
                        child: TextVariant(
                          data: doneButtonText?.toUpperCase() ??
                              LocaleKeys.yes.tr().toUpperCase(),
                          variantType: TextVariantType.labelMedium,
                          fontFamily: FontFamily.poppins,
                          fontSize: 16,
                          color: CustomColors.white,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 20,
                ),
              ],
            ),
          ),
        );
      });
}

///
Future<bool?> permissionAlert(
  BuildContext context, {
  String? title,
  String? subTitle,
  String? doneButtonText,
  String? cancelButtonText,
  bool? showCancelButton,
  bool? isBackButton,
  bool? barrierDismissible,
  GestureTapCallback? onTap,
  GestureTapCallback? cancelOnTap,
  String? image,
}) async {
  return showDialog<bool>(
      context: context,
      barrierDismissible: barrierDismissible ?? true,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async {
            return isBackButton ?? true;
          },
          child: Theme(
            data: ThemeData(dialogBackgroundColor: CustomColors.white),
            child: AlertDialog(
              backgroundColor: CustomColors.white,
              actionsPadding: const EdgeInsets.only(bottom: 22),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(34)),
              title: Image.asset(
                width: 50,
                height: 160,
                image ?? 'assets/images/ic_logout.png',
                fit: BoxFit.contain,
              ),
              content: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: TextVariant(
                  textAlign: TextAlign.center,
                  data: subTitle ?? LocaleKeys.doYouWantLogout.tr(),
                  color: CustomColors.black,
                  fontFamily: FontFamily.playfairDisplay,
                  variantType: TextVariantType.displaySmall,
                  fontWeight: FontWeight.w600,
                  fontSize: 20,
                ),
              ),
              actions: <Widget>[
                showCancelButton == null || showCancelButton == true
                    ? Padding(
                        padding: const EdgeInsets.only(bottom: 8.0),
                        child: Material(
                          borderRadius:
                              const BorderRadius.all(Radius.circular(21.0)),
                          child: InkWell(
                            onTap: cancelOnTap ??
                                () {
                                  AutoRouter.of(context).maybePop();
                                },
                            child: Shimmer.fromColors(
                              enabled: true,
                              period: const Duration(milliseconds: 3000),
                              baseColor: CustomColors.midBlue,
                              highlightColor: CustomColors.black,
                              child: AnimatedContainer(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 28, vertical: 9.0),
                                decoration: BoxDecoration(
                                    border: Border.all(color: CustomColors.red),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(21.0))),
                                duration: const Duration(seconds: 1),
                                child: TextVariant(
                                  data: cancelButtonText?.toUpperCase() ??
                                      LocaleKeys.no.tr().toUpperCase(),
                                  variantType: TextVariantType.labelMedium,
                                  fontFamily: FontFamily.poppins,
                                  fontSize: 16,
                                  color: CustomColors.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ) /*Material(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(21.0)),
                        color: CustomColors.white,
                        child: InkWell(
                          onTap:cancelOnTap?? () {
                            AutoRouter.of(context).pop();
                          },
                          borderRadius:
                              const BorderRadius.all(Radius.circular(21.0)),
                          splashColor: CustomColors.grey900,
                          child: Shimmer.fromColors(
                            enabled: true,
                            period: const Duration(milliseconds: 3000),
                            baseColor: CustomColors.white,
                            highlightColor: CustomColors.greyish,
                            child: AnimatedContainer(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 6),
                              decoration: const BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(21.0))),
                              duration: const Duration(seconds: 1),
                              child: TextVariant(
                                data: calcelButtonText ?? LocaleKeys.no.tr().toUpperCase(),
                                variantType: TextVariantType.labelMedium,
                                fontFamily: FontFamily.poppins,
                                fontSize: 16,
                                color: CustomColors.white,
                              ),
                            ),
                          ),
                        ),
                      )*/
                    : const SizedBox(),
                const SizedBox(
                  width: 4,
                ),
                Center(
                  child: Material(
                    borderRadius: const BorderRadius.all(Radius.circular(21.0)),
                    color: CustomColors.midBlue,
                    child: InkWell(
                      onTap: onTap ?? () {},
                      borderRadius:
                          const BorderRadius.all(Radius.circular(21.0)),
                      splashColor: CustomColors.grey900,
                      child: Shimmer.fromColors(
                        enabled: true,
                        period: const Duration(milliseconds: 3000),
                        baseColor: CustomColors.white,
                        highlightColor: CustomColors.greyish,
                        child: AnimatedContainer(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 28, vertical: 10),
                          decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(21.0))),
                          duration: const Duration(seconds: 1),
                          child: TextVariant(
                            data: doneButtonText?.toUpperCase() ??
                                LocaleKeys.yes.tr().toUpperCase(),
                            variantType: TextVariantType.labelMedium,
                            fontFamily: FontFamily.poppins,
                            fontSize: 16,
                            color: CustomColors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      });
}
