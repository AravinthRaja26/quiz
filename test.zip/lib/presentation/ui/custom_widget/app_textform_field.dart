import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/data/storage/local_storage/local.storage.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/storage.keys.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

///
class UnderLineTextField extends StatelessWidget {

  ///
  final String? title;

  ///
  final TextEditingController? controller;

  ///
  final TextInputType? keyboardType;

  ///
  final int? maxLength;

  ///
  final int? maxLines;

  ///
  final FormFieldValidator<String>? validator;

  ///
  final Widget? suffix;

  ///
  final TextInputAction? textInputAction;

  ///
  final Widget? prefixIcon;

  ///
  final Widget? prefix;

  ///
  final Widget? suffixIcon;

  ///
  final bool? enabled;

  ///
  final double? borderRadius;

  ///
  final EdgeInsetsGeometry? contentPadding;

  ///
  final bool? readOnly;

  ///
  final bool? obscureText;

  ///
  final String? hintText;

  ///
  final String? labelText;

  ///
  final Color? fillColor;

  ///
  final Color? color;

  ///
  final Color? hintColor;

  ///
  final Color? textColor;

  ///
  final Color? borderColor;

  ///
  final String? suffixText;

  ///
  final String? counterText;

  ///
  final String? fontFamily;

  ///
  final bool? filled;

  ///
  final TextAlign? textAlign;

  ///
  final FontWeight? fontWeight;

  ///
  final bool? alignLabelWithHint;

  ///
  final TextCapitalization? textCapitalization;

  ///
  final FocusNode? focusNode;

  ///
  final Function(String)? onChanged;

  ///
  List<TextInputFormatter>? inputFormatters;

  ///
  final GestureTapCallback? onTap;

  ///
  final Function(String? savedValue)? onSaved;

  ///
  UnderLineTextField(
      {Key? key,
      this.title,
      this.controller,
      this.keyboardType,
      this.maxLength,
      this.validator,
      this.textInputAction,
      this.suffix,
      this.onTap,
      this.prefixIcon,
      this.suffixIcon,
      this.counterText,
      this.obscureText,
      this.enabled,
      this.onChanged,
      this.readOnly,
      this.inputFormatters,
      this.hintText,
      this.fillColor,
      this.color,
      this.hintColor,
      this.filled,
      this.suffixText,
      this.maxLines,
      this.labelText,
      this.contentPadding,
      this.textAlign,
      this.alignLabelWithHint,
      this.textCapitalization,
      this.fontFamily,
      this.fontWeight,
      this.focusNode,
      this.textColor,
      this.prefix,
      this.borderColor,
      this.borderRadius,
      this.onSaved})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    ///
    LocalStorage localStorage = injector<LocalStorage>();
    final double scaleFactor = MediaQuery.of(context).textScaleFactor;

    ///
    String tamilFontSize =
        localStorage.retrieveString(StorageKey.selectLanguage) ?? 'en';
    return Padding(
      padding: const EdgeInsets.only(top: 8.0, bottom: 8),
      child: TextFormField(
        textAlign: textAlign ?? TextAlign.start,
        focusNode: focusNode,
        textCapitalization: textCapitalization ?? TextCapitalization.none,
        style: TextStyle(

            fontSize: tamilFontSize == 'ta' ? 14/scaleFactor : 16/scaleFactor,
            color: textColor ?? CustomColors.darkBlack,

            fontWeight: FontWeight.w700,
            fontFamily: FontFamily.quattrocentoSans),
        inputFormatters: inputFormatters ??
            <TextInputFormatter>[NoInitialSpaceInputFormatter()],
        textInputAction: textInputAction ?? TextInputAction.next,

        decoration: InputDecoration(
          contentPadding: contentPadding ?? const EdgeInsets.all(12.0),
          counterText: counterText ?? '',
          hintText: hintText,
          prefixIcon: prefixIcon,
          suffixIcon: suffixIcon,
          labelText: labelText,
          hintStyle: TextStyle(
            fontSize: tamilFontSize == 'ta' ? 14/scaleFactor : 16/scaleFactor,
            color: CustomColors.greyish,
            fontWeight: FontWeight.w400,
            fontFamily: FontFamily.quattrocentoSans,
          ),
          suffix: suffix,
          suffixText: suffixText,
          enabled: true,
          suffixStyle: TextStyle(
            color: CustomColors.midBlue,
            fontSize: tamilFontSize == 'ta' ? 14/scaleFactor : 16/scaleFactor,
            fontWeight: FontWeight.w400,


          ),
          prefix: prefix,
          border: OutlineInputBorder(

            borderSide: BorderSide(
                color: borderColor ?? CustomColors.whiteTwo, width: 1.0),
            borderRadius: BorderRadius.circular(borderRadius ?? 8.0),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: borderColor ?? CustomColors.whiteTwo, width: 1.0),
            borderRadius: BorderRadius.circular(borderRadius ?? 8.0),
          ),
          disabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: borderColor ?? CustomColors.whiteTwo, width: 1.0),
            borderRadius: BorderRadius.circular(borderRadius ?? 8.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: borderColor ?? CustomColors.whiteTwo, width: 1.0),
            borderRadius: BorderRadius.circular(borderRadius ?? 8.0),
          ),
        ),
        onSaved: onSaved ?? (String? value) {},
        readOnly: readOnly ?? false,
        cursorColor: CustomColors.midBlue,
        enabled: enabled,
        obscureText: obscureText ?? false,
        cursorHeight: 25,
        controller: controller,
        onTap: onTap ?? () {},
        validator: validator ??
            (String? value) {
              return null;
            },
        keyboardType: keyboardType,
        maxLength: maxLength,
        maxLines: maxLines,
        onChanged: onChanged ?? (String value) {},
      ),
    );
  }
}

///
class NoInitialSpaceInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    if (newValue.text.startsWith(' ')) {
      return oldValue;
    }
    return newValue;
  }
}

///
class MessageUnderLineTextField extends StatelessWidget {
  ///
  final String? title;

  ///
  final TextEditingController? controller;

  ///
  final TextInputType? keyboardType;

  ///
  final int? maxLength;

  ///
  final int? maxLines;

  ///
  final FormFieldValidator<String>? validator;

  ///
  final Widget? suffix;

  ///
  final TextInputAction? textInputAction;

  ///
  final Widget? prefixIcon;

  ///
  final Widget? prefix;

  ///
  final Widget? suffixIcon;

  ///
  final bool? enabled;

  ///
  final double? borderRadius;

  ///
  final EdgeInsetsGeometry? contentPadding;

  ///
  final bool? readOnly;

  ///
  final bool? obscureText;

  ///
  final String? hintText;

  ///
  final String? labelText;

  ///
  final Color? fillColor;

  ///
  final Color? color;

  ///
  final Color? hintColor;

  ///
  final Color? textColor;

  ///
  final Color? borderColor;

  ///
  final String? suffixText;

  ///
  final String? counterText;

  ///
  final String? fontFamily;

  ///
  final bool? filled;

  ///
  final TextAlign? textAlign;

  ///
  final FontWeight? fontWeight;

  ///
  final bool? alignLabelWithHint;

  ///
  final TextCapitalization? textCapitalization;

  ///
  final FocusNode? focusNode;

  ///
  final Function(String)? onChanged;

  ///
  List<TextInputFormatter>? inputFormatters;

  ///
  final GestureTapCallback? onTap;

  ///
  MessageUnderLineTextField(
      {Key? key,
      this.title,
      this.controller,
      this.onTap,
      this.keyboardType,
      this.maxLength,
      this.validator,
      this.textInputAction,
      this.suffix,
      this.prefixIcon,
      this.suffixIcon,
      this.counterText,
      this.obscureText,
      this.enabled,
      this.onChanged,
      this.readOnly,
      this.inputFormatters,
      this.hintText,
      this.fillColor,
      this.color,
      this.hintColor,
      this.filled,
      this.suffixText,
      this.maxLines,
      this.labelText,
      this.contentPadding,
      this.textAlign,
      this.alignLabelWithHint,
      this.textCapitalization,
      this.fontFamily,
      this.fontWeight,
      this.focusNode,
      this.textColor,
      this.prefix,
      this.borderColor,
      this.borderRadius})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    ///
    LocalStorage localStorage = injector<LocalStorage>();

    ///
    String tamilFontSize =
        localStorage.retrieveString(StorageKey.selectLanguage) ?? 'en';
    return Padding(
      padding: const EdgeInsets.only(top: 8.0, bottom: 8),
      child: TextFormField(
        cursorColor:CustomColors.midBlue,
        textAlign: textAlign ?? TextAlign.start,
        focusNode: focusNode,
        textCapitalization: textCapitalization ?? TextCapitalization.none,
        style: TextStyle(
            fontSize: tamilFontSize == 'ta' ? 14 : 16,
            color: textColor ?? CustomColors.darkBlack,
            fontWeight: FontWeight.w700,
            fontFamily: FontFamily.quattrocentoSans),
        inputFormatters: inputFormatters ??
            <TextInputFormatter>[NoInitialSpaceInputFormatter()],
        textInputAction: textInputAction ?? TextInputAction.next,
        decoration: InputDecoration(
          // alignLabelWithHint: alignLabelWithHint,
          // errorStyle: const TextStyle(color: Colors.white),
          // enabledBorder: OutlineInputBorder(
          //   borderRadius: BorderRadius.circular(8.0),
          //   borderSide:
          //       const BorderSide(width: 1.5, color: CustomColors.whiteTwo),
          // ),
          // focusedErrorBorder: OutlineInputBorder(
          //   borderSide: const BorderSide(color: Colors.white, width: 1.0),
          //   borderRadius: BorderRadius.circular(8.0),
          // ),

          contentPadding: contentPadding ?? const EdgeInsets.all(12.0),
          hintText: hintText,
          prefixIcon: prefixIcon,
          suffixIcon: suffixIcon,
          labelText: labelText,

          hintStyle: TextStyle(
            fontSize: tamilFontSize == 'ta' ? 14 : 16,
            color: CustomColors.greyish,
            fontWeight: FontWeight.w400,
            fontFamily: FontFamily.quattrocentoSans,
          ),
          // labelStyle: TextStyle(
          //   color: hintColor ?? Colors.white,
          //   fontSize: 16,
          //   fontWeight: fontWeight ?? FontWeight.w400,
          //   fontFamily: FontFamily.quattrocentoSans,
          // ),
          suffix: suffix,
          suffixText: suffixText,
          enabled: true,
          suffixStyle: TextStyle(
            color: Colors.red,
            fontSize: tamilFontSize == 'ta' ? 14 : 16,
            fontWeight: FontWeight.w400,
          ),

          prefix: prefix,
          border: OutlineInputBorder(
            borderSide: BorderSide(
                color: borderColor ?? CustomColors.whiteTwo, width: 1.0),
            borderRadius: BorderRadius.circular(borderRadius ?? 8.0),
          ),
          // errorBorder: OutlineInputBorder(
          //   borderSide:
          //       BorderSide(color: color ?? Colors.white, width: 1.0),
          //   borderRadius: BorderRadius.circular(8.0),
          // ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: borderColor ?? CustomColors.whiteTwo, width: 1.0),
            borderRadius: BorderRadius.circular(borderRadius ?? 8.0),
          ),
          disabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: borderColor ?? CustomColors.whiteTwo, width: 1.0),
            borderRadius: BorderRadius.circular(borderRadius ?? 8.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: borderColor ?? CustomColors.whiteTwo, width: 1.0),
            borderRadius: BorderRadius.circular(borderRadius ?? 8.0),
          ),
        ),
        readOnly: readOnly ?? false,
        enabled: enabled,
        obscureText: obscureText ?? false,
        cursorHeight: 25,
        controller: controller,
        onTap: onTap ?? () {},
        validator: validator ??
            (String? value) {
              return null;
            },
        keyboardType: keyboardType,
        maxLength: maxLength,
        maxLines: maxLines,
        onChanged: onChanged ?? (String value) {},
      ),
    );
  }
}
