import 'dart:io';

import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/config/application.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/infrastructure/utils/app.text.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_outline_button.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_snack_bar.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_textform_field.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:nikitchem/presentation/ui/utils/valitaion.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

///

void showModelBottomSheet(
    BuildContext context,
    TextEditingController? accountHolderController,
    TextEditingController? accountNoController,
    TextEditingController? reAccountNoController,
    TextEditingController? ifscController,
    TextEditingController? bankNameController,
    TextEditingController? branchController,
    {GestureTapCallback? onTap,
    GestureTapCallback? cancelOnTap,
    Key? key,
    bool? load,
    Function(String)? ifscOnChanged,
    FormFieldValidator<String>? accountHolderNameValidator}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (BuildContext context) {
      return StatefulBuilder(
        builder:
            (BuildContext context, void Function(void Function()) setState) {
          return Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Form(
              key: key,
              child: Container(
                height: MediaQuery.of(context).size.height * 0.75,
                decoration: const BoxDecoration(
                  color: CustomColors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30.0),
                    topRight: Radius.circular(30.0),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        TextVariant(
                          data: localLanguage?.keyAddBankAccount ??
                              LocaleKeys.addBankAccount.tr(),
                          color: CustomColors.midBlue,
                          fontFamily: FontFamily.quattrocentoSans,
                          fontWeight: FontWeight.w700,
                          variantType: TextVariantType.headlineSmall,
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        UnderLineTextField(
                          textCapitalization: TextCapitalization.characters,
                          controller: accountHolderController,
                          hintText:
                              '${localLanguage?.keyAccountHolderName ?? LocaleKeys.accountHolderName.tr()}*',
                          hintColor: CustomColors.greyish,
                          color: CustomColors.midBlue,
                          validator: accountHolderNameValidator ??
                              (String? value) {
                                return AppValidation
                                    .accountHolderNameVerification(
                                        value: value?.trim() ?? '');
                              },
                          fillColor: CustomColors.lightWhite,
                        ),
                        UnderLineTextField(
                          controller: accountNoController,
                          hintText: localLanguage?.keyAccountNumber ??
                              '${LocaleKeys.accountNumber.tr()}*',
                          hintColor: CustomColors.greyish,
                          color: CustomColors.midBlue,
                          maxLength: 16,
                          validator: (String? value) {
                            return AppValidation.accountNumberVerification(
                                value: value?.trim() ?? '');
                          },
                          fillColor: CustomColors.lightWhite,
                          keyboardType: TextInputType.number,
                        ),
                        UnderLineTextField(
                          controller: reAccountNoController,
                          hintText: localLanguage?.keyReenterAccountNo ??
                              '${LocaleKeys.reEnterAccountNumber.tr()}*',
                          hintColor: CustomColors.greyish,
                          color: CustomColors.midBlue,
                          maxLength: 16,
                          validator: (String? value) {
                            return AppValidation.reAccountNumberVerification(
                                value: value ?? '',
                                accountNumber: accountNoController?.text
                                        .toString()
                                        .trim() ??
                                    '');
                          },
                          fillColor: CustomColors.lightWhite,
                          keyboardType: TextInputType.number,
                        ),
                        UnderLineTextField(
                          textCapitalization: TextCapitalization.characters,
                          controller: ifscController,
                          hintText:
                              '${localLanguage?.keyIfscCode ?? LocaleKeys.ifscCodeNumber.tr()}*',
                          hintColor: CustomColors.greyish,
                          color: CustomColors.midBlue,
                          maxLength: 11,
                          onChanged: ifscOnChanged ?? (String value) {},
                          validator: (String? value) {
                            return AppValidation.ifscCodeVerification(
                                value?.trim() ?? '');
                          },
                          fillColor: CustomColors.lightWhite,
                          keyboardType: TextInputType.emailAddress,
                        ),
                        UnderLineTextField(
                          controller: bankNameController,
                          hintText: localLanguage?.keyAddBankName ??
                              '${LocaleKeys.bankNameHolder.tr()}*',
                          hintColor: CustomColors.black,
                          textCapitalization: TextCapitalization.characters,
                          color: CustomColors.midBlue,
                          validator: (String? value) {
                            return AppValidation.bankNameVerification(
                                value?.trim() ?? '');
                          },
                          fillColor: CustomColors.lightWhite,
                          keyboardType: TextInputType.emailAddress,
                        ),
                        UnderLineTextField(
                          controller: branchController,
                          hintText: localLanguage?.keyBranchName ??
                              '${LocaleKeys.branchNameHolder.tr()}*',
                          hintColor: CustomColors.black,
                          color: CustomColors.midBlue,
                          textInputAction: TextInputAction.done,
                          textCapitalization: TextCapitalization.characters,
                          validator: (String? value) {
                            return AppValidation.branchNameVerification(
                                value?.trim() ?? '');
                          },
                          fillColor: CustomColors.lightWhite,
                          keyboardType: TextInputType.emailAddress,
                        ),
                        Row(
                          children: <Widget>[
                            const Padding(
                              padding: EdgeInsets.only(top: 14.0),
                              child: TextVariant(
                                data: '* ',
                                color: CustomColors.lipstick,
                                fontFamily: FontFamily.quattrocentoSans,
                                variantType: TextVariantType.bodyMedium,
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(right: 16.0, top: 14.0),
                              child: TextVariant(
                                data: localLanguage?.keyMandatoryHelpText !=
                                        null
                                    ? '${localLanguage?.keyMandatoryHelpText}'
                                    : LocaleKeys.markedFieldsAreMandatory.tr(),
                                color: CustomColors.purpleBrown,
                                fontFamily: FontFamily.quattrocentoSans,
                                variantType: TextVariantType.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              Expanded(
                                child: CustomOutlineButton(
                                  width: 160,
                                  text: localLanguage?.keyCancel ??
                                      LocaleKeys.cancel.tr().toUpperCase(),
                                  onTap: cancelOnTap ??
                                      () {
                                        AutoRouter.of(context).maybePop();
                                      },
                                ),
                              ),
                              Expanded(
                                child: BackGroundColorButton(
                                  isEnable: true,
                                  load: false,
                                  width: 160,
                                  btnName: localLanguage?.keyAdd ??
                                      LocaleKeys.add.tr().toUpperCase(),
                                  center: true,
                                  onTap: onTap ?? () async {},
                                  variantType: TextVariantType.titleMedium,
                                  fontFamily: FontFamily.quattrocentoSans,
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      );
    },
  );
}

///

void ticketBottomSheet(
    {BuildContext? context,
    TextEditingController? controller,
    GestureTapCallback? onTap,
    Key? key,
    FormFieldValidator<String>? validator}) {
  showModalBottomSheet(
    context: context!,
    isScrollControlled: true,
    builder: (BuildContext context) {
      return Padding(
        padding:
            EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          height: MediaQuery.of(context).size.height * 0.45,
          decoration: const BoxDecoration(
            color: CustomColors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30.0),
              topRight: Radius.circular(30.0),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: SingleChildScrollView(
              child: Form(
                key: key,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    TextVariant(
                      data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),
                      color: CustomColors.midBlue,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w700,
                      variantType: TextVariantType.headlineSmall,
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    MessageUnderLineTextField(
                      maxLines: 6,
                      maxLength: 1000,
                      controller: controller,
                      textAlign: TextAlign.start,
                      hintText: localLanguage?.keyEnterYourComment ??
                          LocaleKeys.enterYourCommentHere.tr(),
                      hintColor: CustomColors.greyish,
                      color: CustomColors.midBlue,
                      alignLabelWithHint: true,
                      validator: validator ??
                          (dynamic value) {
                            return null;
                          },
                      fillColor: CustomColors.lightWhite,
                      keyboardType: TextInputType.emailAddress,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Expanded(
                            child: CustomOutlineButton(
                              width: 160,
                              text: localLanguage?.keyCancel ??
                                  LocaleKeys.cancel.tr().toUpperCase(),
                              onTap: () {
                                AutoRouter.of(context).maybePop();
                              },
                            ),
                          ),
                          Expanded(
                            child: BackGroundColorButton(
                              width: 160,
                              isEnable: true,
                              load: false,
                              btnName: localLanguage?.keyCreate ??
                                  LocaleKeys.create.tr().toUpperCase(),
                              center: true,
                              onTap: onTap ?? () {},
                              variantType: TextVariantType.titleMedium,
                              fontFamily: FontFamily.quattrocentoSans,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    },
  );
}

///

void forgetPasswordBottomSheet(
    {required BuildContext context,
    TextEditingController? controller,
    GestureTapCallback? onTap,
    String? whatsappNumber,
    String? phoneNumber,
    Key? key,
    FormFieldValidator<String>? validator}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (BuildContext context) {
      return Padding(
        padding:
            EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          height: MediaQuery.of(context).size.height * 0.65,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(
            color: CustomColors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30.0),
              topRight: Radius.circular(30.0),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: SingleChildScrollView(
              child: Form(
                key: key,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    /* InkWell(
                      onTap: () {
                        AutoRouter.of(context).pop();
                      },
                      child: const Align(
                        alignment: Alignment.topRight,
                        child: Icon(
                          Icons.clear,
                          color: CustomColors.red,
                        ),
                      ),
                    ),*/
                    const SizedBox(
                      height: 25,
                    ),
                    Align(
                      alignment: Alignment.topCenter,
                      child: Image.asset(
                        AssetImagePath.asLogo,
                      ),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    const TextVariant(
                      data: 'Contact Support ',
                      color: CustomColors.purpleBrown,
                      fontFamily: FontFamily.playfairDisplay,
                      variantType: TextVariantType.headlineMedium,
                      fontWeight: FontWeight.w600,
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    Visibility(
                      visible: phoneNumber != null &&
                          phoneNumber != '' &&
                          phoneNumber != 'null',
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                          color: CustomColors.midBlue,
                          border: Border.all(
                            color: CustomColors.black,
                          ),
                        ),
                        child: Row(
                          children: <Widget>[
                            Container(
                              decoration: const BoxDecoration(
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(8.0),
                                  bottomLeft: Radius.circular(8.0),
                                ),
                                color: CustomColors.midBlue,
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  children: <Widget>[
                                    Icon(
                                      Icons.phone,
                                      color: CustomColors.white,
                                    ),
                                    SizedBox(
                                      width: 8,
                                    ),
                                    TextVariant(
                                      data: phoneNumber ?? '',
                                      color: CustomColors.white,
                                      fontFamily: FontFamily.quattrocentoSans,
                                      fontWeight: FontWeight.w700,
                                      variantType: TextVariantType.bodyLarge,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const Spacer(),
                            InkWell(
                              onTap: () async {
                                String url = "tel:${phoneNumber ?? ''}";
                                if (!await launchUrl(Uri.parse(url))) {
                                  throw Exception('Could not launch $url');
                                } else {
                                  // await launchUrl(Uri.parse(url));
                                }
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.only(
                                    topRight: Radius.circular(8.0),
                                    bottomRight: Radius.circular(8.0),
                                  ),
                                  color: CustomColors.midBlue,
                                  border: Border.all(
                                    color: CustomColors.black,
                                  ),
                                ),
                                child: const Padding(
                                  padding: EdgeInsets.all(9.55),
                                  child: Row(
                                    children: <Widget>[
                                      Icon(
                                        Icons.phone,
                                        color: CustomColors.white,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    Visibility(
                      visible: whatsappNumber != null &&
                          whatsappNumber != '' &&
                          whatsappNumber != 'null',
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                          color: CustomColors.midBlue,
                          border: Border.all(
                            color: CustomColors.black,
                          ),
                        ),
                        child: Row(
                          children: <Widget>[
                            Container(
                              decoration: const BoxDecoration(
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(8.0),
                                  bottomLeft: Radius.circular(8.0),
                                ),
                                color: CustomColors.midBlue,
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  children: <Widget>[
                                    Image.asset(
                                      'assets/images/whatsapp.webp',
                                      width: 25,

                                      height: 25,

                                      fit: BoxFit.cover,
                                    ),
                                    SizedBox(
                                      width: 8,
                                    ),
                                    TextVariant(
                                      data: whatsappNumber ?? '',
                                      color: CustomColors.white,
                                      fontFamily: FontFamily.quattrocentoSans,
                                      fontWeight: FontWeight.w700,
                                      variantType: TextVariantType.bodyLarge,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const Spacer(),
                            InkWell(
                              onTap: () async {
                                openWhatsapp(context,whatsappNumber??'');
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.only(
                                    topRight: Radius.circular(8.0),
                                    bottomRight: Radius.circular(8.0),
                                  ),
                                  color: CustomColors.midBlue,
                                  border: Border.all(
                                    color: CustomColors.black,
                                  ),
                                  /* boxShadow: <BoxShadow>[
                                        BoxShadow(
                                          color: Colors.grey.withOpacity(0.2),
                                          spreadRadius: 2,
                                          blurRadius: 5,
                                          offset: const Offset(0, 5),
                                        ),
                                      ],*/
                                ),
                                child: const Padding(
                                  padding: EdgeInsets.all(9.55),
                                  child: Row(
                                    children: <Widget>[
                                      Icon(
                                        Icons.copy_all_rounded,
                                        color: CustomColors.white,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        TextVariant(
                          data: '*',
                          color: CustomColors.red,
                          fontFamily: FontFamily.playfairDisplay,
                          variantType: TextVariantType.headlineSmall,
                          fontWeight: FontWeight.w600,
                        ),
                        SizedBox(
                          width: 12,
                        ),
                        TextVariant(
                          data:
                              'Please Contact support via call or\nWhatsapp from your register mobile \nnumber to reset your password',
                          color: CustomColors.purpleBrown,
                          // fontFamily: FontFamily.playfairDisplay,
                          variantType: TextVariantType.bodyMedium,
                          fontWeight: FontWeight.w400,
                        ),
                      ],
                    ),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16.0, vertical: 26.0),
                        child: AppButton(
                          isEnable: true,
                          width: MediaQuery.of(context).size.width,
                          btnName: 'OK',
                          center: true,
                          onTap: () {
                            AutoRouter.of(context).maybePop();
                          },
                          variantType: TextVariantType.titleMedium,
                          fontFamily: FontFamily.quattrocentoSans,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    },
  );

}
///
void openWhatsapp(BuildContext context,String whatsappNumber) async {
  String whatsapp =
      '+$whatsappNumber';
  String whatsappURlAndroid =
      'whatsapp://send?phone=$whatsapp';
  String whatsappURLIos =
      'https://wa.me/$whatsapp';
  if (Platform.isIOS) {
    if (await canLaunchUrl(Uri.parse(whatsappURLIos))) {
      await launchUrl(Uri.parse(whatsappURLIos));
    } else {
      AppSnackBar.warningSnackBar(context,
          contentMessage: 'Whatsapp is not installed');
    }
  } else {
    if (await canLaunchUrl(Uri.parse(whatsappURlAndroid))) {
      await launchUrl(Uri.parse(whatsappURlAndroid));
    } else {
      AppSnackBar.warningSnackBar(context,
          contentMessage: 'Whatsapp is not installed');
    }
  }
}

///

void passbookBottomSheet({
  BuildContext? context,
  TextEditingController? controller,
  GestureTapCallback? onTap,
  Key? key,
  FormFieldValidator<String>? validator,
  String? transcationType,
  String? couponCode,
  String? transferDate,
  double? transferValue,
}) {
  showModalBottomSheet(
    context: context!,
    isScrollControlled: true,
    builder: (BuildContext context) {
      return Padding(
        padding:
            EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          height: MediaQuery.of(context).size.height * 0.50,
          decoration: const BoxDecoration(
            color: CustomColors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30.0),
              topRight: Radius.circular(30.0),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.only(
                left: 20.0, right: 20.0, top: 10, bottom: 5),
            child: SingleChildScrollView(
              child: Form(
                key: key,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                            onPressed: () {
                              AutoRouter.of(context).maybePop();
                            },
                            icon: const Icon(Icons.clear))),
                    const TextVariant(
                      data: 'Transaction Details',
                      /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                      color: CustomColors.midBlue,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w700,
                      variantType: TextVariantType.headlineSmall,
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const TextVariant(
                      data: 'Coupon Code',
                      /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                      color: CustomColors.dimBlack,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w500,
                      variantType: TextVariantType.bodyMedium,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    TextVariant(
                      data: couponCode ?? '',
                      /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                      color: CustomColors.black,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w700,
                      variantType: TextVariantType.bodyLarge,
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const TextVariant(
                      data: 'Transaction Type',
                      /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                      color: CustomColors.dimBlack,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w500,
                      variantType: TextVariantType.bodyMedium,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    TextVariant(
                      data: transcationType ?? '',
                      /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                      color: CustomColors.red,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w700,
                      variantType: TextVariantType.bodyLarge,
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const TextVariant(
                      data: 'Transfer on',
                      /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                      color: CustomColors.dimBlack,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w500,
                      variantType: TextVariantType.bodyMedium,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    TextVariant(
                      data: transferDate ?? '',
                      /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                      color: CustomColors.black,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w700,
                      variantType: TextVariantType.bodyLarge,
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const TextVariant(
                      data: 'Points Value',
                      /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                      color: CustomColors.dimBlack,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w500,
                      variantType: TextVariantType.bodyMedium,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    TextVariant(
                      data: '${transferValue ?? ''}',
                      /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                      color: CustomColors.black,
                      fontFamily: FontFamily.quattrocentoSans,
                      fontWeight: FontWeight.w700,
                      variantType: TextVariantType.bodyLarge,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    },
  );
}

///
void transcationBottomSheet(
    {required BuildContext context,
    TextEditingController? controller,
    GestureTapCallback? onTap,
    Key? key,
    String? couponCode,
    double? basePoint,
    double? addtionalPoint,
    String? scanDate,
    String? expireDate,
    double? amount,
    FormFieldValidator<String>? validator}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (BuildContext context) {
      return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
        return Padding(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Container(
            height: MediaQuery.of(context).size.height * 0.65,
            decoration: const BoxDecoration(
              color: CustomColors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(30.0),
                topRight: Radius.circular(30.0),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 25.0, right: 25.0, top: 10, bottom: 5),
              child: SingleChildScrollView(
                child: Form(
                  key: key,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Align(
                          alignment: Alignment.topRight,
                          child: IconButton(
                              onPressed: () {
                                AutoRouter.of(context).maybePop();
                              },
                              icon: Icon(Icons.clear))),
                      const TextVariant(
                        data: 'Coupon Details',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.midBlue,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w700,
                        variantType: TextVariantType.headlineSmall,
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      const TextVariant(
                        data: 'QR code',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.dimBlack,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w500,
                        variantType: TextVariantType.bodyMedium,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      TextVariant(
                        data: couponCode ?? '----',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.black,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w700,
                        variantType: TextVariantType.bodyLarge,
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      const TextVariant(
                        data: 'Base Points',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.dimBlack,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w500,
                        variantType: TextVariantType.bodyMedium,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      TextVariant(
                        data: '$basePoint' ?? '',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.black,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w700,
                        variantType: TextVariantType.bodyLarge,
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      const TextVariant(
                        data: 'Additional Points',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.dimBlack,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w500,
                        variantType: TextVariantType.bodyMedium,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      TextVariant(
                        data: '$addtionalPoint' ?? '',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.black,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w700,
                        variantType: TextVariantType.bodyLarge,
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      const TextVariant(
                        data: 'Amount Earned',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.dimBlack,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w500,
                        variantType: TextVariantType.bodyMedium,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      TextVariant(
                        data: '$amount' ?? '',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.black,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w700,
                        variantType: TextVariantType.bodyLarge,
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      const TextVariant(
                        data: 'Scan Date ',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.dimBlack,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w500,
                        variantType: TextVariantType.bodyMedium,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      TextVariant(
                        data: scanDate ?? '-------',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.black,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w700,
                        variantType: TextVariantType.bodyLarge,
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      const TextVariant(
                        data: 'Expire Date ',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.dimBlack,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w500,
                        variantType: TextVariantType.bodyMedium,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      TextVariant(
                        data: expireDate ?? '------',
                        /*  data: localLanguage?.keyEnterYourTicketIssue ??
                          LocaleKeys.enterYourTicketIssue.tr(),*/
                        color: CustomColors.black,
                        fontFamily: FontFamily.quattrocentoSans,
                        fontWeight: FontWeight.w700,
                        variantType: TextVariantType.bodyLarge,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      });
    },
  );
}
