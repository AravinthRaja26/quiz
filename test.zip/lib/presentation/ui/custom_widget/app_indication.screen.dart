import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_button.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
class IndicationScreen extends StatelessWidget {
  ///
  final String? image;

  ///
  final String? title;

  ///
  final String? subTitle;

  ///
  final String? buttonName;

  ///
  GestureTapCallback? onTap;

  ///
  IndicationScreen(
      {Key? key,
      this.image,
      this.title,
      this.subTitle,
      this.buttonName,
      this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      persistentFooterButtons: <Widget>[
        BackGroundColorButton(
          isEnable: true,
          load: false,
          width: MediaQuery.of(context).size.width,
          btnName: buttonName ??
              localLanguage?.keyGoBack ??
              LocaleKeys.goBack.tr().toUpperCase(),
          center: true,
          onTap: onTap ?? () {},
          variantType: TextVariantType.titleMedium,
          fontFamily: FontFamily.quattrocentoSans,
        ),
      ],
      body: SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height / 6),
                child: Image.asset(
                  image ?? AssetImagePath.notificationImage,
                  height: 155,
                  width: 155,
                  fit: BoxFit.contain,
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: TextVariant(
                  data: title ?? 'Your Details is Empty',
                  color: CustomColors.midBlue,
                  fontFamily: FontFamily.playfairDisplay,
                  variantType: TextVariantType.displayMedium,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: TextVariant(
                  data: subTitle ?? 'Your Details is Empty',
                  color: CustomColors.purpleBrown,
                  fontFamily: FontFamily.quattrocentoSans,
                  variantType: TextVariantType.bodyLarge,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
