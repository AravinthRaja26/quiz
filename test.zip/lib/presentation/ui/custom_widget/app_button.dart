import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

///
class AppButton extends StatelessWidget {
  ///
  final String? btnName;

  ///
  final String? fontFamily;

  ///
  final TextVariantType? variantType;

  ///
  final GestureTapCallback? onTap;

  ///
  final bool? isEnable;

  ///
  final double? width;

  ///
  final bool? load;

  ///
  final bool? center;

  ///
  final bool? isBackgroundColorWhite;

  ///
  final bool? isGoIconShow;

  ///
  const AppButton(
      {super.key,
      this.fontFamily,
      this.variantType,
      this.btnName,
      this.onTap,
      this.width,
      this.center,
      this.isEnable,
      this.load,
      this.isBackgroundColorWhite,
      this.isGoIconShow});

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: const BorderRadius.all(Radius.circular(40.0)),
      color: isEnable == true
          ? btnName?.toLowerCase() == 'logout' ||
                  btnName?.toLowerCase() == localLanguage?.keyDelete ||
                  btnName?.toLowerCase() == 'வெளியேறு' ||
                  btnName?.toLowerCase() == 'delete my account'
              ? CustomColors.midBlue
              : isBackgroundColorWhite == true
                  ? CustomColors.white
                  : CustomColors.midBlue
          : CustomColors.ligthRed,
      child: InkWell(
        onTap: isEnable == true && load != true ? onTap : null,
        borderRadius: const BorderRadius.all(Radius.circular(40.0)),
        splashColor: CustomColors.greyish,
        child: Shimmer.fromColors(
          enabled: isEnable ?? false,
          period: const Duration(milliseconds: 3000),
          baseColor: isEnable == true
              ? isBackgroundColorWhite == true
                  ? CustomColors.midBlue
                  : CustomColors.white
              : CustomColors.midBlue,
          highlightColor: CustomColors.black,
          child: AnimatedContainer(
            height: 54.0,
            width: width,
            padding: EdgeInsets.symmetric(
                horizontal: load == true ? 12 : 16, vertical: 16),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.all(
                    Radius.circular(load == true ? 60 : 40.0))),
            duration: const Duration(seconds: 1),
            child: center != null && center == true
                ? load == true
                    ? const SizedBox(
                        child: Center(
                          child: SizedBox(
                            width: 22,
                            child: CircularProgressIndicator(
                              color: CustomColors.midBlue,
                            ),
                          ),
                        ),
                      )
                    : isGoIconShow == true
                        ? Row(
                            children: <Widget>[
                              TextVariant(
                                data: btnName?.toUpperCase() ??
                                    localLanguage?.keyLetsGo?.toUpperCase() ??
                                    LocaleKeys.LetsGo.tr().toUpperCase(),
                                textAlign: TextAlign.center,
                                variantType:
                                    variantType ?? TextVariantType.bodySmall,
                                fontFamily: fontFamily ?? FontFamily.poppins,
                                color: Colors.red,
                              ),
                              const Spacer(),
                              const Icon(
                                  Icons.keyboard_double_arrow_right_outlined,
                                  color: CustomColors.red),
                            ],
                          )
                        : TextVariant(
                            data: btnName?.toUpperCase() ??
                                localLanguage?.keyLetsGo?.toUpperCase() ??
                                LocaleKeys.LetsGo.tr().toUpperCase(),
                            textAlign: TextAlign.center,
                            variantType:
                                variantType ?? TextVariantType.bodySmall,
                            fontFamily: fontFamily ?? FontFamily.poppins,
                            color: Colors.red,
                          )
                : load == true
                    ? const SizedBox(
                        child: Center(
                          child: CircularProgressIndicator(
                            color: CustomColors.midBlue,
                          ),
                        ),
                      )
                    : TextVariant(
                        data: btnName?.toUpperCase() ??
                            localLanguage?.keyLetsGo?.toUpperCase() ??
                            LocaleKeys.LetsGo.tr().toUpperCase(),
                        variantType: variantType ?? TextVariantType.bodySmall,
                        fontFamily: fontFamily ?? FontFamily.poppins,
                        color: isEnable == true
                            ? CustomColors.white
                            : CustomColors.midBlue,
                      ),
          ),
        ),
      ),
    );
  }
}

///
class BackGroundColorButton extends StatelessWidget {
  ///
  final String? btnName;

  ///
  final String? fontFamily;

  ///
  final TextVariantType? variantType;

  ///
  final GestureTapCallback? onTap;

  ///
  final bool? isEnable;

  ///
  final double? width;

  ///
  final double? fontSize;

  ///
  final bool? load;

  ///
  final bool? center;

  ///
  final bool? isGoIconShow;

  ///
  final Color? backgroundColor;

  ///
  const BackGroundColorButton(
      {super.key,
      this.fontFamily,
      this.variantType,
      this.btnName,
      this.onTap,
      this.width,
      this.center,
      this.fontSize,
      this.isEnable,
      this.load,
      this.isGoIconShow,
      this.backgroundColor});

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: const BorderRadius.all(Radius.circular(40.0)),
      color: isEnable == true ? backgroundColor ?? CustomColors.midBlue :  CustomColors.greyish,
      child: InkWell(
        onTap: isEnable == true && load != true ? onTap : null,
        borderRadius: const BorderRadius.all(Radius.circular(40.0)),
        splashColor: CustomColors.greyish,
        child: Shimmer.fromColors(
          enabled: isEnable ?? false,
          period: const Duration(milliseconds: 3000),
          baseColor: CustomColors.white,
          highlightColor: CustomColors.black,
          child: AnimatedContainer(
            height: 54.0,
            width: width,
            padding: EdgeInsets.symmetric(
                horizontal: load == true ? 12 : 16, vertical: 16),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.all(
                    Radius.circular(load == true ? 60 : 40.0))),
            duration: const Duration(seconds: 1),
            child: center != null && center == true
                ? load == true
                    ? const Center(
                        child: SizedBox(
                          width: 24.0,
                          child: CircularProgressIndicator(
                            color: CustomColors.midBlue,
                          ),
                        ),
                      )
                    : isGoIconShow == true
                        ? Row(
                            children: <Widget>[
                              InkWell(
                                onTap: onTap??(){
                                  AutoRouter.of(context).maybePop();
                                },
                                child: TextVariant(
                                  data: btnName?.toUpperCase() ??
                                      localLanguage?.keyLetsGo?.toUpperCase() ??
                                      LocaleKeys.LetsGo.tr().toUpperCase(),
                                  textAlign: TextAlign.center,
                                  variantType:
                                      variantType ?? TextVariantType.bodySmall,
                                  fontFamily: fontFamily ?? FontFamily.poppins,
                                  color: Colors.red,
                                ),
                              ),
                              const Spacer(),
                              const Icon(
                                  Icons.keyboard_double_arrow_right_outlined,
                                  color: CustomColors.red),
                            ],
                          )
                        : TextVariant(
                            data: btnName?.toUpperCase() ??
                                localLanguage?.keyLetsGo?.toUpperCase() ??
                                LocaleKeys.LetsGo.tr().toUpperCase(),
                            textAlign: TextAlign.center,
                            variantType:
                                variantType ?? TextVariantType.bodySmall,
                            fontFamily: fontFamily ?? FontFamily.poppins,
                            color: Colors.red,
                            fontSize: fontSize,
                          )
                : load == true
                    ? const SizedBox(
                        child: Center(
                          child: CircularProgressIndicator(
                            color: CustomColors.midBlue,
                          ),
                        ),
                      )
                    : TextVariant(
                        data: btnName?.toUpperCase() ??
                            localLanguage?.keyLetsGo?.toUpperCase() ??
                            LocaleKeys.LetsGo.tr().toUpperCase(),
                        variantType: variantType ?? TextVariantType.bodySmall,
                        fontFamily: fontFamily ?? FontFamily.poppins,
                        color: Colors.white,
                      ),
          ),
        ),
      ),
    );
  }
}

///
class OpenButton extends StatelessWidget {
  ///
  final String? btnName;

  ///
  final String? fontFamily;

  ///
  final TextVariantType? variantType;

  ///
  final GestureTapCallback? onTap;

  ///
  final bool? isEnable;

  ///
  final double? width;

  ///
  final bool? load;

  ///
  final bool? center;

  ///
  const OpenButton(
      {super.key,
      this.fontFamily,
      this.variantType,
      this.btnName,
      this.onTap,
      this.width,
      this.center,
      this.isEnable,
      this.load});

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: const BorderRadius.all(Radius.circular(35.0)),
      color: isEnable == true
          ? btnName?.toLowerCase() == 'logout'
              ? CustomColors.lipstick
              : CustomColors.midBlue
          : CustomColors.greyish,
      child: InkWell(
        onTap: isEnable == true && load != true ? onTap : null,
        borderRadius: const BorderRadius.all(Radius.circular(21.0)),
        splashColor: CustomColors.grey900,
        child: Shimmer.fromColors(
          enabled: isEnable ?? false,
          period: const Duration(milliseconds: 3000),
          baseColor: CustomColors.white,
          highlightColor: CustomColors.greyish,
          child: AnimatedContainer(
            width: width,
            padding: EdgeInsets.symmetric(
                horizontal: load == true ? 12 : 32, vertical: 13),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.all(
                    Radius.circular(load == true ? 60 : 21.0))),
            duration: const Duration(seconds: 1),
            child: center != null && center == true
                ? Center(
                    child: load == true
                        ? const SizedBox(
                            width: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                            ),
                          )
                        : TextVariant(
                            data: btnName?.toUpperCase() ??
                                localLanguage?.keyLetsGo?.toUpperCase() ??
                                LocaleKeys.LetsGo.tr().toUpperCase(),
                            textAlign: TextAlign.center,
                            variantType:
                                variantType ?? TextVariantType.bodySmall,
                            fontFamily: fontFamily ?? FontFamily.poppins,
                            color: Colors.white,
                          ),
                  )
                : load == true
                    ? const CircularProgressIndicator(
                        color: Colors.white,
                      )
                    : TextVariant(
                        data: btnName?.toUpperCase() ??
                            localLanguage?.keyLetsGo?.toUpperCase() ??
                            LocaleKeys.LetsGo.tr().toUpperCase(),
                        variantType: variantType ?? TextVariantType.bodySmall,
                        fontFamily: fontFamily ?? FontFamily.poppins,
                        color: Colors.white,
                        textAlign: TextAlign.center,
                      ),
          ),
        ),
      ),
    );
  }
}

///
class AlertButton extends StatelessWidget {
  ///
  final String? okText;

  ///
  final GestureTapCallback? onTap;

  ///
  const AlertButton({super.key, this.okText, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: const BorderRadius.all(Radius.circular(21.0)),
      color: CustomColors.midBlue,
      child: InkWell(
        onTap: onTap ??
            () {
              AutoRouter.of(context).maybePop();
            },
        borderRadius: const BorderRadius.all(Radius.circular(21.0)),
        splashColor: CustomColors.grey900,
        child: Shimmer.fromColors(
          enabled: true,
          period: const Duration(milliseconds: 3000),
          baseColor: CustomColors.white,
          highlightColor: CustomColors.greyish,
          child: AnimatedContainer(
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
            decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(21.0))),
            duration: const Duration(seconds: 1),
            child: TextVariant(
              data: okText ??
                  localLanguage?.keyConfirm ??
                  LocaleKeys.confirm.tr().toUpperCase(),
              variantType: TextVariantType.labelMedium,
              fontFamily: FontFamily.poppins,
              fontSize: 16,
              color: CustomColors.white,
            ),
          ),
        ),
      ),
    );
  }
}

///
class CustomButton extends StatelessWidget {
  ///
  final String? btnName;

  ///
  final String? fontFamily;

  ///
  final TextVariantType? variantType;

  ///
  final GestureTapCallback? onTap;

  ///
  final double? width;

  ///
  final double? height;

  ///
  final bool? center;

  ///
  const CustomButton(
      {super.key,
      this.fontFamily,
      this.variantType,
      this.btnName,
      this.onTap,
      this.width,
      this.height,
      this.center});

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: const BorderRadius.all(Radius.circular(21.0)),
      color: CustomColors.midBlue,
      child: InkWell(
        onTap: onTap ?? () {},
        borderRadius: const BorderRadius.all(Radius.circular(21.0)),
        splashColor: CustomColors.grey900,
        child: Shimmer.fromColors(
          enabled: true,
          period: const Duration(milliseconds: 1000),
          baseColor: CustomColors.white,
          highlightColor: CustomColors.midBlue,
          child: Container(
            width: width,
            height: height,
            decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(21.0))),
            child: center != null && center == true
                ? Center(
                    child: TextVariant(
                      data: btnName ??
                          localLanguage?.keyLetsGo ??
                          LocaleKeys.LetsGo.tr(),
                      variantType: variantType ?? TextVariantType.bodySmall,
                      fontFamily: fontFamily ?? FontFamily.poppins,
                      color: Colors.white,
                    ),
                  )
                : TextVariant(
                    data: btnName ??
                        localLanguage?.keyLetsGo ??
                        LocaleKeys.LetsGo.tr(),
                    variantType: variantType ?? TextVariantType.bodySmall,
                    fontFamily: fontFamily ?? FontFamily.poppins,
                    color: Colors.white,
                  ),
          ),
        ),
      ),
    );
  }
}

///
class AppTextButton extends StatelessWidget {
  ///
  final String? btnName;

  ///
  final GestureTapCallback? onTap;

  final bool? isShowArrowIcon;

  ///
  const AppTextButton(
      {super.key, this.btnName, this.onTap, this.isShowArrowIcon});

  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: onTap ?? () {},
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              TextVariant(
                  data: btnName ?? '',
                  variantType: TextVariantType.bodySmall,
                  color: CustomColors.white,
                  fontFamily: FontFamily.poppins),
              isShowArrowIcon != null && isShowArrowIcon == true
                  ? const Padding(
                      padding: EdgeInsets.only(left: 4.0),
                      child: Icon(
                        Icons.keyboard_double_arrow_right_outlined,
                        color: CustomColors.white,
                      ),
                    )
                  : const SizedBox()
            ],
          ),
        ));
  }
}
