// ignore_for_file: always_specify_types

import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:flutter/material.dart';

///
class AppListTitle extends StatelessWidget {
  ///
  final String? text;

  ///
  final bool? isSupport;

  ///
  final GestureTapCallback? onTap;

  ///
  const AppListTitle({Key? key, this.text, this.isSupport, this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8.0, right: 8.0, top: 10, bottom: 6),
      child: Material(
        borderRadius: BorderRadius.circular(6.0),
        elevation: 3.0,
        color: Colors.white,
        child: InkWell(
          borderRadius: BorderRadius.circular(6.0),
          onTap: () {},
          splashColor: Colors.grey.withOpacity(0.2),
          splashFactory: InkSplash.splashFactory,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12.0),
            ),
            child: ListTile(
              title: TextVariant(
                data: text ?? '',
                color: CustomColors.purpleBrown,
                fontFamily: FontFamily.quattrocentoSans,
                variantType: TextVariantType.titleMedium,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

///
class CustomWidget extends StatelessWidget {
  ///
  final String? text;

  ///
  final GestureTapCallback? onTap;

  ///
  const CustomWidget({Key? key, this.text, this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8.0, right: 8.0, top: 10, bottom: 6),
      child: Material(
        borderRadius: BorderRadius.circular(6.0),
        elevation: 3.0,
        color: Colors.white,
        child: InkWell(
          borderRadius: BorderRadius.circular(6.0),
          onTap: onTap ?? () {},
          splashColor: Colors.grey.withOpacity(0.2),
          splashFactory: InkSplash.splashFactory,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12.0),
            ),
            child: ListTile(
              title: TextVariant(
                data: text ?? '',
                color: CustomColors.purpleBrown,
                fontFamily: FontFamily.quattrocentoSans,
                variantType: TextVariantType.titleMedium,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
