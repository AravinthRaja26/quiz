import 'package:flutter/material.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';

///
Future<void> mPinAlert(BuildContext context,
    {GestureTapCallback? onTap,GestureTapCallback? copyButton, String? alertMessage,String? pin}) async {

  List<String> tempList = alertMessage!.split('#');

  return showDialog<void>(
    context: context,
    barrierDismissible: false, // user must tap button!
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: CustomColors.lightBlue,
        title: const TextVariant(data:'Nikitchem',fontFamily: FontFamily.playfairDisplay,),
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              Row(
                children: <Widget>[
                  TextVariant(
                      data: tempList.first,
                      fontFamily: FontFamily.quattrocentoSans),
                  const SizedBox(
                    width: 6,
                  ),
                  TextVariant(
                      data: pin.toString(),
                      fontFamily: FontFamily.quattrocentoSans,
                      fontSize: 16.0,
                      color: CustomColors.midBlue),
                  const SizedBox(
                    width: 6,
                  ),
                  InkWell(onTap:copyButton?? (){}, child: const Icon(Icons.copy,color: Colors.red,)),
                ],
              ),
              TextVariant(
                  data: tempList.last,
                  fontFamily: FontFamily.quattrocentoSans),
            ],
          ),
        ),
        actions: <Widget>[
          Center(
            child: Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(16.0),color:CustomColors.midBlue,),
              padding: EdgeInsets.symmetric(horizontal: 4,vertical: 3),
              child: TextButton(
                child: const TextVariant(data: 'Okay',
                    fontFamily: FontFamily.poppins,
                    color: CustomColors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 18.0),
                onPressed: onTap
              ),
            ),
          ),
        ],
      );
    },
  );
}
