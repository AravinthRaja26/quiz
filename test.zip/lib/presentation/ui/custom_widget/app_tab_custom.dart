import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

///
class CustomCardWidget extends StatelessWidget {
  ///

  final String? image;

  ///
  final String? title;

  ///
  final GestureTapCallback? onTap;

  ///
  final double? width;

  ///
  final double? height;

  ///
  final Color? selectBgColor;

  ///
  final Color? selectTextColor;

  ///
  const CustomCardWidget(
      {Key? key,
      this.image,
      this.title,
      this.onTap,
      this.width,
      this.height,
      this.selectBgColor,
      this.selectTextColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap ?? () {},
      child: Card(
        elevation: 0,
        child: Container(
          width: width ?? 80,
          height: height ?? 75,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: Colors.grey.withOpacity(0.099)),
            color: selectBgColor ?? CustomColors.white,
          ),
          child: Center(
              child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Image.asset(
                image ?? AssetImagePath.earned,
                fit: BoxFit.fill,
                height: 23,
                width: 24,
                color: selectTextColor ?? CustomColors.darkBrown,
              ),

              TextVariant(
                data: title ??
                    localLanguage?.keyEarned ??
                    LocaleKeys.earned.tr().toUpperCase(),
                color: selectTextColor ?? CustomColors.darkBrown,
                fontFamily: FontFamily.quattrocentoSans,
                fontWeight: FontWeight.w700,
                variantType: TextVariantType.labelSmall,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              //  Text('$index'),
            ],
          )),
        ),
      ),
    );
  }
}
