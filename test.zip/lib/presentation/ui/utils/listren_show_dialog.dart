import 'package:injectable/injectable.dart';

///

@Singleton()
class IsShowAlert {
  ///
  bool show = false;
}
