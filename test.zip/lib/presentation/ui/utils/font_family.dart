import 'dart:core';

///
/// Font family calss
///
class FontFamily {
  ///
  static const String playfairDisplay = 'PlayfairDisplay';

  ///
  static const String poppins = 'Poppins';

  ///
  static const String quattrocentoSans = 'QuattrocentoSans';
}
