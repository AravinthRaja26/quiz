import 'package:flutter/material.dart';

///
/// AppIcons class for using hole projects
///

@staticIconProvider
abstract final class AppIcons {
  ///
  static const IconData payment = IconData(0xe481, fontFamily: 'MaterialIcons');
}
