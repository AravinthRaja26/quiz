///
class StorageKey {
  ///
  static String userName = 'user_name';

  ///
  static String password = 'password';

  ///
  static String isFinishedTutorial = 'is_finished_tutorial';

  ///
  static String cameraPermission = 'camera_permission';

  ///
  static String userPhoneNumber = 'user_phone_number';

  ///
  static String userEmail = 'user_email';

  ///
  static String keykjm = 'keykjm';

  ///
  static String fcmToken = 'fcm_token';

  ///
  static String isShowKeyWarning = 'is_show_key_warning';

  ///
  static String appLink = 'app_link';

  ///
  static String messageVersion = 'message_version';

  ///
  static String messageInstall = 'message_install';

  ///
  static String messageDownload = 'message_download';

  ///
  static String accountBalance = 'account_balance';

  ///
  static String selectLanguage = 'select_language';

  ///
  static String currentPageIndex = 'current_page_index';

  ///
  static String backPageIndex = 'back_page_index';

  ///
  static String isLogin = 'is_login';

  ///
  static String latitude = 'latitude';

  ///
  static String longitude = 'longitude';

  ///
  static String isProfileUpdate = 'is_profile_update';

  ///
  static String administrativeArea = 'administrativeArea';

  ///
  static String isForceUpdate = 'is_force_update';

  ///
  static String subAdministrativeArea = 'subAdministrativeArea';

  ///
  static String locality = 'locality';

  ///
  static String subLocality = 'subLocality';

  ///
  static String postalCode = 'postalCode';

  ///
  static String countryCode = 'country_code';
}
