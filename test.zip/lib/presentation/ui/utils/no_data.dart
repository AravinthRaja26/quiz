import 'package:nikitchem/gen/assets.gen.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:nikitchem/presentation/styles/text_variants.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:nikitchem/presentation/ui/utils/font_family.dart';
import 'package:flutter/material.dart';

///
class NoDataFound extends StatelessWidget {
  ///
  const NoDataFound({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Image.asset(AssetImagePath.noRecord),
          const SizedBox(
            height: 8.0,
          ),
          TextVariant(
            data: localLanguage?.keyNoDataAvailable ?? 'No Data Available',
            variantType: TextVariantType.headlineLarge,
            color: CustomColors.midBlue,
            fontFamily: FontFamily.playfairDisplay,
          )
        ],
      ),
    );
  }
}

///
class AccountNoDataFound extends StatelessWidget {
  ///
  const AccountNoDataFound({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Image.asset(Assets.images.group321.path),
          const SizedBox(
            height: 8.0,
          ),
          TextVariant(
            data: localLanguage?.keyNotFoundBank ?? 'No account found !',
            variantType: TextVariantType.headlineLarge,
            color: CustomColors.midBlue,
            textAlign: TextAlign.center,
            fontFamily: FontFamily.playfairDisplay,
          ),
          const SizedBox(
            height: 8.0,
          ),
          TextVariant(
            data: localLanguage?.keyYouDontHaveAnyBankAccountDetails ??
                'you don`t have any bank account added.',
            color: CustomColors.purpleBrown,
            fontFamily: FontFamily.quattrocentoSans,
            variantType: TextVariantType.bodyMedium,
            textAlign: TextAlign.center,
          )
        ],
      ),
    );
  }
}
