import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/infrastructure/utils/Rex.dart';
import 'package:nikitchem/infrastructure/utils/app.text.dart';

///
class AppValidation {
  static final RegExp _emailRegex = RegExp(
      r"^[a-zA-Z0-9.a-zA-Z0-9!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
  static final RegExp _ifscRegex = RegExp(r'^[A-Za-z]{4}0[A-Z0-9a-z]{6}$');

  ///
  static String? phoneValidation(String value) {
    if (value.length < 10) {
      return localLanguage?.keyValidPhoneNumber ??
          'Please enter the valid phone number';
    }
    return null;
  }

  ///
  static String? otpVerification(String value) {
    if (value.length < 4) {
      return localLanguage?.keyValidOtp ?? 'Please enter the valid OTP';
    }
    return null;
  }

  ///
  static String? userNameVerification(String value) {
    if (value == '') {
      return localLanguage?.keyValidUsername ??
          'Please enter the valid user name';
    }
    return null;
  }

  ///
  static String? panNumberVerification(String value) {
    if (value == '') {
      return localLanguage?.keyValidPanNumber ??
          'Please enter the valid pan number';
    } else if (!Rex.panCard.hasMatch(value)) {
      return localLanguage?.keyValidPanNumber ??
          'Please enter the valid pan number';
    }
    return null;
  }

  ///
  static String? accountHolderNameVerification({required String value}) {
    if (value == '' || value.length < 3) {
      return localLanguage?.keyValidPlaceholder ??
          'Please enter the valid bank holder name';
    }
    return null;
  }

  ///
  static String? accountNumberVerification({required String value}) {
    if (value.length < 8) {
      return localLanguage?.keyValidAccountNumber ??
          'Please enter the valid account number';
    }
    return null;
  }

  ///
  static String? reAccountNumberVerification(
      {required String value, required String accountNumber}) {
    if (value.length < 8) {
      return localLanguage?.keyValidAccountNumber ??
          'Please enter the valid account number';
    } else if (accountNumber != value) {
      return localLanguage?.keyNotMatchingAccountNumber ??
          'Not matching your account number';
    }
    return null;
  }

  ///
  static String? ifscCodeVerification(String value) {
    if (value.isEmpty) {
      return localLanguage?.keyEnterIfscCode ?? 'Please enter IFSC Code';
    } else if (value.isNotEmpty) {
      if (!_ifscRegex.hasMatch(value)) {
        return localLanguage?.keyValidIfscCode ??
            'Please enter valid IFSC Code';
      }
    }
    return null;
  }

  ///
  static String? bankNameVerification(String value) {
    if (value.isEmpty) {
      return localLanguage?.keyValidBankName ?? 'Please enter the bank name';
    }
    return null;
  }

  ///
  static String? commentVerification(String value) {
    if (value.isEmpty) {
      return localLanguage?.keyEnterYourComment ?? 'Please enter comment';
    }
    return null;
  }

  ///
  static String? branchNameVerification(String value) {
    if (value.isEmpty) {
      return localLanguage?.keyValidBranchName ??
          'Please enter the branch name';
    }
    return null;
  }

  ///
  static String? emailVerification(String value) {
    if (value.isNotEmpty) {
      if (!_emailRegex.hasMatch(value)) {
        return AppText.pleaseValidEmail;
      }
    } else if (value.isEmpty) {
      return AppText.pleaseValidEmail;
    }
    return null;
  }
}
