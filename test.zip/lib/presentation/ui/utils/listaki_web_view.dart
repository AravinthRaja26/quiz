import 'package:nikitchem/infrastructure/utils/web_url.dart';
import 'package:nikitchem/presentation/styles/custom_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:url_launcher/url_launcher.dart';

///
class NikitWebView extends StatefulWidget {
  ///
  final String? url;

  ///
  const NikitWebView({super.key, this.url});

  @override
  State<NikitWebView> createState() => _NikitWebViewState();
}

class _NikitWebViewState extends State<NikitWebView> {
  ///
  bool load = false;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        InAppWebView(
          onLoadStop: (_, __) {
            setState(() {
              load = false;
            });
          },
          onLoadStart: (InAppWebViewController controller, Uri? url) async {
            setState(() {
              load = true;
            });
          },
          shouldOverrideUrlLoading: (InAppWebViewController controller,
              NavigationAction navigationAction) async {
            Uri? uri = navigationAction.request.url;
            if (uri != null) {
              if (uri.toString().contains(WebUrl.aboutAppUrl) ||
                  uri.toString().contains(WebUrl.privacyPolicy) ||
                  uri.toString().contains(WebUrl.termsConditions) ||
                  uri.toString().contains(WebUrl.aboutUsUrl)) {
                return NavigationActionPolicy.ALLOW;
              } else {
                if (uri.path.contains('info@') && uri.pathSegments.isNotEmpty) {
                  Uri mailUri = Uri.parse('mailto:${uri.pathSegments.first}');
                  launchUrl(mailUri, mode: LaunchMode.externalApplication);
                } else {
                  launchUrl(uri, mode: LaunchMode.externalApplication);
                }
              }
            }
            return NavigationActionPolicy.CANCEL;
          },
          initialOptions: InAppWebViewGroupOptions(
              crossPlatform: InAppWebViewOptions(
                  useShouldOverrideUrlLoading: true,
                  transparentBackground: true)),
          initialUrlRequest: URLRequest(
            url: WebUri.uri(Uri.parse(widget.url ?? '')),
          ),
        ),
        if (load)
          const Center(
            child: CircularProgressIndicator(
              color: CustomColors.midBlue,
            ),
          )
      ],
    );
  }
}
