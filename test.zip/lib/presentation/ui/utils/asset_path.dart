///
class AssetImagePath {
  ///
  static String asLogo = 'assets/images/nikit_logo.png';

  ///
  static String downArrow = 'assets/images/down_arrow.png';

  ///
  static String phoneLoginImage = 'assets/images/group_4.png';

  ///
  static String otpVerificationImage = 'assets/images/enter_otp_cuate_1.png';

  ///
  static String profilePic = 'assets/images/profile_pic_cuate_1.png';

  ///
  static String onlineWorldRafiki = 'assets/images/online_world_rafiki.png';

  ///
  static String locationPermission = 'assets/images/location_address_cuate.png';

  ///
  static String cameraAccess = 'assets/images/camera_access.png';

  ///
  static String notificationImage = 'assets/images/group_2.png';
  ///
  static String whatsappImage = 'assets/images/whatsapp.png';

  ///
  static String personImage = 'assets/images/group_3149.png';
  ///
  static String appUpdate = 'assets/images/Frame.png';

  ///
  static String carouselImage = 'assets/images/ela_qsmk_vg_aa_dndk_1.png';

  ///
  static String rectangleImage = 'assets/images/rectangle_85.png';

  ///
  static String dashboardPersonImage = 'assets/images/person_1.png';

  ///
  static String bank = 'assets/images/bank.png';

  ///
  static String scan = 'assets/images/subtraction_11.png';

  ///
  static String home = 'assets/images/home.png';

  ///
  static String transation = 'assets/images/group_344.png';
  ///
  static String passbook = 'assets/images/group_3153.png';

  ///
  static String profile = 'assets/images/group_273.png';

  ///
  static String profile2 = 'assets/images/group_295.png';

  ///
  static String setting = 'assets/images/union_4.png';

  ///
  static String whatsapp = 'assets/images/group_272.png';

  ///
  static String bankAccount = 'assets/images/bank_2.png';

  ///
  static String about = 'assets/images/layer_2.png';

  ///
  static String language = 'assets/images/language.png';

  ///
  static String email = 'assets/images/email.png';

  ///
  static String customerService = 'assets/images/customer_service.png';

  ///
  static String security = 'assets/images/security.png';

  ///
  static String scanCouponSuccess = 'assets/images/coupon_code_success.png';

  ///
  static String tickets = 'assets/images/tickets_1.png';

  ///
  static String message = 'assets/images/b.png';

  ///
  static String manageAccount = 'assets/images/subtraction_3.png';

  ///
  static String timeOut = 'assets/images/time_out.png';

  ///
  static String delete = 'assets/images/trash_bin.png';

  ///
  static String earned = 'assets/images/saving_1.png';

  ///
  static String qrCode = 'assets/images/qr_1.png';

  ///
  static String redeemed = 'assets/images/layer_30.png';

  ///
  static String expired = 'assets/images/layer_14.png';

  ///
  static String expired1 = 'assets/images/expired_1.png';

  ///
  static String verified = 'assets/images/shield.png';

  ///
  static String ticket = 'assets/images/group_336.png';

  ///
  static String qrDim = 'assets/images/qr_dim.png';

  ///
  static String noRecord = 'assets/images/no_data_cuate.png';

  ///
  static String qrDetails = 'assets/images/qr.png';

  ///
  static String redeemedTicket = 'assets/images/group_352.png';

  ///
  static String ticketDetails = 'assets/images/group_353.png';

  ///
  static String endUser = 'assets/images/end_user_issue.png';

  ///
  static String allTicket = 'assets/images/all_ticket.png';

  ///
  static String resolved = 'assets/images/group_354.png';

  ///
  static String openTicket = 'assets/images/union_3.png';

  ///
  static String loginSuccess = 'assets/images/login_success.png';

  ///
  static String forbidden = 'assets/images/forbidden.png';

  ///
  static String arrow = 'assets/images/subtraction_7.png';

  ///
  static String walletSuccess = 'assets/images/group_307.png';

  ///
  static String noNotification = 'assets/images/no_notification.png';

  ///
  static String successful = 'assets/images/group_321.png';

  ///
  static String ticketCreated = 'assets/images/group_322.png';

  ///
  static String congratulations = 'assets/images/group_337.png';

  ///
  static String failure = 'assets/images/group_338.png';

  ///
  static String offline = 'assets/images/your_offline.png';

  ///
  static String wrapQR = 'assets/images/subtraction_9.png';
}
