import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/data/models/consumer/consumer_transaction.model.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:flutter/cupertino.dart';
import 'package:injectable/injectable.dart';

///
@injectable
class AppNavigation {
  ///
  Future<void> navigationToLoginScreen(BuildContext context, {String? phoneNumber}) async {
    await AutoRouter.of(context)
        .pushAndPopUntil(const LoginScreen(), predicate: (_) => false);
  }

  ///
  Future<void> navigationToOtpVerification(BuildContext context, String phoneNumber)async  {
    await AutoRouter.of(context)
        .push(OtpVerificationScreen(phoneNumber: phoneNumber));
  }

  ///
  Future<void> navigationToLanguage(BuildContext context) async {
    await AutoRouter.of(context).push(const LanguageScreen());
  }
  ///
  Future<void> navigationToForgetPassword(BuildContext context) async {
    await AutoRouter.of(context).push(const ForgetPasswordScreen());
  }

  ///
  Future<void> navigationToManageBankAccountScreen(
    BuildContext context,
  ) async {
    await AutoRouter.of(context).push(const ManageBankAccountScreen());
  }

  ///
  Future<void> navigationToContactScreen(
    BuildContext context,
  ) async {
    await AutoRouter.of(context).push(const ContactScreen());
  }

  ///
  Future<void> navigationToNotificationScreen(
    BuildContext context,
  ) async{
    await AutoRouter.of(context).push(const NotificationScreen());
  } ///
  ///
  Future<void> navigationToProfileScreen(
      BuildContext context,
      ) async{
    await AutoRouter.of(context).push(const ProfileScreen());
  }

  ///
  Future<void> navigationToBankTransferScreen(
    BuildContext context,
  ) async {
    await AutoRouter.of(context).push(const BankTransferScreen());
  }

  ///
  Future<void> navigationToSupportScreen(
    BuildContext context,
  ) async {
    await AutoRouter.of(context).push(const SupportScreen());
  }

  ///
  Future<void> navigationToSupportIssueScreen(
    BuildContext context,
  )async  {
    await AutoRouter.of(context).push(const SupportIssueScreen());
  }

  ///
  Future<void> navigationToAboutScreen(
    BuildContext context,
  ) async {
    await AutoRouter.of(context).push(const AboutScreen());
  }

  ///
  Future<void> navigationToTermsAndConditionScreen(
    BuildContext context,
  )async  {
    await AutoRouter.of(context).push(const TermsAndConditionScreen());
  }

  ///
  Future<void> navigationToPrivacyScreen(
    BuildContext context,
  ) async {
    await AutoRouter.of(context).push(const PrivacyPolicyScreen());
  }

  ///
  Future<void> navigationToTicketDetailScreen(
    BuildContext context,
    String ticketId,
  )async  {
    await AutoRouter.of(context).push(TicketDetailScreen(ticketId: ticketId));
  }

  ///
  Future<void> navigationToTicketListScreen(
    BuildContext context,
  ) async {
    await AutoRouter.of(context).push(const TicketListScreen());
  }

  ///
  Future<void> navigationToTutorial(
    BuildContext context,
  )async  {
    await AutoRouter.of(context)
        .pushAndPopUntil(const TutorialScreen(), predicate: (_) => false);
  }

  ///
  Future<void> navigationToScannerScreen(
    BuildContext context,
  )async  {
    await AutoRouter.of(context).push(const ScanScreen());
  }

  ///
  Future<void> navigationToEarnedDetailScreen(
    BuildContext context,
    Earned? consumerEarnedDetails,
  ) async {
    await AutoRouter.of(context)
        .push(CouponDetailScreen(consumerEarnedDetails: consumerEarnedDetails));
  }

  ///
  Future<void> navigationToExpiredDetailScreen(
    BuildContext context,
    Expired? consumerExpiredDetails,
  )async  {
    await AutoRouter.of(context).push(
        CouponDetailScreen(consumerExpiredDetails: consumerExpiredDetails));
  }

  ///
  Future<void> navigationToCouponCodeScreen(
    BuildContext context,
  ) async{
    await AutoRouter.of(context).push(const CouponScreen());
  }

  ///
  Future<void> navigationToNetWorkScreen(
    BuildContext context,
  ) async {
    AutoRouter.of(context).push(const NetworkScreen());
  }

  ///
  Future<void> userProfile(BuildContext context) async {
    await AutoRouter.of(context)
        .pushAndPopUntil(const UserProfileScreen(), predicate: (_) => false);
  }

  ///
  Future<void> toHomeScreen(BuildContext context, {bool? isShowSuccessAlert})async  {
    await AutoRouter.of(context).pushAndPopUntil(
        MainScreen(comesToUserProfile: isShowSuccessAlert),
        predicate: (_) => false);
  }
}
