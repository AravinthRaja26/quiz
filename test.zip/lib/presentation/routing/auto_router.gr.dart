// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:auto_route/auto_route.dart' as _i33;
import 'package:flutter/material.dart' as _i34;
import 'package:nikitchem/data/models/consumer/consumer_transaction.model.dart'
    as _i35;
import 'package:nikitchem/presentation/ui/custom_widget/api_success_screen.dart'
    as _i2;
import 'package:nikitchem/presentation/ui/custom_widget/force_update_screen.dart'
    as _i8;
import 'package:nikitchem/presentation/ui/views/screens/about_us/about_us.screen.dart'
    as _i1;
import 'package:nikitchem/presentation/ui/views/screens/auth/forget_screen.dart'
    as _i9;
import 'package:nikitchem/presentation/ui/views/screens/auth/login_screen.dart'
    as _i11;
import 'package:nikitchem/presentation/ui/views/screens/auth/otp_verification_screen.dart'
    as _i16;
import 'package:nikitchem/presentation/ui/views/screens/bank_transfer/bank_transfer.dart'
    as _i3;
import 'package:nikitchem/presentation/ui/views/screens/contact_us/contact_us.screen.dart'
    as _i4;
import 'package:nikitchem/presentation/ui/views/screens/coupon/coupon.screen.dart'
    as _i6;
import 'package:nikitchem/presentation/ui/views/screens/coupon/coupon_details.screen.dart'
    as _i5;
import 'package:nikitchem/presentation/ui/views/screens/language/language_screen.dart'
    as _i10;
import 'package:nikitchem/presentation/ui/views/screens/main/dashboard/index.dart'
    as _i7;
import 'package:nikitchem/presentation/ui/views/screens/main/index.dart'
    as _i12;
import 'package:nikitchem/presentation/ui/views/screens/main/passbook/index.dart'
    as _i17;
import 'package:nikitchem/presentation/ui/views/screens/main/profile/index.dart'
    as _i19;
import 'package:nikitchem/presentation/ui/views/screens/main/quiz/quiz_screen.dart'
    as _i20;
import 'package:nikitchem/presentation/ui/views/screens/main/settings/index.dart'
    as _i22;
import 'package:nikitchem/presentation/ui/views/screens/main/transactions/index.dart'
    as _i29;
import 'package:nikitchem/presentation/ui/views/screens/main/whatsapp/index.dart'
    as _i32;
import 'package:nikitchem/presentation/ui/views/screens/manage_bank_account/manage_bank_account.screen.dart'
    as _i13;
import 'package:nikitchem/presentation/ui/views/screens/network/network_screen.dart'
    as _i14;
import 'package:nikitchem/presentation/ui/views/screens/notification/notification.screen.dart'
    as _i15;
import 'package:nikitchem/presentation/ui/views/screens/privacy_policy/privacy_policy.screen.dart'
    as _i18;
import 'package:nikitchem/presentation/ui/views/screens/scan/scan_screen.dart'
    as _i21;
import 'package:nikitchem/presentation/ui/views/screens/splash_screen/splsh_screen.dart'
    as _i23;
import 'package:nikitchem/presentation/ui/views/screens/support/support.screen.dart'
    as _i25;
import 'package:nikitchem/presentation/ui/views/screens/support/support_issue.dart'
    as _i24;
import 'package:nikitchem/presentation/ui/views/screens/terms_condition/terms_condition.screen.dart'
    as _i26;
import 'package:nikitchem/presentation/ui/views/screens/ticket_details/ticket_details.screen.dart'
    as _i27;
import 'package:nikitchem/presentation/ui/views/screens/ticket_details/ticket_list.screen.dart'
    as _i28;
import 'package:nikitchem/presentation/ui/views/screens/tutorial/tutorial_screen.dart'
    as _i30;
import 'package:nikitchem/presentation/ui/views/screens/use_profile/user_profile_screen.dart'
    as _i31;

/// generated route for
/// [_i1.AboutScreen]
class AboutScreen extends _i33.PageRouteInfo<void> {
  const AboutScreen({List<_i33.PageRouteInfo>? children})
      : super(
          AboutScreen.name,
          initialChildren: children,
        );

  static const String name = 'AboutScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i1.AboutScreen();
    },
  );
}

/// generated route for
/// [_i2.ApiSuccessScreen]
class ApiSuccessScreen extends _i33.PageRouteInfo<ApiSuccessScreenArgs> {
  ApiSuccessScreen({
    _i34.Key? key,
    String? image,
    String? title,
    String? subTitle,
    String? buttonName,
    _i34.GestureTapCallback? onTap,
    bool? isScanScreen,
    List<_i33.PageRouteInfo>? children,
  }) : super(
          ApiSuccessScreen.name,
          args: ApiSuccessScreenArgs(
            key: key,
            image: image,
            title: title,
            subTitle: subTitle,
            buttonName: buttonName,
            onTap: onTap,
            isScanScreen: isScanScreen,
          ),
          initialChildren: children,
        );

  static const String name = 'ApiSuccessScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<ApiSuccessScreenArgs>(
          orElse: () => const ApiSuccessScreenArgs());
      return _i2.ApiSuccessScreen(
        key: args.key,
        image: args.image,
        title: args.title,
        subTitle: args.subTitle,
        buttonName: args.buttonName,
        onTap: args.onTap,
        isScanScreen: args.isScanScreen,
      );
    },
  );
}

class ApiSuccessScreenArgs {
  const ApiSuccessScreenArgs({
    this.key,
    this.image,
    this.title,
    this.subTitle,
    this.buttonName,
    this.onTap,
    this.isScanScreen,
  });

  final _i34.Key? key;

  final String? image;

  final String? title;

  final String? subTitle;

  final String? buttonName;

  final _i34.GestureTapCallback? onTap;

  final bool? isScanScreen;

  @override
  String toString() {
    return 'ApiSuccessScreenArgs{key: $key, image: $image, title: $title, subTitle: $subTitle, buttonName: $buttonName, onTap: $onTap, isScanScreen: $isScanScreen}';
  }
}

/// generated route for
/// [_i3.BankTransferScreen]
class BankTransferScreen extends _i33.PageRouteInfo<void> {
  const BankTransferScreen({List<_i33.PageRouteInfo>? children})
      : super(
          BankTransferScreen.name,
          initialChildren: children,
        );

  static const String name = 'BankTransferScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i3.BankTransferScreen();
    },
  );
}

/// generated route for
/// [_i4.ContactScreen]
class ContactScreen extends _i33.PageRouteInfo<void> {
  const ContactScreen({List<_i33.PageRouteInfo>? children})
      : super(
          ContactScreen.name,
          initialChildren: children,
        );

  static const String name = 'ContactScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i4.ContactScreen();
    },
  );
}

/// generated route for
/// [_i5.CouponDetailScreen]
class CouponDetailScreen extends _i33.PageRouteInfo<CouponDetailScreenArgs> {
  CouponDetailScreen({
    _i34.Key? key,
    _i35.Earned? consumerEarnedDetails,
    _i35.Expired? consumerExpiredDetails,
    List<_i33.PageRouteInfo>? children,
  }) : super(
          CouponDetailScreen.name,
          args: CouponDetailScreenArgs(
            key: key,
            consumerEarnedDetails: consumerEarnedDetails,
            consumerExpiredDetails: consumerExpiredDetails,
          ),
          initialChildren: children,
        );

  static const String name = 'CouponDetailScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<CouponDetailScreenArgs>(
          orElse: () => const CouponDetailScreenArgs());
      return _i5.CouponDetailScreen(
        key: args.key,
        consumerEarnedDetails: args.consumerEarnedDetails,
        consumerExpiredDetails: args.consumerExpiredDetails,
      );
    },
  );
}

class CouponDetailScreenArgs {
  const CouponDetailScreenArgs({
    this.key,
    this.consumerEarnedDetails,
    this.consumerExpiredDetails,
  });

  final _i34.Key? key;

  final _i35.Earned? consumerEarnedDetails;

  final _i35.Expired? consumerExpiredDetails;

  @override
  String toString() {
    return 'CouponDetailScreenArgs{key: $key, consumerEarnedDetails: $consumerEarnedDetails, consumerExpiredDetails: $consumerExpiredDetails}';
  }
}

/// generated route for
/// [_i6.CouponScreen]
class CouponScreen extends _i33.PageRouteInfo<void> {
  const CouponScreen({List<_i33.PageRouteInfo>? children})
      : super(
          CouponScreen.name,
          initialChildren: children,
        );

  static const String name = 'CouponScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i6.CouponScreen();
    },
  );
}

/// generated route for
/// [_i7.DashBoard]
class DashboardScreen extends _i33.PageRouteInfo<void> {
  const DashboardScreen({List<_i33.PageRouteInfo>? children})
      : super(
          DashboardScreen.name,
          initialChildren: children,
        );

  static const String name = 'DashboardScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i7.DashBoard();
    },
  );
}

/// generated route for
/// [_i8.ForceUpdateScreen]
class ForceUpdateScreen extends _i33.PageRouteInfo<ForceUpdateScreenArgs> {
  ForceUpdateScreen({
    _i34.Key? key,
    String? image,
    String? title,
    String? subTitle,
    String? buttonName,
    _i34.GestureTapCallback? onTap,
    bool? isScanScreen,
    List<_i33.PageRouteInfo>? children,
  }) : super(
          ForceUpdateScreen.name,
          args: ForceUpdateScreenArgs(
            key: key,
            image: image,
            title: title,
            subTitle: subTitle,
            buttonName: buttonName,
            onTap: onTap,
            isScanScreen: isScanScreen,
          ),
          initialChildren: children,
        );

  static const String name = 'ForceUpdateScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<ForceUpdateScreenArgs>(
          orElse: () => const ForceUpdateScreenArgs());
      return _i8.ForceUpdateScreen(
        key: args.key,
        image: args.image,
        title: args.title,
        subTitle: args.subTitle,
        buttonName: args.buttonName,
        onTap: args.onTap,
        isScanScreen: args.isScanScreen,
      );
    },
  );
}

class ForceUpdateScreenArgs {
  const ForceUpdateScreenArgs({
    this.key,
    this.image,
    this.title,
    this.subTitle,
    this.buttonName,
    this.onTap,
    this.isScanScreen,
  });

  final _i34.Key? key;

  final String? image;

  final String? title;

  final String? subTitle;

  final String? buttonName;

  final _i34.GestureTapCallback? onTap;

  final bool? isScanScreen;

  @override
  String toString() {
    return 'ForceUpdateScreenArgs{key: $key, image: $image, title: $title, subTitle: $subTitle, buttonName: $buttonName, onTap: $onTap, isScanScreen: $isScanScreen}';
  }
}

/// generated route for
/// [_i9.ForgetPasswordScreen]
class ForgetPasswordScreen extends _i33.PageRouteInfo<void> {
  const ForgetPasswordScreen({List<_i33.PageRouteInfo>? children})
      : super(
          ForgetPasswordScreen.name,
          initialChildren: children,
        );

  static const String name = 'ForgetPasswordScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i9.ForgetPasswordScreen();
    },
  );
}

/// generated route for
/// [_i10.LanguageScreen]
class LanguageScreen extends _i33.PageRouteInfo<void> {
  const LanguageScreen({List<_i33.PageRouteInfo>? children})
      : super(
          LanguageScreen.name,
          initialChildren: children,
        );

  static const String name = 'LanguageScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i10.LanguageScreen();
    },
  );
}

/// generated route for
/// [_i11.LoginScreen]
class LoginScreen extends _i33.PageRouteInfo<void> {
  const LoginScreen({List<_i33.PageRouteInfo>? children})
      : super(
          LoginScreen.name,
          initialChildren: children,
        );

  static const String name = 'LoginScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i11.LoginScreen();
    },
  );
}

/// generated route for
/// [_i12.MainScreen]
class MainScreen extends _i33.PageRouteInfo<MainScreenArgs> {
  MainScreen({
    _i34.Key? key,
    bool? comesToUserProfile,
    List<_i33.PageRouteInfo>? children,
  }) : super(
          MainScreen.name,
          args: MainScreenArgs(
            key: key,
            comesToUserProfile: comesToUserProfile,
          ),
          initialChildren: children,
        );

  static const String name = 'MainScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      final args =
          data.argsAs<MainScreenArgs>(orElse: () => const MainScreenArgs());
      return _i12.MainScreen(
        key: args.key,
        comesToUserProfile: args.comesToUserProfile,
      );
    },
  );
}

class MainScreenArgs {
  const MainScreenArgs({
    this.key,
    this.comesToUserProfile,
  });

  final _i34.Key? key;

  final bool? comesToUserProfile;

  @override
  String toString() {
    return 'MainScreenArgs{key: $key, comesToUserProfile: $comesToUserProfile}';
  }
}

/// generated route for
/// [_i13.ManageBankAccountScreen]
class ManageBankAccountScreen extends _i33.PageRouteInfo<void> {
  const ManageBankAccountScreen({List<_i33.PageRouteInfo>? children})
      : super(
          ManageBankAccountScreen.name,
          initialChildren: children,
        );

  static const String name = 'ManageBankAccountScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i13.ManageBankAccountScreen();
    },
  );
}

/// generated route for
/// [_i14.NetworkScreen]
class NetworkScreen extends _i33.PageRouteInfo<void> {
  const NetworkScreen({List<_i33.PageRouteInfo>? children})
      : super(
          NetworkScreen.name,
          initialChildren: children,
        );

  static const String name = 'NetworkScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i14.NetworkScreen();
    },
  );
}

/// generated route for
/// [_i15.NotificationScreen]
class NotificationScreen extends _i33.PageRouteInfo<void> {
  const NotificationScreen({List<_i33.PageRouteInfo>? children})
      : super(
          NotificationScreen.name,
          initialChildren: children,
        );

  static const String name = 'NotificationScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i15.NotificationScreen();
    },
  );
}

/// generated route for
/// [_i16.OtpVerificationScreen]
class OtpVerificationScreen
    extends _i33.PageRouteInfo<OtpVerificationScreenArgs> {
  OtpVerificationScreen({
    _i34.Key? key,
    String? phoneNumber,
    List<_i33.PageRouteInfo>? children,
  }) : super(
          OtpVerificationScreen.name,
          args: OtpVerificationScreenArgs(
            key: key,
            phoneNumber: phoneNumber,
          ),
          initialChildren: children,
        );

  static const String name = 'OtpVerificationScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<OtpVerificationScreenArgs>(
          orElse: () => const OtpVerificationScreenArgs());
      return _i16.OtpVerificationScreen(
        key: args.key,
        phoneNumber: args.phoneNumber,
      );
    },
  );
}

class OtpVerificationScreenArgs {
  const OtpVerificationScreenArgs({
    this.key,
    this.phoneNumber,
  });

  final _i34.Key? key;

  final String? phoneNumber;

  @override
  String toString() {
    return 'OtpVerificationScreenArgs{key: $key, phoneNumber: $phoneNumber}';
  }
}

/// generated route for
/// [_i17.PassbookScreen]
class PassbookScreen extends _i33.PageRouteInfo<void> {
  const PassbookScreen({List<_i33.PageRouteInfo>? children})
      : super(
          PassbookScreen.name,
          initialChildren: children,
        );

  static const String name = 'PassbookScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i17.PassbookScreen();
    },
  );
}

/// generated route for
/// [_i18.PrivacyPolicyScreen]
class PrivacyPolicyScreen extends _i33.PageRouteInfo<void> {
  const PrivacyPolicyScreen({List<_i33.PageRouteInfo>? children})
      : super(
          PrivacyPolicyScreen.name,
          initialChildren: children,
        );

  static const String name = 'PrivacyPolicyScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i18.PrivacyPolicyScreen();
    },
  );
}

/// generated route for
/// [_i19.ProfileScreen]
class ProfileScreen extends _i33.PageRouteInfo<void> {
  const ProfileScreen({List<_i33.PageRouteInfo>? children})
      : super(
          ProfileScreen.name,
          initialChildren: children,
        );

  static const String name = 'ProfileScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i19.ProfileScreen();
    },
  );
}

/// generated route for
/// [_i20.QuizScreen]
class QuizScreen extends _i33.PageRouteInfo<void> {
  const QuizScreen({List<_i33.PageRouteInfo>? children})
      : super(
          QuizScreen.name,
          initialChildren: children,
        );

  static const String name = 'QuizScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i20.QuizScreen();
    },
  );
}

/// generated route for
/// [_i21.ScanScreen]
class ScanScreen extends _i33.PageRouteInfo<void> {
  const ScanScreen({List<_i33.PageRouteInfo>? children})
      : super(
          ScanScreen.name,
          initialChildren: children,
        );

  static const String name = 'ScanScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i21.ScanScreen();
    },
  );
}

/// generated route for
/// [_i22.SettingScreen]
class SettingScreen extends _i33.PageRouteInfo<void> {
  const SettingScreen({List<_i33.PageRouteInfo>? children})
      : super(
          SettingScreen.name,
          initialChildren: children,
        );

  static const String name = 'SettingScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i22.SettingScreen();
    },
  );
}

/// generated route for
/// [_i23.SplashScreen]
class SplashScreen extends _i33.PageRouteInfo<void> {
  const SplashScreen({List<_i33.PageRouteInfo>? children})
      : super(
          SplashScreen.name,
          initialChildren: children,
        );

  static const String name = 'SplashScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i23.SplashScreen();
    },
  );
}

/// generated route for
/// [_i24.SupportIssueScreen]
class SupportIssueScreen extends _i33.PageRouteInfo<void> {
  const SupportIssueScreen({List<_i33.PageRouteInfo>? children})
      : super(
          SupportIssueScreen.name,
          initialChildren: children,
        );

  static const String name = 'SupportIssueScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i24.SupportIssueScreen();
    },
  );
}

/// generated route for
/// [_i25.SupportScreen]
class SupportScreen extends _i33.PageRouteInfo<void> {
  const SupportScreen({List<_i33.PageRouteInfo>? children})
      : super(
          SupportScreen.name,
          initialChildren: children,
        );

  static const String name = 'SupportScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i25.SupportScreen();
    },
  );
}

/// generated route for
/// [_i26.TermsAndConditionScreen]
class TermsAndConditionScreen extends _i33.PageRouteInfo<void> {
  const TermsAndConditionScreen({List<_i33.PageRouteInfo>? children})
      : super(
          TermsAndConditionScreen.name,
          initialChildren: children,
        );

  static const String name = 'TermsAndConditionScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i26.TermsAndConditionScreen();
    },
  );
}

/// generated route for
/// [_i27.TicketDetailScreen]
class TicketDetailScreen extends _i33.PageRouteInfo<TicketDetailScreenArgs> {
  TicketDetailScreen({
    _i34.Key? key,
    required String ticketId,
    List<_i33.PageRouteInfo>? children,
  }) : super(
          TicketDetailScreen.name,
          args: TicketDetailScreenArgs(
            key: key,
            ticketId: ticketId,
          ),
          initialChildren: children,
        );

  static const String name = 'TicketDetailScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<TicketDetailScreenArgs>();
      return _i27.TicketDetailScreen(
        key: args.key,
        ticketId: args.ticketId,
      );
    },
  );
}

class TicketDetailScreenArgs {
  const TicketDetailScreenArgs({
    this.key,
    required this.ticketId,
  });

  final _i34.Key? key;

  final String ticketId;

  @override
  String toString() {
    return 'TicketDetailScreenArgs{key: $key, ticketId: $ticketId}';
  }
}

/// generated route for
/// [_i28.TicketListScreen]
class TicketListScreen extends _i33.PageRouteInfo<void> {
  const TicketListScreen({List<_i33.PageRouteInfo>? children})
      : super(
          TicketListScreen.name,
          initialChildren: children,
        );

  static const String name = 'TicketListScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i28.TicketListScreen();
    },
  );
}

/// generated route for
/// [_i2.TransactionErrorScreen]
class TransactionErrorScreen
    extends _i33.PageRouteInfo<TransactionErrorScreenArgs> {
  TransactionErrorScreen({
    _i34.Key? key,
    String? image,
    String? title,
    bool? isScanNewButton,
    String? subTitle,
    String? buttonName,
    _i34.GestureTapCallback? onTap,
    bool? isScanScreen,
    String? enteredValue,
    List<_i33.PageRouteInfo>? children,
  }) : super(
          TransactionErrorScreen.name,
          args: TransactionErrorScreenArgs(
            key: key,
            image: image,
            title: title,
            isScanNewButton: isScanNewButton,
            subTitle: subTitle,
            buttonName: buttonName,
            onTap: onTap,
            isScanScreen: isScanScreen,
            enteredValue: enteredValue,
          ),
          initialChildren: children,
        );

  static const String name = 'TransactionErrorScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<TransactionErrorScreenArgs>(
          orElse: () => const TransactionErrorScreenArgs());
      return _i2.TransactionErrorScreen(
        key: args.key,
        image: args.image,
        title: args.title,
        isScanNewButton: args.isScanNewButton,
        subTitle: args.subTitle,
        buttonName: args.buttonName,
        onTap: args.onTap,
        isScanScreen: args.isScanScreen,
        enteredValue: args.enteredValue,
      );
    },
  );
}

class TransactionErrorScreenArgs {
  const TransactionErrorScreenArgs({
    this.key,
    this.image,
    this.title,
    this.isScanNewButton,
    this.subTitle,
    this.buttonName,
    this.onTap,
    this.isScanScreen,
    this.enteredValue,
  });

  final _i34.Key? key;

  final String? image;

  final String? title;

  final bool? isScanNewButton;

  final String? subTitle;

  final String? buttonName;

  final _i34.GestureTapCallback? onTap;

  final bool? isScanScreen;

  final String? enteredValue;

  @override
  String toString() {
    return 'TransactionErrorScreenArgs{key: $key, image: $image, title: $title, isScanNewButton: $isScanNewButton, subTitle: $subTitle, buttonName: $buttonName, onTap: $onTap, isScanScreen: $isScanScreen, enteredValue: $enteredValue}';
  }
}

/// generated route for
/// [_i29.TransactionScreen]
class TransactionScreen extends _i33.PageRouteInfo<void> {
  const TransactionScreen({List<_i33.PageRouteInfo>? children})
      : super(
          TransactionScreen.name,
          initialChildren: children,
        );

  static const String name = 'TransactionScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i29.TransactionScreen();
    },
  );
}

/// generated route for
/// [_i30.TutorialScreen]
class TutorialScreen extends _i33.PageRouteInfo<void> {
  const TutorialScreen({List<_i33.PageRouteInfo>? children})
      : super(
          TutorialScreen.name,
          initialChildren: children,
        );

  static const String name = 'TutorialScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i30.TutorialScreen();
    },
  );
}

/// generated route for
/// [_i31.UserProfileScreen]
class UserProfileScreen extends _i33.PageRouteInfo<void> {
  const UserProfileScreen({List<_i33.PageRouteInfo>? children})
      : super(
          UserProfileScreen.name,
          initialChildren: children,
        );

  static const String name = 'UserProfileScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i31.UserProfileScreen();
    },
  );
}

/// generated route for
/// [_i32.WhatsappScreen]
class WhatsappScreen extends _i33.PageRouteInfo<void> {
  const WhatsappScreen({List<_i33.PageRouteInfo>? children})
      : super(
          WhatsappScreen.name,
          initialChildren: children,
        );

  static const String name = 'WhatsappScreen';

  static _i33.PageInfo page = _i33.PageInfo(
    name,
    builder: (data) {
      return const _i32.WhatsappScreen();
    },
  );
}
