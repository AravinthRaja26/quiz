import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/presentation/routing/guard/tutorial_guard.dart';
import 'auto_router.gr.dart';

///
/// AppRouter class
///
@AutoRouterConfig(replaceInRouteName: 'Route')
class AppRouter extends RootStackRouter {


  @override
  RouteType get defaultRouteType => const RouteType.material();

  @override
  List<AutoRoute> get routes => <CupertinoRoute>[
        CupertinoRoute(
            page: MainScreen.page,
            path: '/home',
            children: <CupertinoRoute>[
              CupertinoRoute(
                page: DashboardScreen.page,
                path: 'dashboard',
                keepHistory: true,
              ),
              CupertinoRoute(
                  page: SettingScreen.page,
                  path: 'settings',
                  keepHistory: true),
              CupertinoRoute(
                  page: TransactionScreen.page,
                  path: 'transactions',
                  keepHistory: true),
              CupertinoRoute(
                  page: PassbookScreen.page,
                  path: 'passbookScreen',
                  keepHistory: true),
              CupertinoRoute(
                  page: WhatsappScreen.page,
                  path: 'whatsapp',
                  keepHistory: true)
            ],
            keepHistory: true),
        CupertinoRoute(
            page: TutorialScreen.page,
            path: '/tutorial_screen',
            guards: <AutoRouteGuard>[TutorialGuard()],
            keepHistory: true),
    CupertinoRoute(
            page: QuizScreen.page,
            path: '/',
            initial: true,
            keepHistory: true),
        CupertinoRoute(
            page: SplashScreen.page,
            path: '/splash',
            keepHistory: true,
            ),
        CupertinoRoute(
            page: ProfileScreen.page, path: '/profile', keepHistory: true),
        CupertinoRoute(
            page: LoginScreen.page, path: '/login_screen', keepHistory: true),
        CupertinoRoute(
            page: OtpVerificationScreen.page,
            path: '/otpVerification_screen',
            keepHistory: true),
        CupertinoRoute(
            page: ScanScreen.page, path: '/scanScreen', keepHistory: true),
        CupertinoRoute(
            page: ManageBankAccountScreen.page,
            path: '/manageBankAccountScreen',
            keepHistory: true),
        CupertinoRoute(
            page: TransactionErrorScreen.page,
            path: '/transactionErrorScreen',
            keepHistory: true),
        CupertinoRoute(
            page: ContactScreen.page,
            path: '/contactScreen',
            keepHistory: true),
        CupertinoRoute(
            page: AboutScreen.page, path: '/aboutScreen', keepHistory: true),
        CupertinoRoute(
          page: NotificationScreen.page,
          path: '/notificationScreen',
          keepHistory: true,
        ),
        CupertinoRoute(
            page: PrivacyPolicyScreen.page,
            path: '/privacyPolicyScreen',
            keepHistory: true),
        CupertinoRoute(
            page: SupportScreen.page,
            path: '/supportScreen',
            keepHistory: true),
        CupertinoRoute(
            page: SupportIssueScreen.page,
            path: '/SupportIssueScreen',
            keepHistory: true),
        CupertinoRoute(
            page: LanguageScreen.page,
            path: '/language_screen',
            keepHistory: true),
        CupertinoRoute(
            page: TermsAndConditionScreen.page,
            path: '/termsAndConditionScreen',
            keepHistory: true),
        CupertinoRoute(
            page: ForceUpdateScreen.page,
            path: '/force_update_screen',
            keepHistory: true),
        CupertinoRoute(
            page: TicketDetailScreen.page,
            path: '/ticketDetailScreen',
            keepHistory: true),
        CupertinoRoute(
            page: TicketListScreen.page,
            path: '/ticketListScreen',
            keepHistory: true),
        CupertinoRoute(
            page: ForgetPasswordScreen.page,
            path: '/forgetPasswordScreen',
            keepHistory: true),
        CupertinoRoute(
            page: CouponScreen.page,
            path: '/couponScreen', keepHistory: true),
        CupertinoRoute(
            page: CouponDetailScreen.page,
            path: '/couponDetailScreen',
            keepHistory: true),
        CupertinoRoute(
            page: ScanScreen.page, path: '/scanScreen', keepHistory: true),
        CupertinoRoute(
          page: UserProfileScreen.page,
          path: '/user_profile_screen',
          keepHistory: true,
        ),
        CupertinoRoute(
          page: ApiSuccessScreen.page,
          path: '/api_success_screen',
          keepHistory: true,
        ),
        CupertinoRoute(
            page: NetworkScreen.page,
            path: '/networkScreen',
            keepHistory: true),
        CupertinoRoute(
            page: BankTransferScreen.page,
            path: '/bankTransferScreen',
            keepHistory: true),
      ];
}
