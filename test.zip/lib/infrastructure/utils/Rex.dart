///
class Rex {
  ///
  static RegExp panCard = RegExp(r"^[A-Z]{5}[0-9]{4}[A-Z]{1}$");

}
