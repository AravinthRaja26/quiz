import 'package:nikitchem/data/models/language_model/local_language.dart';

///
LocalLanguage? localLanguage = LocalLanguage();
