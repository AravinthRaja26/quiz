/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: directives_ordering,unnecessary_import,implicit_dynamic_list_literal,deprecated_member_use

class FontFamily {
  FontFamily._();

  /// Font family: PlayfairDisplay
  static const String playfairDisplay = 'PlayfairDisplay';

  /// Font family: Poppins
  static const String poppins = 'Poppins';

  /// Font family: QuattrocentoSans
  static const String quattrocentoSans = 'QuattrocentoSans';
}
