/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: directives_ordering,unnecessary_import,implicit_dynamic_list_literal,deprecated_member_use

import 'package:flutter/widgets.dart';

class $AssetsImagesGen {
  const $AssetsImagesGen();

  /// File path: assets/images/Frame.png
  AssetGenImage get frame => const AssetGenImage('assets/images/Frame.png');

  /// File path: assets/images/active_support_cuate.png
  AssetGenImage get activeSupportCuate =>
      const AssetGenImage('assets/images/active_support_cuate.png');

  /// File path: assets/images/all_ticket.png
  AssetGenImage get allTicket =>
      const AssetGenImage('assets/images/all_ticket.png');

  /// File path: assets/images/already_scan.png
  AssetGenImage get alreadyScan =>
      const AssetGenImage('assets/images/already_scan.png');

  /// File path: assets/images/app_update.png
  AssetGenImage get appUpdate =>
      const AssetGenImage('assets/images/app_update.png');

  /// File path: assets/images/approval_submitted.png
  AssetGenImage get approvalSubmitted =>
      const AssetGenImage('assets/images/approval_submitted.png');

  /// File path: assets/images/aslogo_1.png
  AssetGenImage get aslogo1 =>
      const AssetGenImage('assets/images/aslogo_1.png');

  /// File path: assets/images/b.png
  AssetGenImage get b => const AssetGenImage('assets/images/b.png');

  /// File path: assets/images/ban_account_add_success.png
  AssetGenImage get banAccountAddSuccess =>
      const AssetGenImage('assets/images/ban_account_add_success.png');

  /// File path: assets/images/bank.png
  AssetGenImage get bank => const AssetGenImage('assets/images/bank.png');

  /// File path: assets/images/bank_2.png
  AssetGenImage get bank2 => const AssetGenImage('assets/images/bank_2.png');

  /// File path: assets/images/bank_account_add_success.png
  AssetGenImage get bankAccountAddSuccess =>
      const AssetGenImage('assets/images/bank_account_add_success.png');

  /// File path: assets/images/bank_faliure.png
  AssetGenImage get bankFaliure =>
      const AssetGenImage('assets/images/bank_faliure.png');

  /// File path: assets/images/camera_access.png
  AssetGenImage get cameraAccess =>
      const AssetGenImage('assets/images/camera_access.png');

  /// File path: assets/images/coupon_code_success.png
  AssetGenImage get couponCodeSuccess =>
      const AssetGenImage('assets/images/coupon_code_success.png');

  /// File path: assets/images/customer_service.png
  AssetGenImage get customerService =>
      const AssetGenImage('assets/images/customer_service.png');

  /// File path: assets/images/dashboard.png
  AssetGenImage get dashboard =>
      const AssetGenImage('assets/images/dashboard.png');

  /// File path: assets/images/delete_bank_account.png
  AssetGenImage get deleteBankAccount =>
      const AssetGenImage('assets/images/delete_bank_account.png');

  /// File path: assets/images/down_arrow.png
  AssetGenImage get downArrow =>
      const AssetGenImage('assets/images/down_arrow.png');

  /// File path: assets/images/ela_qsmk_vg_aa_dndk_1.png
  AssetGenImage get elaQsmkVgAaDndk1 =>
      const AssetGenImage('assets/images/ela_qsmk_vg_aa_dndk_1.png');

  /// File path: assets/images/email.png
  AssetGenImage get email => const AssetGenImage('assets/images/email.png');

  /// File path: assets/images/end_user_issue.png
  AssetGenImage get endUserIssue =>
      const AssetGenImage('assets/images/end_user_issue.png');

  /// File path: assets/images/enter_otp_cuate_1.png
  AssetGenImage get enterOtpCuate1 =>
      const AssetGenImage('assets/images/enter_otp_cuate_1.png');

  /// File path: assets/images/expired_1.png
  AssetGenImage get expired1 =>
      const AssetGenImage('assets/images/expired_1.png');

  /// File path: assets/images/fi_3126571.png
  AssetGenImage get fi3126571 =>
      const AssetGenImage('assets/images/fi_3126571.png');

  /// File path: assets/images/forbidden.png
  AssetGenImage get forbidden =>
      const AssetGenImage('assets/images/forbidden.png');

  /// File path: assets/images/group_10.png
  AssetGenImage get group10 =>
      const AssetGenImage('assets/images/group_10.png');

  /// File path: assets/images/group_17.png
  AssetGenImage get group17 =>
      const AssetGenImage('assets/images/group_17.png');

  /// File path: assets/images/group_2.png
  AssetGenImage get group2 => const AssetGenImage('assets/images/group_2.png');

  /// File path: assets/images/group_272.png
  AssetGenImage get group272 =>
      const AssetGenImage('assets/images/group_272.png');

  /// File path: assets/images/group_273.png
  AssetGenImage get group273 =>
      const AssetGenImage('assets/images/group_273.png');

  /// File path: assets/images/group_295.png
  AssetGenImage get group295 =>
      const AssetGenImage('assets/images/group_295.png');

  /// File path: assets/images/group_307.png
  AssetGenImage get group307 =>
      const AssetGenImage('assets/images/group_307.png');

  /// File path: assets/images/group_3117.png
  AssetGenImage get group3117 =>
      const AssetGenImage('assets/images/group_3117.png');

  /// File path: assets/images/group_3122.png
  AssetGenImage get group3122 =>
      const AssetGenImage('assets/images/group_3122.png');

  /// File path: assets/images/group_3149.png
  AssetGenImage get group3149 =>
      const AssetGenImage('assets/images/group_3149.png');

  /// File path: assets/images/group_3153.png
  AssetGenImage get group3153 =>
      const AssetGenImage('assets/images/group_3153.png');

  /// File path: assets/images/group_3157.png
  AssetGenImage get group3157 =>
      const AssetGenImage('assets/images/group_3157.png');

  /// File path: assets/images/group_320.png
  AssetGenImage get group320 =>
      const AssetGenImage('assets/images/group_320.png');

  /// File path: assets/images/group_321.png
  AssetGenImage get group321 =>
      const AssetGenImage('assets/images/group_321.png');

  /// File path: assets/images/group_322.png
  AssetGenImage get group322 =>
      const AssetGenImage('assets/images/group_322.png');

  /// File path: assets/images/group_334.png
  AssetGenImage get group334 =>
      const AssetGenImage('assets/images/group_334.png');

  /// File path: assets/images/group_337.png
  AssetGenImage get group337 =>
      const AssetGenImage('assets/images/group_337.png');

  /// File path: assets/images/group_338.png
  AssetGenImage get group338 =>
      const AssetGenImage('assets/images/group_338.png');

  /// File path: assets/images/group_339.png
  AssetGenImage get group339 =>
      const AssetGenImage('assets/images/group_339.png');

  /// File path: assets/images/group_344.png
  AssetGenImage get group344 =>
      const AssetGenImage('assets/images/group_344.png');

  /// File path: assets/images/group_352.png
  AssetGenImage get group352 =>
      const AssetGenImage('assets/images/group_352.png');

  /// File path: assets/images/group_354.png
  AssetGenImage get group354 =>
      const AssetGenImage('assets/images/group_354.png');

  /// File path: assets/images/group_356.png
  AssetGenImage get group356 =>
      const AssetGenImage('assets/images/group_356.png');

  /// File path: assets/images/group_358.png
  AssetGenImage get group358 =>
      const AssetGenImage('assets/images/group_358.png');

  /// File path: assets/images/group_360.png
  AssetGenImage get group360 =>
      const AssetGenImage('assets/images/group_360.png');

  /// File path: assets/images/group_376.png
  AssetGenImage get group376 =>
      const AssetGenImage('assets/images/group_376.png');

  /// File path: assets/images/group_4.png
  AssetGenImage get group4 => const AssetGenImage('assets/images/group_4.png');

  /// File path: assets/images/group_401.png
  AssetGenImage get group401 =>
      const AssetGenImage('assets/images/group_401.png');

  /// File path: assets/images/group_402.png
  AssetGenImage get group402 =>
      const AssetGenImage('assets/images/group_402.png');

  /// File path: assets/images/group_403.png
  AssetGenImage get group403 =>
      const AssetGenImage('assets/images/group_403.png');

  /// File path: assets/images/group_8.png
  AssetGenImage get group8 => const AssetGenImage('assets/images/group_8.png');

  /// File path: assets/images/group_9.png
  AssetGenImage get group9 => const AssetGenImage('assets/images/group_9.png');

  /// File path: assets/images/home.png
  AssetGenImage get home => const AssetGenImage('assets/images/home.png');

  /// File path: assets/images/ic_logout.png
  AssetGenImage get icLogout =>
      const AssetGenImage('assets/images/ic_logout.png');

  /// File path: assets/images/im_transfer.png
  AssetGenImage get imTransfer =>
      const AssetGenImage('assets/images/im_transfer.png');

  /// File path: assets/images/img_account_removed.png
  AssetGenImage get imgAccountRemoved =>
      const AssetGenImage('assets/images/img_account_removed.png');

  /// File path: assets/images/intersection_1.png
  AssetGenImage get intersection1 =>
      const AssetGenImage('assets/images/intersection_1.png');

  /// File path: assets/images/intersection_2.png
  AssetGenImage get intersection2 =>
      const AssetGenImage('assets/images/intersection_2.png');

  /// File path: assets/images/invalild.png
  AssetGenImage get invalild =>
      const AssetGenImage('assets/images/invalild.png');

  /// File path: assets/images/kyc_success_img.png
  AssetGenImage get kycSuccessImg =>
      const AssetGenImage('assets/images/kyc_success_img.png');

  /// File path: assets/images/language.png
  AssetGenImage get language =>
      const AssetGenImage('assets/images/language.png');

  /// File path: assets/images/layer_14.png
  AssetGenImage get layer14 =>
      const AssetGenImage('assets/images/layer_14.png');

  /// File path: assets/images/layer_2.png
  AssetGenImage get layer2 => const AssetGenImage('assets/images/layer_2.png');

  /// File path: assets/images/layer_30.png
  AssetGenImage get layer30 =>
      const AssetGenImage('assets/images/layer_30.png');

  /// File path: assets/images/location_address_cuate.png
  AssetGenImage get locationAddressCuate =>
      const AssetGenImage('assets/images/location_address_cuate.png');

  /// File path: assets/images/log_out.png
  AssetGenImage get logOut => const AssetGenImage('assets/images/log_out.png');

  /// File path: assets/images/login_another_device.png
  AssetGenImage get loginAnotherDevice =>
      const AssetGenImage('assets/images/login_another_device.png');

  /// File path: assets/images/login_success.png
  AssetGenImage get loginSuccess =>
      const AssetGenImage('assets/images/login_success.png');

  /// File path: assets/images/mail_sent.png
  AssetGenImage get mailSent =>
      const AssetGenImage('assets/images/mail_sent.png');

  /// File path: assets/images/mobile_inbox_cuate.png
  AssetGenImage get mobileInboxCuate =>
      const AssetGenImage('assets/images/mobile_inbox_cuate.png');

  /// File path: assets/images/nikit_logo.png
  AssetGenImage get nikitLogo =>
      const AssetGenImage('assets/images/nikit_logo.png');

  /// File path: assets/images/no_bank_account.png
  AssetGenImage get noBankAccount =>
      const AssetGenImage('assets/images/no_bank_account.png');

  /// File path: assets/images/no_bank_bank_transfer.png
  AssetGenImage get noBankBankTransfer =>
      const AssetGenImage('assets/images/no_bank_bank_transfer.png');

  /// File path: assets/images/no_data_cuate.png
  AssetGenImage get noDataCuate =>
      const AssetGenImage('assets/images/no_data_cuate.png');

  /// File path: assets/images/no_notification.png
  AssetGenImage get noNotification =>
      const AssetGenImage('assets/images/no_notification.png');

  /// File path: assets/images/no_record.png
  AssetGenImage get noRecord =>
      const AssetGenImage('assets/images/no_record.png');

  /// File path: assets/images/online_world_rafiki.png
  AssetGenImage get onlineWorldRafiki =>
      const AssetGenImage('assets/images/online_world_rafiki.png');

  /// File path: assets/images/person_1.png
  AssetGenImage get person1 =>
      const AssetGenImage('assets/images/person_1.png');

  /// File path: assets/images/pleasant_surprise_cuate_1_1.png
  AssetGenImage get pleasantSurpriseCuate11 =>
      const AssetGenImage('assets/images/pleasant_surprise_cuate_1_1.png');

  /// File path: assets/images/profile_pic_cuate_1.png
  AssetGenImage get profilePicCuate1 =>
      const AssetGenImage('assets/images/profile_pic_cuate_1.png');

  /// File path: assets/images/qr.png
  AssetGenImage get qr => const AssetGenImage('assets/images/qr.png');

  /// File path: assets/images/qr_1.png
  AssetGenImage get qr1 => const AssetGenImage('assets/images/qr_1.png');

  /// File path: assets/images/qr_dim.png
  AssetGenImage get qrDim => const AssetGenImage('assets/images/qr_dim.png');

  /// File path: assets/images/questions_cuate.png
  AssetGenImage get questionsCuate =>
      const AssetGenImage('assets/images/questions_cuate.png');

  /// File path: assets/images/rectangle_85.png
  AssetGenImage get rectangle85 =>
      const AssetGenImage('assets/images/rectangle_85.png');

  /// File path: assets/images/saving_1.png
  AssetGenImage get saving1 =>
      const AssetGenImage('assets/images/saving_1.png');

  /// File path: assets/images/security.png
  AssetGenImage get security =>
      const AssetGenImage('assets/images/security.png');

  /// File path: assets/images/shield.png
  AssetGenImage get shield => const AssetGenImage('assets/images/shield.png');

  /// File path: assets/images/splash_background.png
  AssetGenImage get splashBackground =>
      const AssetGenImage('assets/images/splash_background.png');

  /// File path: assets/images/splash_screen.png
  AssetGenImage get splashScreen =>
      const AssetGenImage('assets/images/splash_screen.png');

  /// File path: assets/images/subtraction_11.png
  AssetGenImage get subtraction11 =>
      const AssetGenImage('assets/images/subtraction_11.png');

  /// File path: assets/images/subtraction_3.png
  AssetGenImage get subtraction3 =>
      const AssetGenImage('assets/images/subtraction_3.png');

  /// File path: assets/images/subtraction_7.png
  AssetGenImage get subtraction7 =>
      const AssetGenImage('assets/images/subtraction_7.png');

  /// File path: assets/images/subtraction_9.png
  AssetGenImage get subtraction9 =>
      const AssetGenImage('assets/images/subtraction_9.png');

  /// File path: assets/images/tickets_1.png
  AssetGenImage get tickets1 =>
      const AssetGenImage('assets/images/tickets_1.png');

  /// File path: assets/images/time_out.png
  AssetGenImage get timeOut =>
      const AssetGenImage('assets/images/time_out.png');

  /// File path: assets/images/top_wrong.png
  AssetGenImage get topWrong =>
      const AssetGenImage('assets/images/top_wrong.png');

  /// File path: assets/images/transaction_faliure.png
  AssetGenImage get transactionFaliure =>
      const AssetGenImage('assets/images/transaction_faliure.png');

  /// File path: assets/images/transfer_success.png
  AssetGenImage get transferSuccess =>
      const AssetGenImage('assets/images/transfer_success.png');

  /// File path: assets/images/trash_bin.png
  AssetGenImage get trashBin =>
      const AssetGenImage('assets/images/trash_bin.png');

  /// File path: assets/images/tutorialbg_1.png
  AssetGenImage get tutorialbg1 =>
      const AssetGenImage('assets/images/tutorialbg_1.png');

  /// File path: assets/images/tutorialbg_2.png
  AssetGenImage get tutorialbg2 =>
      const AssetGenImage('assets/images/tutorialbg_2.png');

  /// File path: assets/images/union_3.png
  AssetGenImage get union3 => const AssetGenImage('assets/images/union_3.png');

  /// File path: assets/images/union_4.png
  AssetGenImage get union4 => const AssetGenImage('assets/images/union_4.png');

  /// File path: assets/images/whats_app_image.png
  AssetGenImage get whatsAppImage =>
      const AssetGenImage('assets/images/whats_app_image.png');

  /// File path: assets/images/whatsapp.jpg
  AssetGenImage get whatsappJpg =>
      const AssetGenImage('assets/images/whatsapp.jpg');

  /// File path: assets/images/whatsapp.png
  AssetGenImage get whatsappPng =>
      const AssetGenImage('assets/images/whatsapp.png');

  /// File path: assets/images/whatsapp.webp
  AssetGenImage get whatsappWebp =>
      const AssetGenImage('assets/images/whatsapp.webp');

  /// File path: assets/images/your_offline.png
  AssetGenImage get yourOffline =>
      const AssetGenImage('assets/images/your_offline.png');

  /// List of all assets
  List<AssetGenImage> get values => [
        frame,
        activeSupportCuate,
        allTicket,
        alreadyScan,
        appUpdate,
        approvalSubmitted,
        aslogo1,
        b,
        banAccountAddSuccess,
        bank,
        bank2,
        bankAccountAddSuccess,
        bankFaliure,
        cameraAccess,
        couponCodeSuccess,
        customerService,
        dashboard,
        deleteBankAccount,
        downArrow,
        elaQsmkVgAaDndk1,
        email,
        endUserIssue,
        enterOtpCuate1,
        expired1,
        fi3126571,
        forbidden,
        group10,
        group17,
        group2,
        group272,
        group273,
        group295,
        group307,
        group3117,
        group3122,
        group3149,
        group3153,
        group3157,
        group320,
        group321,
        group322,
        group334,
        group337,
        group338,
        group339,
        group344,
        group352,
        group354,
        group356,
        group358,
        group360,
        group376,
        group4,
        group401,
        group402,
        group403,
        group8,
        group9,
        home,
        icLogout,
        imTransfer,
        imgAccountRemoved,
        intersection1,
        intersection2,
        invalild,
        kycSuccessImg,
        language,
        layer14,
        layer2,
        layer30,
        locationAddressCuate,
        logOut,
        loginAnotherDevice,
        loginSuccess,
        mailSent,
        mobileInboxCuate,
        nikitLogo,
        noBankAccount,
        noBankBankTransfer,
        noDataCuate,
        noNotification,
        noRecord,
        onlineWorldRafiki,
        person1,
        pleasantSurpriseCuate11,
        profilePicCuate1,
        qr,
        qr1,
        qrDim,
        questionsCuate,
        rectangle85,
        saving1,
        security,
        shield,
        splashBackground,
        splashScreen,
        subtraction11,
        subtraction3,
        subtraction7,
        subtraction9,
        tickets1,
        timeOut,
        topWrong,
        transactionFaliure,
        transferSuccess,
        trashBin,
        tutorialbg1,
        tutorialbg2,
        union3,
        union4,
        whatsAppImage,
        whatsappJpg,
        whatsappPng,
        whatsappWebp,
        yourOffline
      ];
}

class $AssetsQuizJsonGen {
  const $AssetsQuizJsonGen();

  /// File path: assets/quizJson/quizz.json
  String get quizz => 'assets/quizJson/quizz.json';

  /// List of all assets
  List<String> get values => [quizz];
}

class $AssetsTranslationsGen {
  const $AssetsTranslationsGen();

  /// File path: assets/translations/en.json
  String get en => 'assets/translations/en.json';

  /// List of all assets
  List<String> get values => [en];
}

class Assets {
  Assets._();

  static const $AssetsImagesGen images = $AssetsImagesGen();
  static const $AssetsQuizJsonGen quizJson = $AssetsQuizJsonGen();
  static const $AssetsTranslationsGen translations = $AssetsTranslationsGen();
}

class AssetGenImage {
  const AssetGenImage(
    this._assetName, {
    this.size,
    this.flavors = const {},
  });

  final String _assetName;

  final Size? size;
  final Set<String> flavors;

  Image image({
    Key? key,
    AssetBundle? bundle,
    ImageFrameBuilder? frameBuilder,
    ImageErrorWidgetBuilder? errorBuilder,
    String? semanticLabel,
    bool excludeFromSemantics = false,
    double? scale,
    double? width,
    double? height,
    Color? color,
    Animation<double>? opacity,
    BlendMode? colorBlendMode,
    BoxFit? fit,
    AlignmentGeometry alignment = Alignment.center,
    ImageRepeat repeat = ImageRepeat.noRepeat,
    Rect? centerSlice,
    bool matchTextDirection = false,
    bool gaplessPlayback = false,
    bool isAntiAlias = false,
    String? package,
    FilterQuality filterQuality = FilterQuality.low,
    int? cacheWidth,
    int? cacheHeight,
  }) {
    return Image.asset(
      _assetName,
      key: key,
      bundle: bundle,
      frameBuilder: frameBuilder,
      errorBuilder: errorBuilder,
      semanticLabel: semanticLabel,
      excludeFromSemantics: excludeFromSemantics,
      scale: scale,
      width: width,
      height: height,
      color: color,
      opacity: opacity,
      colorBlendMode: colorBlendMode,
      fit: fit,
      alignment: alignment,
      repeat: repeat,
      centerSlice: centerSlice,
      matchTextDirection: matchTextDirection,
      gaplessPlayback: gaplessPlayback,
      isAntiAlias: isAntiAlias,
      package: package,
      filterQuality: filterQuality,
      cacheWidth: cacheWidth,
      cacheHeight: cacheHeight,
    );
  }

  ImageProvider provider({
    AssetBundle? bundle,
    String? package,
  }) {
    return AssetImage(
      _assetName,
      bundle: bundle,
      package: package,
    );
  }

  String get path => _assetName;

  String get keyName => _assetName;
}
