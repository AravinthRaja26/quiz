import 'dart:async';
import 'dart:io';
import 'package:auto_route/auto_route.dart';
import 'package:nikitchem/application/localizations/locale_keys.g.dart';
import 'package:nikitchem/data/injection/injector.dart';
import 'package:nikitchem/infrastructure/globle.dart';
import 'package:nikitchem/presentation/routing/auto_router.gr.dart';
import 'package:nikitchem/presentation/ui/custom_widget/app_alert.dialog.dart';
import 'package:nikitchem/presentation/ui/utils/asset_path.dart';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:nikitchem/presentation/ui/utils/listren_show_dialog.dart';

///
Future<ApiResult<R>> runApiInSafeZone<R>(Future<R> Function() callback) async {
  try {
    return ApiResult<R>(data: await callback());
  } on DioException catch (e) {
    debugPrint('${e.type}');
    return ApiResult<R>(error: e);
  } catch (e) {
    return ApiResult<R>(error: e);
  }
}

///
class ApiResult<T> {
  ///
  final T? data;

  ///
  final Object? error;

  ///
  const ApiResult({this.data, this.error});

  ///
  bool get isSucceeded => error == null;

  ///
  ///
  static Future<void> catchError(
      ApiResult<dynamic>? result, BuildContext context,
      {String? contentMessage, VoidCallback? callBack}) async {
    switch (result?.error.runtimeType) {
      case DioException:
        final Response<dynamic>? errors =
            (result?.error as DioException).response;
        DioException error = result?.error as DioException;
        if (error.error.runtimeType == SocketException) {
          confirmationDialog(context,
              showCancelButton: false,
              image: 'assets/images/group_339.png',
              doneButtonText: LocaleKeys.retry.tr().toUpperCase(), onTap: () {
                AutoRouter.of(context).maybePop();
          },
              subTitle: LocaleKeys.noNetworkFound.tr() ??
                  'No network found, please check your network connections');
        } else if (error.type == DioExceptionType.connectionTimeout ||
            error.type == DioExceptionType.receiveTimeout) {

          IsShowAlert isShowAlert = injector<IsShowAlert>();
          isShowAlert.show = true;
          if (isShowAlert.show) {
            isShowAlert.show = false;
            timeOutAlert(context,
                image: 'assets/images/group_401.png',
                showCancelButton: false,
                doneButtonText: localLanguage?.keyRetry?.toUpperCase() ??
                    LocaleKeys.retry.tr().toUpperCase(), onTap: () {
                  /*AutoRouter.of(context).pushAndPopUntil(const DashboardScreen(),
                predicate: (_) => false);*/
                  isShowAlert.show = false;
                  AutoRouter.of(context).maybePop();
                },
                subTitle: LocaleKeys.noResponse.tr() ??
                    'No response,Please try again later');
          }

          /*confirmationDialog(context,
              image: AssetImagePath.timeOut,
              showCancelButton: false,
              doneButtonText: localLanguage?.keyRetry?.toUpperCase() ??LocaleKeys.retry.tr().toUpperCase(), onTap: () {
            *//*AutoRouter.of(context).pushAndPopUntil(const DashboardScreen(),
                predicate: (_) => false);*//*
                AutoRouter.of(context).pop();
          },
              subTitle: LocaleKeys.noResponse.tr() ??
                  'No response,Please try again later');*/
        } else {
          if (error.type == DioExceptionType.badResponse) {
            confirmationDialog(context,
                image: AssetImagePath.timeOut,
                showCancelButton: false,
                doneButtonText: localLanguage?.keyRetry?.toUpperCase() ?? LocaleKeys.retry.tr().toUpperCase(), onTap: () {
              /*AutoRouter.of(context).pushAndPopUntil(const DashboardScreen(),
                  predicate: (_) => false);*/
                  AutoRouter.of(context).maybePop();
            },
                subTitle: LocaleKeys.noResponse.tr() ??
                    'No response,Please try again later');
          } else {
            confirmationDialog(context, showCancelButton: false, onTap: () {
              AutoRouter.of(context).maybePop();
              /*AutoRouter.of(context).pushAndPopUntil(const DashboardScreen(),
                  predicate: (_) => false);*/
            },
                doneButtonText: localLanguage?.keyRetry?.toUpperCase() ??LocaleKeys.retry.tr().toUpperCase(),
                subTitle: (errors?.data.toString().isEmpty ?? false)
                    ? errors?.statusMessage
                    : error.error.runtimeType == SocketException
                        ? LocaleKeys.noNetworkFound.tr() ??
                            'No network found, please check your network connections'
                        : error.type == DioExceptionType.connectionTimeout
                            ? '${error.error}(${localLanguage?.keyNetworkConnections ?? LocaleKeys.networkConnections.tr()})'
                            : error.type == DioExceptionType.receiveTimeout
                                ? '${error.error}(${localLanguage?.keyNetworkConnections ?? LocaleKeys.networkConnections.tr()})'
                                : errors?.data['message']);
          }
        }
        break;
      default:
        debugPrint(result.toString());
        break;
    }
  }
}

/*///
Future<void> confirmDialog(BuildContext context,
    {String? contentMessage, VoidCallback? callBack}) async {
  await apiAlertDialog(context,
          contentMessage: contentMessage, callBack: callBack)
      .then((bool? value) {});
}*/
