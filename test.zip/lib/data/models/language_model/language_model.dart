import 'package:nikitchem/data/enum/language_enum.dart';

///
class LanguageModelTest {
  ///
  final LanguageEnum? language;

  ///
  final String? title;

  ///
  final String? subTitle;

  ///
  LanguageModelTest({this.language, this.title, this.subTitle});


}
