
///
class CountryCode{

  ///
  final int? code;

  ///
  final String? country;


  ///
  const CountryCode({this.code,this.country});
}