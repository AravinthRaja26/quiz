///
enum DocumentType{
  ///
  local,
  ///
  network,

}