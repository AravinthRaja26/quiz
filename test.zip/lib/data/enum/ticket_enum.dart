///
enum TicketEnum {
  ///
  allTicket,

  ///
  openTicket,

  ///
  resolved,
  ///
  inProcess,
}
