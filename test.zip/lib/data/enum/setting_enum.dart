///
enum SettingsType {
  ///
  manageAccount,

  ///
  languageSetting,

  ///
  contactUs,

  ///
  aboutUs,

  ///
  notifications,

  ///
  privacyPolicy,

  ///
  termsCondition,

  ///
  support,

  ///
  ticketDetails,
}
