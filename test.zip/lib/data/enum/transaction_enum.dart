
///
enum TransactionEnum{
  ///
  earned,
  ///
  transfer,
  ///
  redeemed,
  ///
  expired,
  ///
  verified
}